# Velta

A cross-platform **Delta Chat** client built as a single PWA-ish web app wrapped by **Tauri 2**.

## Download

**[Android](https://github.com/pbuzdin/velta/releases/latest/download/Velta-android-arm64.apk)** (~55 MB) · **[Windows](https://github.com/pbuzdin/velta/releases/latest/download/Velta-windows-x64-setup.exe)** (~14 MB) · **[macOS](https://github.com/pbuzdin/velta/releases/latest/download/Velta-macos-universal.dmg)** (~38 MB) — always the latest release; sizes approximate

Android needs an arm64 phone. Windows is the x64 installer. macOS is a universal test build that isn't notarized yet, so see [Install](#install) before the first launch. Other files and older versions are on the [releases page](https://github.com/pbuzdin/velta/releases).

## What it is

Velta shares one web frontend (`app/`) between:

- **Windows desktop** — a Tauri 2 app that bundles `deltachat-rpc-server.exe` as a sidecar.
- **macOS desktop** (test build) — the same Tauri 2 app with `deltachat-rpc-server` bundled as an `externalBin` sidecar; universal (Apple Silicon + Intel), ad-hoc signed, not notarized yet — see [Install on macOS](#install).
- **Android mobile** — the same Tauri 2 app, but the Delta Chat core runs in-process inside the APK. A foreground service keeps sync (and notifications) running after the app is backgrounded.
- **Browser/PWA** — the same frontend as a static site with a WebAssembly Chatmail core in the tab. Mail goes out through a WebSocket proxy on a chatmail relay (the PWA origin and the proxy host can be different domains). A refresh keeps the signed-in account, database included: the browser copy is written when login or an identity restore finishes, when the page goes to the background, and every few seconds, and a copy cut off by a reload is ignored in favour of the previous one. A crash can drop the last few seconds until the next sync. A new deploy reaches an open PWA on its next load; a page that was already open shows an update notice. A public build is published at [velta.cc/web](https://velta.cc/web) by CI (it mints new chatmail accounts through the configured relay even from another origin). Serving `app/` without the wasm dist still falls back to a mock core (UI smoke test). How to host your own copy: [docs/pwa-self-host.md](docs/pwa-self-host.md); standalone WebSocket proxy in one command: [docs/deploy-pwa-websocket-proxy.md](docs/deploy-pwa-websocket-proxy.md).

The UI is plain HTML/CSS/ES modules (no bundler). The backend is the upstream [Delta Chat core](https://github.com/chatmail/core) at version `2.66.0`.

## Screenshots

Captured from the responsive PWA running in demo mode (mock core), dark theme.

|                | Mobile | Desktop |
|:--------------:|:------:|:-------:|
| **Chat list**  | ![Mobile chat list](screenshots/mobile-chat-list.png) | ![Desktop chat list](screenshots/desktop-chat-list.png) |
| **Chat opened** | ![Mobile chat](screenshots/mobile-chat.png) | ![Desktop chat](screenshots/desktop-chat.png) |

## Install

<details>
<summary>macOS (test build): opening a non-notarized app</summary>

Download `Velta_<version>_universal.dmg` from the
[latest release](https://github.com/pbuzdin/velta/releases/latest). It runs on
Apple Silicon and Intel Macs, macOS 10.15 or newer. The macOS build was
contributed by [@mrgluek](https://github.com/mrgluek) - thank you!

The macOS build is **ad-hoc signed and not notarized** (there is no Apple
Developer ID yet), so Gatekeeper blocks the first launch with "Velta can't be
opened" / "Apple could not verify…". The app is not damaged; clear the
download quarantine once:

1. Open the DMG and drag **Velta** into **Applications**.
2. Either run, in Terminal:

   ```bash
   xattr -dr com.apple.quarantine /Applications/Velta.app
   ```

   or try to open Velta once, then open **System Settings → Privacy &
   Security**, scroll down and click **Open Anyway** (confirm with your
   password). On macOS 15+ the old right-click → **Open** shortcut no longer
   bypasses the check — use one of these two ways.
3. Start Velta normally from then on.

Microphone (audio calls) and camera (QR scanning) are requested on first
use. The ad-hoc signature changes with every build, so macOS may ask for
these permissions again after an update, and **System Settings → Privacy &
Security** can show stale Velta entries — remove them if a permission looks
granted but does not work.

Data lives in `~/Library/Application Support/org.velta/` (accounts) and logs
in `~/Library/Logs/org.velta/`. Self-update works like on Windows (signed
updater archive, see "One-click updates"); updates downloaded by the app are
not quarantined.

</details>

<details>
<summary>Self-host the browser PWA</summary>

A ready-to-serve tree (wasm-opt + brotli/gzip sidecars) lives on the
`pwa-dist` branch:

```sh
git clone --depth 1 --branch pwa-dist --single-branch \
  https://github.com/pbuzdin/velta.git velta-pwa
```

Upload `velta-pwa/` except `.git` to any HTTPS host. Mail uses a WebSocket
proxy on a chatmail relay — the PWA origin and the proxy host can differ;
the relay must allowlist the PWA origin (`ws_allowed_origins`).

Full steps: [docs/pwa-self-host.md](docs/pwa-self-host.md).

</details>

## Functions

- **@mentions** — type `@` in a group to pick a member; the message carries
  plain text `@Name (C0FE)` (first fingerprint group), so Delta Chat shows it
  as typed. Velta highlights mentions, mentions of you stronger, and a muted
  chat still notifies you when you are mentioned (switch in Notifications,
  default on). Details: [docs/mentions.md](docs/mentions.md).
- **Send later** — long-press or right-click Send, press Ctrl+Shift+Enter, or pick it in the attach menu to schedule a
  message: presets or a date and time. Scheduled messages show as a chip in
  the chat and in a per-chat and global list, where you can edit, send now,
  or delete them. Android uses exact alarms when allowed and still sends on
  an inexact one. Details: [docs/scheduled-messages.md](docs/scheduled-messages.md).
- **SOCKS5 proxy (native apps, opt-in)** — save and switch between SOCKS5
  proxies on this device, your LAN, or the internet, with optional
  username/password authentication. A `velta://proxy` link, QR code, or chat
  card adds one after a confirmation that names the server and warns about
  credentials and trust. Details: [docs/socks5-proxy-link.md](docs/socks5-proxy-link.md).
- **WebSocket transport (Android/Windows, opt-in)** — mail can ride a
  WebSocket proxy (the same kind the PWA uses) through a local SOCKS5
  listener. Proxies are saved and switchable; a `velta://ws` link or QR
  adds one after a confirmation. Proxy operators can hand out signed invite
  links with an expiry, a device limit, and revocation. Invite links of all
  kinds show as **invite cards** in chat, and a relay invite can sign you up
  straight from **Add account**. Shared invite links point to
  [velta.cc/join](https://velta.cc/join) by default (since 1.4.87) — a
  landing page that greets the invitee and deep-links into the app; the
  older Delta Chat link format keeps working everywhere. Details:
  [docs/websocket-transport.md](docs/websocket-transport.md),
  [docs/invite-cards.md](docs/invite-cards.md); server side:
  [docs/deploy-pwa-websocket-proxy.md](docs/deploy-pwa-websocket-proxy.md).
- **Smaller QR codes** — every QR the app shows picks the optimal
  numeric/alphanumeric/byte segments, so codes have fewer modules and scan
  more easily.
- **Speed** — incoming messages are batched per frame, notification and
  chat-list work is coalesced, message-row gestures use one delegated
  listener, and the QR scanner, large-file upload and image compression
  load on demand. On a busy account the longest UI freeze dropped from
  about 600 ms to under 50 ms, and opening a chat from about 140 ms to 114 ms.
- **Archived chats row** — when you have archived chats, an **Archived (n)**
  row sits at the bottom of the chat list; archived chats keep their menu
  and in-chat search.

<details>
<summary>Local chat (beta)</summary>

Velta also ships a second, fully serverless transport: 1:1 end-to-end-encrypted
chat between paired devices on the same network (iroh QUIC, no relay, no
account). Devices discover each other via LAN beacons and pair in one of two
ways:

- **Invite QR / pasted code** — the ticket carries a one-time pairing token;
  presenting it is the out-of-band proof and pairing completes immediately.
- **Nearby tap** — sends a pairing request that the other device must
  explicitly approve in a dialog. Beacons carry names and addresses only,
  never the pairing token, so a LAN listener cannot pair by listening.

Paired devices exchange end-to-end-encrypted messages; messages to offline
peers are queued and flushed on reconnect. Engine: `velta-app/src-tauri/src/p2p.rs`;
UI: `app/js/p2p.js`. A headless terminal hub for debugging lives in
`velta-app/src-tauri/src/bin/p2p-hub.rs` — `cargo run --bin p2p-hub --features p2p-hub`
(behind a feature so release bundles never ship it).

Local chat is **disabled by default**. Switch it on/off in the drawer
(**Velta Loop**, subtitle "Local chat on the same network"): when off, the engine never starts (no endpoint
socket, no LAN beacons) and the card and drawer rows disappear. The
browser shows that switch after **Enter local chat…**, so the preview
can be turned off. The
preference persists across restarts. On first run the welcome screen offers
"Enter local chat…" — it enables local chat and skips relay setup; enabling
local chat again later brings the setup screen back.

**Local chats look like regular chats.** Each paired peer appears in the chat
list and opens in the standard chat view (adapter: `app/js/local-chat.js`
wraps the core, so the virtualized list, composer, drafts and read-tick
rendering all work unchanged). Text and **media files** (images, video, audio,
any file up to 256 MB) are supported: files transfer as base64-chunked frames
over the same encrypted session, land in `p2p-blobs/<peer>/` under the
accounts directory and render through the regular media pipeline. Peer names
arrive only from pairing. The hub — device identity, invite QR, add contact,
nearby-device pairing — is a collapsible **Velta Loop** card pinned above the chat list
while local chat is on; peers must be online to receive media (text queues
offline). Voice messages are not offered in local chats (the attach menu hides
the item) and the audio-call button is hidden there — the P2P engine carries
no call signaling.

**Local groups.** Up to 5 devices (you and up to 4 paired ones) can chat in a group (no server, no
relay): the creator signs the member list, every message goes straight between
the members' devices and is replayed to whoever was offline. Groups appear in
the chat list like any chat (create one from the **Velta Loop** card at the
top of the chat list, or from the new-chat
menu; only online devices that run a group-capable version can be added). The
creator renames the group and adds or removes members from the info sheet;
anyone can leave and the creator can disband. A tick turns double only when
every current member has the message, and "Message info" lists who has it.
Members need not have paired with each other, only with the creator. Photos and
files (up to **32 MB**) are sent to the members who are online at that moment —
offline members get no file and show "not yet" with a Retry button per member;
voice messages and stickers are not offered in groups. A group needs Velta 1.4.56
or newer on every member's device (a fifth member needs the version after 1.4.57 on
every device, and all members online when it is added) (group photos/files and the typing indicator
need 1.4.57; 1.4.56 simply ignores them); older devices keep working
for 1:1 chat.

**Typing indicator.** Both 1:1 and group local chats show "Anna is typing…" (or
"Anna and Ben are typing…") in the chat header and the chat list while someone
types; it disappears a few seconds after they stop. The hints are live only
(never stored, never sent to offline or older devices). The drawer row "Typing
indicator" under the Local chat switch turns it off in both directions
(default on).

**Transfer and queue states are surfaced in the UI.** An outbound file shows a
progress bar fed by `file-progress` events (2% steps); a completed transfer
swaps the bar for the file card, and a session death mid-transfer marks the
message failed with a Retry button (re-sends the stored copy from byte zero —
there is no resume; the receiving side simply discards bad partials). Media
picked while the peer is offline parks in a queue chip at the right edge of
the composer (`#lc-queue-chip` → popup with per-item send-now/remove); the
queue auto-flushes, oldest first, on the peer's next `presence` online event.
Offline texts are queued inside the engine and show a pending clock in the
bubble: `p2p_send` returns `{id, queued}`, a reconnect flush emits a
`msg-state` event to upgrade the clock to ticks, and the peer's ack completes
the read state. A text whose send fails outright renders a Retry button too
(resendMessage re-sends the same text and quote as a fresh message; the
failed bubble is restored if the engine still rejects it). Chat names carry a
green wifi badge instead of the relay chats' open lock (the transport is
QUIC/TLS with pairing-pinned identities).

**Interface scale and theme live in the drawer.** Velta pins the WebView's
`textZoom` to 100 (system font scale otherwise inflates text out of its
px-sized boxes — broken layouts on devices set to the largest scaling
factor) and instead offers coherent, in-app scaling: a drawer spoiler with
Small / Normal / Large applied as a zoom on `<html>` before first paint.
The theme spoiler adds **Auto**, which follows the system's
`prefers-color-scheme` live (including the status-bar tint); it is the
default for fresh installs. **Language**, directly under Theme, is English,
Français, or Русский. The choice is per device and reloads the app.
Untranslated text stays English. Product names stay as written.
**About Velta → Show device info** lists the screen,
viewport, scale, locale and versions for bug reports (Copy / Share; no
account data).

**Chat appearance** (drawer → Chat appearance, modelled on Telegram's chat
settings) changes how the chat looks without touching the rest of the UI:
a **message text size** slider (10–22 px; default 15.5 px; sender names,
quotes, forward labels and reactions scale with it), a **message corners** slider
(0–14 px; the bubble's tail corner, reply quotes, photos, videos and link
cards follow it), an **accent color** (8 presets plus a custom color picker)
and **hyphenation** for English and Russian. A live preview with an incoming
and an outgoing bubble sits on top, and Reset to defaults puts everything
back. The accent drives links, buttons, switches, focus rings and your own
bubbles; the hover/pressed shades and the text colors on top of it are
derived automatically and held at WCAG AA (4.5 : 1) in both light and dark
(the Brutal theme keeps its own palette). Settings are per device and apply
before first paint, like the interface scale. Message text is tagged `ru` or
`en` per message so the engine hyphenates with the right dictionary; links,
e-mail addresses and hashtags are never hyphenated.

**Export settings** (drawer → Export settings to Saved Messages, last item
before About) sends one plain-text message to your own Saved Messages: a
`Velta settings v1 (date)` header and one `key: value` line per setting
(theme, language, interface scale, chat appearance, bottom bar, chat categories,
notification toggles, media and link-preview options, send on Enter, read
receipts and a few chat options). Open that message on another device and tap
**Apply these settings**; a confirm lists what would change (current → new)
before anything is applied, live. It is manual only and never syncs
automatically. Relays, transports, push, proxy/tunnel, keys, addresses,
multi-device and device info are never included. Format and rules:
[`docs/settings-transfer.md`](docs/settings-transfer.md).

</details>

<details>
<summary>Audio and video calls (beta)</summary>

Single chats have an audio-call button in the chat header (core 2.60+) and
a video call (header icon on wide screens, ⋮ → **Video call** on phones).
Calls work with Delta Chat: the camera can be turned on and off during any
call, and on phones you can switch between the front and back cameras.
Calls are end-to-end encrypted like everything else: the core carries the
call signaling — the offer and answer SDP ride in encrypted messages — and
hands the app the relay's STUN/TURN servers, while the audio itself flows
over a WebRTC peer connection inside the app's WebView.

- The call button appears in single chats; groups use **Velta Circle** (below).
- Before the microphone or camera is used (accepting, accepting with video,
  turning the camera on, flipping it), Velta checks the permission and asks
  for it first, so a call no longer fails silently on a denied camera.
- Desktop (WebView2) grants the microphone through a launch argument; on
  Android the app asks for the record-audio permission on the first call.
- On Android an audio call starts on the earpiece (or a connected
  wired/Bluetooth headset), like a phone call, and a video call on the
  loudspeaker. **Speaker** and **Earpiece** are both shown, and only the
  active route is highlighted. A tap forces that route, including a second
  tap on the same button so a headset can still be overridden. The screen
  turns off when the phone is at your ear.
  Desktop and the browser use the system's audio output, so neither button
  is shown there.
- Missed, declined and ended calls appear in the chat as a compact **call
  card** (direction, state and duration, red-tinted for missed/declined),
  and calls ring only while the app is open — a backgrounded app shows the
  call as missed.

</details>

<details>
<summary>Velta Circle — group audio calls (beta)</summary>

In a group, attach menu → **Velta Circle** posts the call, a built-in
mini-app. The call shows up in the chat as a card (call name, who started
it, who is in it, **Join** / **Open**; no ringing), and an in-call bar stays
at the top while you use the rest of the app. Up to **6** people talk at
once (later joiners wait until someone leaves); audio flows directly
between participants (full mesh, no media server) and always through the
relay's TURN servers, so nobody sees your IP address. When everyone has
left the card shows "Call ended · duration" and **Start again**.

Velta itself runs the call — the mini-app only gets Velta's call controls,
and only when its exact bundle matches a built-in hash; any other app gets
no microphone. Opened in Delta Chat or another webxdc client, Velta Circle
shows "Open in Velta to join" with the names of the people in the call.

</details>

<details>
<summary>Pinned messages</summary>

Any message in a group or private chat you can post in can be pinned from the
message context menu (**Pin** / **Unpin**); chats you can't write in, like
channels you only read, show no pin controls. Pinned messages show in a
**tray between the chat
header and the history**: collapsed it shows the newest pin (with a count when
there are several); tapping the tray expands it and lists every pinned message
with an **unpin button** on each row; tapping a row jumps to that message. Pins
sync through the core's pinned-messages API (core 2.59+), so they work across
devices and are visible to all chat members.

</details>

<details>
<summary>Chat list categories</summary>

A chip bar at the top of the chat list filters it in one tap:
**All · People · Groups · Channels · Bots · System**. "System" collects
device messages, saved messages and contact requests; a 1:1 chat lands
under **Bots** when its contact is a bot, otherwise under **People**
(checked again each time you pick People or Bots, per account). The
active chip is remembered across restarts, and the bar hides itself in side
views (Contacts, Calls, QR, Search). On phones you can also **swipe left or
right on the list** to step through the categories — vertical scrolling is
unaffected. Not every category has to be there: the drawer's
**Chat categories** section turns the non-All chips on or off (All always
stays, and with every chip off the bar hides entirely), and swiping skips
the hidden ones.

</details>

<details>
<summary>Search in chat</summary>

The chat header's magnifier opens a search over the **full history** — not
just loaded messages — backed by the core's fulltext index (group chats
included). Results list sender and text; tapping one jumps to the message.
Local (nearby) chats are searched within their loaded history only.

**Hashtags.** A `#tag` in message text (letters, digits and `_`, at least
one letter, so `#123` stays text) is tappable and opens Search in chat
prefilled with that tag. Tags inside links are left alone.

</details>

<details>
<summary>Link previews</summary>

A link can show a preview card: image, title, description and domain.
Tapping the card opens the link — in your system browser on desktop, in
the in-app browser on Android. Invite links are not previewed: they
already render as invite cards. That includes every `deltachat.id` link.

Addresses typed without `https://` are highlighted as links too
(`t.me/smysl_doc/10234`, `github.com/user/repo`, `www.example.com`,
`example.com:8080/a?b=c`) and open as `https://`. Only well-known domain
endings are recognised, so `main.js`, `notes.md`, `v1.2.3`, `e.g.` and
e-mail addresses stay plain text. Link previews still look only at
links written with `https://`.

**Drawer → Link previews**, and the same three choices on a chat's
context menu (that chat wins):

- **Off** — no card.
- **Send a picture** — a finished `https://` link goes out as a picture
  of the card (WebP, or JPEG when this app cannot encode WebP) with your
  text as the caption. The picture uses Velta's dark colors, with a small
  "Sent with Velta" chip in the top-right corner. A landscape photo on
  that picture is shown whole. The people you write to see that picture
  and do not contact the site.
- **Load on this device** — the old card. This device fetches the page
  when a plain text link is on screen. The same note sits under the
  radios: the fetch is https only, capped at 256 KB of page and 512 KB of
  image, cached in memory for the session, and it tells the linked site
  your IP address. Someone in a private or group chat may own that site,
  or be able to edit the page. When the profile has a proxy configured
  (SOCKS5 or HTTP), the page and its
  image are fetched through it; if the proxy is unsupported or unreachable,
  no preview is loaded rather than falling back to a direct fetch.

Captions on photos, videos and files do not load a preview. A picture
already sent does not turn back into a live card.

</details>

<details>
<summary>Strip tracking from links</summary>

Pasting a link into the composer, or opening one, drops known tracking
parameters (`utm_…` and click ids such as `fbclid`). A real id on the
same link stays (`https://example.com/?utm_source=x&id=1` keeps `id=1`).
A toast offers **Undo** for a few seconds, which puts the original link
back. Invite links and non-web links are left alone.

**Drawer → Strip tracking from links** is on until you turn it off.

</details>

<details>
<summary>Video messages</summary>

Videos show a thumbnail (a frame extracted from the file) with a play
button, size and duration. Tapping plays the video fullscreen in a
lightbox overlay with the player's own controls; close it with the X
button, Esc, or the system back button. It resumes that video where you
left it, stretches the picture to fill, and keeps the playback speed you
last chose.

- Thumbnails are extracted by the app itself and cached on disk, so they
  appear instantly on later opens.
- Cards keep the video's true shape: landscape videos render wide,
  vertical videos render as a narrow centered card (up to 260 px tall).
- If a thumbnail can't be extracted, the video still plays from a black
  card with the play button.

</details>

<details>
<summary>Shared contacts (vCards)</summary>

When someone sends a **person contact** into a chat (a `.vcf` vCard attachment),
Velta renders it as a compact contact card — avatar, display name and email
address — styled like the invite cards. Tapping the card imports the contact
(the vCard carries the contact's public key, which is the point of contact
gossip) and opens the direct-message chat. Re-sharing a received contact is the
message context menu's **Forward**. This core generation has no contact QR
codes — SecureJoin QRs exist only for the own profile and for groups — so the
vCard is the canonical shareable form.

</details>

<details>
<summary>Profiles and chat info</summary>

Tapping a chat's header (or your own avatar in the drawer) opens the info
modal: the avatar, the chat/profile name below it, and a description block
under the name — a contact's bio/status for people, the self-status for your
own profile, or the group/channel description — followed by the details rows
(address, key, notifications, relays), a **Storage** row (the chat's total
attachment size, counted when you open the sheet) and an **Old messages**
cleanup with the same age picker as the chat-list menu. Links on registered
invite domains render as invite cards and never trigger web previews (no
duplicate card, no fingerprint leak).
render as invite cards and never trigger web previews (no duplicate card, no
fingerprint leak).

What you can edit right in the sheet, in one editor (name, picture and
description together):

- **Own profile** — **Edit profile**: your name, avatar and description
  (status text; saving it empty clears it).
- **Groups and channels** — **Edit group / Edit channel**: rename the chat,
  set or remove its picture (members are informed automatically) and edit
  the description.
- **People** — **Edit name** sets a custom name that only you see; the
  bio/status shown in the sheet is theirs and stays read-only.

</details>
<details>
<summary>Profile management (add, transfer, export, delete)</summary>

The drawer's **Profile management…** modal has four tabs, plus a
**"Sync only active profile"** switch above them: when enabled, only the
profile you are currently using syncs mail — other profiles won't receive
messages until you switch to them (saves battery when you keep several
profiles around). It opens from two places: the **Accounts** popover in the
drawer head (the row under your profile list) and the **Profile
management…** row in the settings list.

- **Add profile** — paste a chatmail invite link, a relay domain, or scan a
  QR; a new profile is created on the relay. No relay name? The splash's
  **"Autopick the fastest relay"** option lets the core pick the
  fastest-answering one automatically and keeps adding relays in the
  background.
- **Second device** — moves a profile between devices over the LAN using the
  core's backup transfer.
- **Old device** shows a QR (its `provide_backup` offer, rendered as the
  design card with the Velta logo) and waits.
- **New device** taps **Receive a profile on this device…**, scans or pastes
  the code (`DCBACKUP2:…`, camera scan everywhere — native `BarcodeDetector`
  where the platform provides it, a built-in decoder fallback where it
  doesn't), and a fresh account is created and filled
  from the transfer — progress is reported live, and the other device stays
  signed in. When the transfer finishes, this device starts mail for that
  profile, so the relay line leaves "no relay configured" without a restart.
  The **Auto-download limit** drawer setting caps how much of
  that chat history is pulled in automatically (No limit / 1 MB / 5 MB /
  25 MB).
- **Export backup** — writes the whole profile (messages, contacts, keys)
  into a timestamped `.tar` in a folder you choose, with an optional
  passphrase (min 6 chars). The profile stays signed in; import via the
  restore option on the splash. In the browser PWA there is no folder
  picker — the backup downloads straight from the page as
  `velta-backup-<addr>-<date>.tar`. On Android a system save dialog asks
  where to put the `.tar`, so a file manager can reach it.
- **Identity backup** (browser PWA) — drawer **Identity backup…** saves the
  mail login and keys in a passphrase file (at least 8 characters). It is
  not the full message archive. The profile must already be signed in.
- **Delete profile** — permanently removes the profile you are in: the
  account, its keys, the message database and all blobs on this device.
  Velta asks you to type the profile's address to confirm, suggests writing
  an export first, and refuses to delete your last remaining profile. This
  cannot be undone.

The **Welcome to Velta** splash (full-screen, with the same choices: create a
new profile on a relay — type the address or scan its QR — **add as second
device** via a `dcbackup:` code, or **restore from a backup** file) is shown
only while there is no configured profile. The line above the logo is the
Velta version, the Chatmail core, and either Tauri or the PWA service-worker
cache. Right after creating a profile it
politely asks **"How should we call you?"** — a name is optional, Skip keeps
the default. Returning users with at least one account boot straight into
the app.

</details>

<details>
<summary>Multi-relay accounts</summary>

One profile can be reachable on **several chatmail relays** at once — what
Delta Chat desktop 2.47+ calls "Relays". Messages are received on all of them;
sending goes through the **primary** relay — and if that relay stops working,
the core automatically sends through another configured one. Pick which one
is primary under
**Relays of this profile…** → **"Use for sending"** on any relay (messages
currently waiting to be sent are dropped, since they carry the old sender
address; the change syncs to your other devices). The chat list **+** menu's
**Add a relay to this account** adds another relay to the profile you are
in, without opening that modal. The status bar shows one
segment per relay, each colored by that relay's own status, with the sending
animation on the sending relay's segment only.
A relay marked **(U)** confirmed UnifiedPush push notifications: the core
registered this device's push token there (Android with a UnifiedPush
distributor). No mark means "not confirmed", never a guess.

Each relay row also carries five small **capability flags** — **C** calls
(TURN credentials), **I** iroh transfers, **P** push notifications, **D**
instant delivery (IMAP IDLE; "not known yet" until that relay has connected),
**W** web
endpoints (the browser app can connect through this relay). A green corner
dot marks capabilities the relay advertises (W is probed live); a flag
without a dot means "not offered", or for D before the first connection
"not known yet" — never a guess. A legend at the bottom of
the modal repeats the letters and the dot. Under the address the row shows
the relay's comment and admin contact as plain text, a storage bar when the
relay reports a quota, and, when the core knows them, the recipient limit
and whether the connection is compressed.

- **Add relay** — paste a `dcaccount:`/`dclogin:` invite code or just the relay's domain (`nine.testrun.org`); the core
  configures it as a second transport (progress modal during setup).
- **Use for sending** — makes that relay the primary (sending) transport.
- **Remove relay** — immediate removal (core 2.60.0): the relay stops being
  used right away and your contacts are informed automatically, but messages
  still on their way to the old address may arrive for a short while. Your
  last relay cannot be removed — the core re-elects a sending relay if
  needed.
- **Stop using for sending** — on the sending relay's own row: moves sending
  to another configured relay in one tap, e.g. when the current sending
  relay is slow. The modal also shows each relay's live state — a relay
  that's down is marked *unreachable — messages queue until it's back*.

The thin status line above the chat list reflects the relay connection:
green connected, yellow connecting/retrying, amber when a relay is not
accepting new connections (Velta checks them out-of-band — the core alone
can keep a dead relay green for hours), grey once a relay has been refusing
connections for a while (offline — a fact, not an active problem), red
unreachable (after a 45 s
grace), blue for demo or local-chat-only mode; animated dashes while a
message is on its way to the relay. Hovering the line (or pulling down at
the top of the chat list on mobile) reveals one **chip per relay** above the
line — `cha*.uk · 55%` style: the relay's domain privacy-masked, plus its
storage quota (the percent turns amber near 70% and red past 90%). A
**✉ envelope** on a chip marks the relay your messages
actually go through — it follows automatic failover, and its color reports
sending health: green sent, amber retrying, red broken, grey unknown. The
marker keys off what the SMTP loop is really bound to, not the configured
address — a Velta core patch reports the live sending transport, so when
the core rotates or fails over between a profile's relays the envelope
moves with the traffic (within one status refresh) instead of going stale.
Full
domain, status and
quota sit in each chip's tooltip.

**Multi-device** (drawer switch) copies the messages you send to your other
devices and syncs state between them. It reads and writes the core's
`bcc_self` setting directly (off by default), so it always shows what the
profile really uses; if the value can't be read it shows "unknown" and
retries. Off means this device deletes messages from the relay (on every
relay of the profile) right after downloading them, so the switch asks
before turning off. The core turns it back on by itself after a backup
export, Add second device, or a sync message from another device; Velta
then shows a note and a toast with **Turn off again** (it never switches
it back on its own).

**Auto-download limit**: files above the limit wait for a tap and stay on
the relay until downloaded (or until the relay purges them, usually after
about 7 days), so a limit uses relay storage.

</details>

<details>
<summary>SOCKS5 proxy (native apps, opt-in)</summary>

Velta can send mail through a SOCKS5 proxy running on this device, on your
local network, or on the internet. Velta is the client; it does not ship or
operate a proxy server. The feature is **off by default**. Add a proxy from
the drawer with a `velta://proxy` link, QR code, deep link, or chat card,
then review the server and trust warning before confirming.

Several proxies can be saved, with one or none active. Optional
username/password authentication is supported; share links containing
credentials grant access to the proxy and must only be shared with people
you trust. The proxy operator can see which relays you connect to and when,
while messages remain end-to-end encrypted.

The drawer’s **SOCKS5 proxy** sheet offers Use/Stop, Rename, Share (QR and
link), and Delete. A manually configured profile proxy is never overwritten.
Backups and second-device transfers leave keeper-owned proxy settings out.
A selected SOCKS5 proxy and WebSocket transport are mutually exclusive.
Upgrades clear stale loopback proxy URLs left by the archived DNS tunnel.
Details: [`docs/socks5-proxy-link.md`](docs/socks5-proxy-link.md).

</details>

<details>
<summary>Deep links: formats and invite cards</summary>

Velta can open invite and account-setup links directly instead of making the user copy-paste them.

### Supported link formats

| Platform | Link type | What happens |
|---|---|---|
| Android | `https://i.delta.chat/#FINGERPRINT&v=3&…` (or a registered mirror domain, e.g. `https://i.gluek.info/#…`) | Intercepted by the Android intent filters and processed in-app. |
| Android / PWA | `https://deltachat.id/<name>` (username-service short link) | Expanded to the full invite URL in-app (shell-side fetch, cached) and rendered as an invite card. |
| Android / PWA | `openpgp4fpr:…` | SecureJoin/verification QR text. On Android the OS now offers Velta as a handler (registered intent-filter scheme). |
| Android / PWA | `dcaccount:https://nine.testrun.org/new` | Opens a chooser: add the relay to the current profile, or create a new chatmail account. Velta is registered for the raw `dcaccount:` scheme on Android (system chooser if other chat apps also handle it). |
| Android | `dclogin:…` | Chooser: add the (existing) relay account to the current profile. |
| Android | `DCBACKUP2:…` (second-device code) | Opens Velta's "Receive a profile" transfer flow directly. |
| Android / desktop | `velta://proxy…` (SOCKS5 setup, v1 or v2) | Shows the server, credential and trust warnings, then adds the proxy only after confirmation (see "SOCKS5 proxy"). |
| Desktop (Windows/Linux) | `velta://invite?url=<encoded i.delta.chat URL>` | Opens Velta and joins the 1:1 or group chat. |
| Desktop (Windows/Linux) | `velta://account?url=<encoded dcaccount URL>` | Opens Velta and offers the relay/new-profile chooser. |

### Invite link mirrors and invite cards

An invite link's payload lives in the URL fragment (`#FINGERPRINT&v=3&…`) and is never
sent to a server — the host is decorative. Velta therefore accepts any **registered
mirror domain** and normalizes the link onto the canonical `i.delta.chat` form before
handing it to the core (which only parses that scheme).

- **Registry** — built-in hosts (`i.delta.chat`, `i.gluek.info`) plus user-added ones,
  managed in the drawer under *Settings → Invite link domains* (stored in
  `localStorage["velta-invite-hosts"]`, logic in `app/js/invites.js`).
- **OS-level interception is compile-time** — Android intent filters live in
  `AndroidManifest.xml` and can only be changed by adding the domain there and
  rebuilding. The runtime registry covers everything inside Velta: OS deep links
  (already routed to the app), links tapped in chat messages, and pasted links.
- **Invite cards** — an invite link inside a message renders as a card instead of a raw
  URL: the main part reads *"Pavel invited you to a Chat RU group"* or *"Chat with
  Pavel"* (parsed from the link's own `n=`/`g=`/`a=` params) and asks for confirmation
  before joining; a copy icon on the right copies the original link.

</details>

<details>
<summary>Deep links on Windows: velta:// scheme, testing, limitations</summary>

### Why Windows needs a custom `velta://` scheme

Windows does **not** allow a normal desktop app to intercept a specific `https://` host like `i.delta.chat` — that power belongs to the default browser. So on Windows Velta registers a custom URI scheme (`velta://`) through `tauri-plugin-deep-link`. The first time the app runs it writes the registry entry for the scheme, after which the OS will launch Velta for any `velta://…` link.

### Wrapping an invite link for Windows

Take an official Android invite link:

```
https://i.delta.chat/#DD1FDB8A5621D4A89DE00542234A2D9967B07594&v=3&i=fbrK144cdHV&s=GI2Y07eCqylGp6j5J_QCZ1vz&a=0so6eoc9s%40d13.buro.dev&n=Pavel
```

Encode the part after `url=` and build a `velta://` link:

```
velta://invite?url=https%3A%2F%2Fi.delta.chat%2F%23DD1FDB8A5621D4A89DE00542234A2D9967B07594%26v%3D3%26i%3DfbrK144cdHV%26s%3DGI2Y07eCqylGp6j5J_QCZ1vz%26a%3D0so6eoc9s%2540d13.buro.dev%26n%3DPavel
```

Quick JavaScript helper:

```js
function toVeltaInvite(httpsUrl) {
  return "velta://invite?url=" + encodeURIComponent(httpsUrl);
}
```

Clicking that link will focus an existing Velta window or start a new one, show a progress modal, and run `secureJoin()` against the decoded invite.

### How it is implemented

- **Android** — `velta-app/src-tauri/gen/android/app/src/main/AndroidManifest.xml` declares `VIEW` intent filters for `https://i.delta.chat` and mirror domains (`i.gluek.info`; one filter each — add more there and rebuild to extend OS-level interception). The Rust layer emits the URL to the frontend as a `deeplink` event.
- **Windows/Linux** — `tauri-plugin-deep-link` registers the `velta://` scheme. `tauri-plugin-single-instance` (with the `deep-link` feature) forwards second-instance launches to the running window. The plugin emits a `deep-link://new-url` event that the frontend listens to.
- **Common frontend handling** — `app/js/app.js` has `extractJoinLink()`, `extractInviteLink()`, and `extractVeltaLink()`. They normalise every supported format and route it to either the SecureJoin flow (`joinFromInvite`) or the account-setup flow (`addAccountFromInvite`). Link recognition, mirroring, and the invite-card rendering live in `app/js/invites.js`.

### Testing locally

- **Android** — tap an `https://i.delta.chat/#…` link from any app. The system should offer to open it with Velta.
- **Windows** — after installing and running Velta once, open a `velta://invite?url=…` link from a browser address bar or a local HTML file. The app should open and show the join progress modal.

### Limitations

- Windows cannot intercept the official `https://i.delta.chat/#…` links directly. To make those links open Velta automatically on Windows, a browser extension that rewrites them to `velta://` URLs would be required.
- macOS deep links are configured in the same `velta://` desktop path, but they are currently untested.



</details>

<details>
<summary>Sending files, photos and videos</summary>

The composer has a paper-clip attachment button, and images can also be
**pasted from the clipboard** (paste a screenshot straight into the composer).
Both paths run through the same send-image flow: a preview with an optional
**caption** and a free-form **Crop** step (drag to move the selection, corner
handle to resize) before sending. Picking two or more photos in the gallery
sends each one immediately as its own message, with no caption strip. One
photo still stops in the strip. In the browser those photos are written
into the local core and sent the same way. The drawer's **Image quality** setting controls what happens to the images
you send: **Standard** compresses large photos down to 940 KB, **Compact**
down to 130 KB (smaller photos are sent unchanged either way). Compact keeps
uploads small and relay storage lasting longer. With **Compress photos to save relay
space** on (the default, same drawer section), big JPEG/WebP photos - and
opaque PNGs the core would recompress anyway - are re-encoded to lossy WebP
before sending when that makes them at least 10% smaller (or fit the limit
above); this also drops location/camera info from those photos. Small
photos, GIFs, animated or transparent images and files are never touched. From the attachment menu you
can send:

**Voice message** (not offered in local groups) records from the
microphone. A bar above the composer shows the time, **Cancel**, and
**Send**. The recording is sent as a voice message with the audio file
attached (m4a when the app can record it, otherwise ogg or webm).

| Type | How it is sent | How it is shown |
|---|---|---|
| Photo | `viewtype: Image` with the original file path | Rendered inline as an `<img>`. A landscape photo is shown whole; a portrait photo fills its frame. |
| Video | `viewtype: Video` | Rendered as a native first-frame preview; tapping plays it in a fullscreen lightbox (controls live there) |
| Voice | recorded in the composer, `viewtype: Voice` plus the audio file | Rendered inline as an `<audio controls>` element |
| Audio file | `viewtype: Audio` | Rendered inline as an `<audio controls>` element |
| Any file | `viewtype: File` | Shown as a file card with name, size and a download/open action |

Implementation files:

- `app/js/chat-view.js` — attachment menu, native file picker (`plugin:dialog|open`), media rendering and the download button.
- `app/js/rpc-core.js` — `sendMessage()`, `getMessage()` and `downloadFullMessage()` wrappers around the core JSON-RPC methods.
- `app/css/main.css` — styles for `.msg-image`, `.msg-video`, `.msg-audio` and `.msg-file`.

### How media is loaded

Real media blobs live in the Delta Chat account directory and cannot be reached by a `file://` URL from the WebView. `app/js/media.js` resolves paths through a three-tier chain:

1. **`blobfile://` custom protocol** (primary once boot-probed) — a Tauri URI-scheme handler in `lib.rs` serves account-dir-scoped blobs with real 206 range responses, no TCP listener. At startup the frontend loads a probe image through the scheme; a webview that never dispatches custom-protocol requests (WebView2's media stack can bypass them even when images through the same scheme load) keeps the legacy chain.
2. **Loopback media HTTP server** — `127.0.0.1` on an ephemeral port (the CSP allows `http://127.0.0.1:*`, so two Velta builds on one device never collide), random per-launch token compared in constant time and kept out of logs, account-directory-scoped, capped concurrent connections, real ranges. This is the probe-negative path and the one-shot per-element fallback: `<img>`/`<video>`/`<audio>` that fail on a blobfile URL swap to it once before showing an error placeholder. On Android this server remains what `<video>`/`<audio>` can always rely on, since the asset protocol there answers the first range read but fails mid-file ones, which kills demuxing of moov-at-end MP4s (most phone recordings). Cleartext is permitted app-wide (network security config) so user-opened http links render in the in-app browser; the SPA itself never navigates top-level and its CSP blocks plain-http subresources, so the shell's own cleartext traffic stays the loopback media server.
3. **Tauri asset protocol** — plain GETs (static assets) work everywhere.

Files are opened with `plugin:opener|open_path`. Video rows render a native `<video preload="metadata">` element — the browser decodes and paints the first frame directly (no extraction pipeline); the file size badge sits top-left, the duration bottom-right, and a centered play button is shown while paused.

### Video placeholder: first frame and badges

The video element loads metadata plus the first frame only (`src="…#t=0.1"`, `preload="metadata"`), so rows stay cheap inside the virtualized list; the real playback opens in the fullscreen lightbox on tap. If the media chain fails, the element falls back to the loopback media server once, then shows an error band.

### Downloading large messages

Delta Chat splits very large messages into a small placeholder plus a downloadable body. When a message has `downloadState` other than `Done`, Velta shows a card with a download icon instead of the media player. Tapping it calls `download_full_message(msgId)` and then refreshes the message, which swaps the placeholder for the real image / video / audio player or the open-file card.

</details>

<details>
<summary>Large files (Lufi, Cryptex)</summary>

On desktop, the attach menu's **Large file** encrypts the file on your
device the same way Lufi's web client does, uploads it to a Lufi server
(default `https://upload.disroot.org`, configurable) through your proxy if
one is set, and posts the name, size and a download link in the chat. The
decryption key is in the link's `#` part, so the server never sees it and
recipients without Velta can download it in any browser. You choose the
expiry within the server's limits and can make it burn after reading;
**Message info** keeps the deletion link with **Delete from server**. Not
offered in local chats.

**Cryptex** (since 1.4.87) is a second provider next to Lufi, picked in the
same menu: up to 1 GB per file, retentions from 30 minutes to 7 days,
upload through the app's proxy (the network runs shell-side, so the browser
build hides it), the password again in the link's `#` part — and the server's
page doubles as a web fallback that auto-fills the key, while Velta downloads
in one tap.

</details>

<details>
<summary>Media internals: size limit, caching, platform notes</summary>

### Attachment size limit

`Config::DownloadLimit` defaults to `0` (no automatic size limit), so the core normally downloads the whole message automatically. For outgoing attachments the Delta Chat core recommends staying below roughly **18 MB** of raw file data (around 24 MB after base64 encoding), defined by `RECOMMENDED_FILE_SIZE` in `deltachat-core-rust`. Velta does not enforce this itself; it just passes the file to the core.

`Config::MediaQuality` (`0` = Balanced, `1` = Worse) controls image compression on send, so the UI does not need to resize images before sending. The drawer's **Image quality** switch writes this config (Standard = Balanced, Compact = Worse).

### Media caching and chat switching

Switching chats is tuned to avoid redundant work: the rendered-message LRU
(`_rowCache` in `app/js/chat-view.js`) survives chat switches — reopening a
chat reuses its rendered rows instead of rebuilding them (it is only dropped
when the account changes, since message ids are per-account). A row that
is off screen releases its video and audio decoder and restores the same
source when it scrolls back, so a long session does not pile up players.
Media responses
are served `Cache-Control: max-age=31536000, immutable`: core blob names are
content-deduplicated, so the same URL always means the same bytes and the
WebView serves images from its cache instead of re-reading and re-decoding
them on every visit.

### Platform notes

- **Windows / desktop** — file pickers return real filesystem paths and everything works end-to-end.
- **Android** — the Tauri dialog may return a `content://` URI that the Delta Chat core cannot read directly. Velta copies picked files into the app’s local data directory using `tauri-plugin-fs` before passing an absolute path to `send_msg`.



</details>

<details>
<summary>Message formatting and replies</summary>

Message text renders a simple, escape-first markdown subset (`app/js/markdown.js`):

| Syntax | Result |
|---|---|
| `**bold**` | **bold** |
| `*italic*` / `_italic_` | *italic* |
| `__underline__` | underline |
| `[label](https://…)` | clickable link (bare URLs linkify too) |
| `- item` / `* item` / `+ item` | bulleted list |
| `1. item` / `1) item` | numbered list (a start value like `3.` is honored) |
| `` `code` `` | click-to-copy button (not a link, not emphasis, not a tag) |

**Enter sends** by default (Shift+Enter makes a newline; IME composition is
never swallowed). Turn the drawer's **Send on Enter** setting off and Enter
always inserts a newline instead — press **Ctrl/Cmd+Enter** to send (#56).

Messages whose original differs from the simplified bubble — the core's mail
simplifier cut a footer/quote (the text ends in `[...]`), or an HTML mail was
flattened to text — render a **Show Full Message…** button (the official
client's label). Tapping it loads the original body from the core
(`get_message_html`) and renders it in the same isolated viewer as HTML
attachments: a sandboxed iframe in an opaque origin, so scripts run but can
touch nothing of the app. Forwarded copies carry no stored original and get
no button. Remote images inside the mail stay blocked by default (the page
CSP applies inside the viewer) — nothing about you leaks to mail-embedded
trackers. Links inside the original mail open **outside** the viewer — in
your system browser on desktop, in the in-app browser on Android — instead
of replacing the message view.

Everything is HTML-escaped before any tag is produced and only `http(s)` targets become links, so message content can never inject markup. Emphasis markers are word-boundary guarded (`2*3*4` and `snake_case_name` stay literal). Invite links (`i.delta.chat` and registered mirror domains) render as invite cards instead of links — see [Deep links](#deep-links). Invites carrying a `b=` parameter are broadcast channels and render as *"Subscribe to ChannelName"* with a Subscribe confirmation instead of the group wording.

Hovering a message on desktop shows a small **Reply** pill along the bubble's right edge, with a **⋮** chip beside it. The pill stays visible while that bubble is on screen, then leaves with it. One click sets the reply (same pipeline as the menu's Reply) and focuses the composer. The pill is hidden on touch devices, in read-only chats, and during message selection — the ⋮ chip stays, and opens the same menu as right-click.

Right-clicking a bubble (desktop) or long-pressing one (phone) opens the message menu. On desktop it is a compact bar of chips anchored to the bubble — a row of quick-reaction emoji (the round smiley at its end opens the full searchable emoji tray) over labeled action chips — instead of a long vertical list. On a phone it stays the bottom sheet. Right-clicking or long-pressing **a link** targets that link: **Copy link** copies it with tracking parameters stripped (the same URL a click would open) and **Open link** opens it; on a phone there is also **Share link**. The phone sheet additionally offers **Show links**, listing every link in the message as real anchors — the WebView's own long-press menu (open / copy / share) works on each.

On a phone, swipe a bubble to the right to reply. The bubble slides a short way with your finger, and letting go far enough sets the reply and focuses the composer, the same as Reply in the menu. A short swipe snaps the bubble back. Swipe left on the message history to go back to the chat list: the chat screen follows your finger, the list shows underneath, and letting go far enough leaves the chat, the same as the back button. A short swipe snaps back. Scrolling up and down stays a scroll. A swipe that starts on a video poster or an invite card still replies or goes back, and the tap the phone fires afterwards does not play the video or join the invite. A video that is already showing its controls keeps the finger for scrubbing. A read-only chat can swipe back, and it does not swipe to reply. Neither swipe runs on desktop.

On a phone, long-press a bubble to open the message menu. That hold does not start the system's text selection. Choose **Select text** when you want the handles. The whole message starts selected, and the native handles shrink that span. **Reply**, **Copy**, and **Close** sit inside the bubble: Reply quotes just the selected text, Copy copies that span, and Close leaves the mode and dismisses the handles. While that bar is open, a long-press does not open the message menu. The desktop message menu has no Select text. Select with the mouse as usual; on desktop a small Reply chip quotes the selection (the floating chip is desktop-only — touch quotes through this Select-text flow). **Download** on an image, video, or file saves it. Android asks where to put the file. Desktop and the browser save it from the page.

Note: other Delta Chat clients render the core's markdown subset (bold, italic, strikethrough, code). Velta's backticks are a click-to-copy button, and the text inside is not parsed as a link, emphasis, or tag. Underline and lists are Velta-side rendering niceties — other clients show those markers literally.

</details>

<details>
<summary>Editing sent messages</summary>

Your own text messages can be edited after sending: long-press/right-click the
bubble and pick **Edit**. The composer switches to edit mode ("Editing
message" bar, ✕ cancels); Enter applies. Editing updates the message in place
for every chat member (the bubble shows an *edited* tag), reuses Delta Chat
core's edit delivery (a hidden edit message synced to recipients), and is
restricted to what the core allows: your own, plain-text, non-empty messages —
no attachments, captions, info or HTML mail bodies. P2P local chats don't
support editing yet.

</details>

<details>
<summary>Message ticks and resending</summary>

Outgoing messages show where they are in the pipeline:

- **Clock** — sending: your relay has not accepted the message yet (it also
  means "queued, retrying" while your relay is unreachable).
- **One check ✓** — your relay accepted the message. This is as far as the
  pipeline can be verified: chatmail is store-and-forward, and relays do not
  report onward delivery back to the sender.
- **Two checks ✓✓** — the recipient's client confirmed it has seen the
  message (read receipt).
- **Red !** — the send failed permanently; the bubble shows the reason and
  Retry/Remove actions. **Message info** (context menu) shows when it was
  sent and received, Seen and Encrypted, the database id, the Message-ID,
  and the server URL (one line per copy on the server). Each reaction is
  listed there, with the people who sent it. Tap a reaction to send the
  same one; tap your own reaction (highlighted) to remove it, and picking
  another emoji replaces it. Local chats have no reactions.

Long-press/right-click one of your own messages and pick **Resend** to push
the same message through the pipeline again — useful when the recipient says
nothing arrived. The message re-enters the sending state and the tick ladder
starts over; the core refuses to resend info messages or ones still in
flight. P2P local chats retry through their own engine instead.

</details>

<details>
<summary>Stickers</summary>

Stickers (Delta Chat's <code>Sticker</code> view type) render the way the
official clients show them: floating on the chat background without a bubble
around them, at a compact size. The composer's input field has a sticker
button on the right edge that opens a picker fed by the account's sticker
folder (the same mechanism as Delta Chat desktop — collections are folders
under the account's <code>stickers/</code> directory, shared with a desktop
install of the same account). Tap a sticker you received and Velta offers
to add it to your collection — like the official mobile clients; the
context menu's **Save sticker** adds it directly. In demo mode the picker
ships a few emoji placeholders.

</details>

<details>
<summary>Notifications</summary>

A drawer section carries the full set of notification switches:
**Notifications** (master), **Replies only** (skip the rest), **Show message content**, **System notification for new
messages**, **Calls**, and — on Android — **Vibration**, **In-chat sounds**,
**Use background connection** (the periodic background fetch; off means
messages arrive when you open Velta) and **Force background connection**
(asks Android for battery exemption so background fetching survives Doze).
Per-chat muting lives in each chat's info sheet. Incoming-message
notifications mirror the official client's conversation
layout on both mobile platforms:

- **Android** — real MessagingStyle conversations: group name as the title,
  sender name as the second line, plain message text below (never a
  "GroupName: text" prefix); the sender's avatar on the left, the chat
  avatar on the right; follow-up messages of one chat group into a single
  conversation instead of stacking cards. Built by the background event
  poller through a small Kotlin helper while the app is hidden. The page
  does not post a second card. Pressing
  Home often leaves the page marked visible and freezes it, so leaving the
  activity also wakes that poller, and a message already waiting in the
  frozen page is still notified. Since 1.4.50 the shell is the single
  reader of core events: the page stops its own long-poll and the Rust
  poller routes every batch itself — to the page while you are looking,
  to the notification system while you are not — and muted chats are
  skipped. A message sent while the app sits backgrounded therefore
  notifies within seconds of the OS unfreezing the process; a persisted
  15-minute scheduled fetch (`BackgroundFetchJob`) covers the frozen
  stretches even without a push distributor, and a push wake-up no longer
  waits out a half-open IDLE connection before fetching. The sync service
  holds no permanent wake lock (since 1.4.83), reconnects when the network changes, and fetches again when you
  return, nudges a reconnect every 10 minutes in the background unless push is delivering, and can start the core without the app's window (a push, job or alarm cold-starts it). With the screen off,
  Android Doze still suspends that network until you allow unrestricted
  battery use; Velta asks once, with a link to dontkillmyapp.com for your phone's maker.
- **Windows** — a toast with three text lines (chat name / sender / text)
  and the sender's avatar cropped circular, rendered via the same
  notification identity the installer registers. The toast is shown when
  the window is minimized or another window is in front, not only when the
  page reports itself hidden — a minimized window often still looks visible,
  which used to draw the message and skip the toast. For the identity to
  resolve, the app must have been installed through the installer at least
  once (PWA-in-browser and pre-install dev runs show no toasts).

1:1 chats show the sender as the title with just the message text.

**Tapping a notification opens its chat** — on Android (whether Velta was
running or not) and on Windows (while the app is running). If the message
belongs to another profile, Velta switches to it first; if the chat was
deleted meanwhile, the app just comes to the front.

**UnifiedPush (Android, groundwork):** if a UnifiedPush distributor app
(ntfy, NextPush, self-hosted — your choice, no Google) is installed (only one, or one set as default), Velta registers with it
automatically and uses the push channel to fetch messages the moment the
server announces them. **Settings → Push notifications** shows the current
state, lets you pick among several installed push apps or turn push off
(the choice sticks across restarts), tells whether your relay(s) confirmed
push support and when the last push arrived, and links to ntfy when no
push app is installed. The relay-side
notifier must support `webpush:` push tokens (stock chatmail deployments
with the notifier enabled do). The foreground service stays on for now, so
this is currently an instant-fetch booster rather than a battery saver.

**Web Push (browser PWA):** in the browser app, **Push notifications** in
the drawer has a switch "Notify me when Velta is closed". Turning it on asks
for notification permission and subscribes this browser; your relay then
pings it through notifications.delta.chat when mail arrives, and you get a
generic "New message" notification (no sender or text — the message is
fetched when you open Velta). No notification is shown while Velta is open
and focused. Turning it off unsubscribes the browser. On iPhone/iPad this
needs iOS 16.4 or newer and Velta added to the Home Screen (open it from
the icon, then turn the switch on). Needs a relay with push support.

</details>

<details>
<summary>Muting chats</summary>

Open a chat's info sheet and tap **Notifications** to quiet a chat or
channel: mute for 1 hour / 8 hours / 1 day / 7 days / forever — or
unmute. The ⋮ menu in a chat carries a quick **Mute / Unmute** toggle for
the same chat. Muted chats stay in the list and keep their unread badges;
they just stop making noise — including in background notifications while
the app is hidden (since 1.4.51 both mute paths also actually apply: a
wire-format bug silently discarded them before).
Since 1.4.78 one exception: an **@mention of you** in a muted chat still
notifies (drawer → Notifications → "Notify me when mentioned in muted chats", default on).
On desktop and in the browser app muted chats were not filtered from
notifications before 1.4.78; they now stay quiet unless you are mentioned.

</details>

<details>
<summary>Disappearing messages</summary>

Groups and 1:1 chats can be set to make messages disappear
automatically: open the chat info and pick **Disappearing messages** —
Off, or after 5 minutes / 1 hour / 1 day / 1 week / 5 weeks / 1 year.

The setting applies to **all members** of the chat (they can still copy,
save, and forward messages before expiry). Changing it posts a system
notice into the chat, so everyone is informed. Timers for incoming
messages start when the message is actually seen — an unread message
does not count down.

</details>

<details>
<summary>Groups and channels: members, invites, leave</summary>

Create a channel from the chat list's **+** menu (**New channel**): name it
and it opens. People subscribe with **Invite via link/QR**; members are not
picked when you create it.

The chat info sheet carries the per-chat actions:

- **Add members** (groups) — pick contacts from your address book; the
  group is informed automatically.
- **Members list** (groups) — collapsed behind a "Members (n)" summary;
  each row shows which **relay** the member is on (hover/long-press for
  the full address).
- **Invite via link/QR** (groups and channels) — share a secure-join
  invite: scanning or tapping it joins the group / subscribes to the
  channel, with end-to-end verification.
- **Media sections** — Apps, Photos, Videos, Audio and Files. Tapping a
  photo, video or app opens it; every tile and row has **Show in chat**,
  which jumps to and highlights that message. Audio rows (and audio
  bubbles in the chat) use Velta's own player: play, seek and
  "current / total", full width from the first render.
- **Admin groups** (since 1.4.88) — turn on **Admin group** in the New
  group dialog and you become the group's only admin: only you can add or
  remove members, change name, description, avatar, the disappearing
  timer and pins, and you can delete anyone's message for everyone. The
  info sheet shows "Moderated group · admin: X" and an Admin badge, and
  the admin's messages carry an **Admin** chip. Other members' Velta and
  ArcaneChat clients enforce the same rules; compatible with ArcaneChat
  admin groups.
- **Leave group / Leave channel** — in the chat's ⋮ menu. Mailing lists
  have no Leave. The chat turns
  read-only and stops receiving messages; the history stays on this
  device until you delete or archive the chat. Deleting a group or a
  broadcast channel from the chat list leaves it first, so the other
  members are told.

</details>

<details>
<summary>Diagnostics &amp; debugging</summary>

The pinned "Velta Diagnostics" chat collects startup, core and error
diagnostics in a screencap-visible console style — no adb or logcat needed.
Its action bar carries two switches: **Logging** freezes/resumes the shell
log (`velta.log`), and **DevTools** opens the WebView inspector on Windows
or enables remote debugging (`chrome://inspect` over USB) on Android. The
same bar offers a "Restart: Core | UI" recovery group and a pause/play
toggle that freezes the live log (events keep being recorded while paused).

</details>

<details>
<summary>One-click updates (Windows, macOS)</summary>

On Windows the drawer's update banner grows an **Update** button: one tap
checks the update feed, downloads and signature-verifies the new installer
(tauri-plugin-updater, minisign), runs it and relaunches the app — no browser,
no manual download. Progress shows on the button; the check gate is unchanged
(version.txt first, the signed manifest re-validated at install). Only
installs made through the NSIS installer can self-update; a bare
`velta-app.exe` copied somewhere still needs a manual installer run. macOS
updates the same way from the signed `Velta_<version>_universal.app.tar.gz`
(both architectures, one `latest.json` entry each). Android downloads the
APK inside the app — the banner button shows the download progress and then
hands the file to the system installer over Velta, no browser detour.

</details>

<details>
<summary>Deleting messages</summary>

Deleting a message (long-press / right-click → Delete) opens the same dialog as
official Delta Chat desktop. After you confirm, the bubble stays put and shows
"This message was deleted" with Undo. A bar along the bottom of Undo runs for
10 seconds; the deleted bubble keeps its height meanwhile, so nothing
jumps, then collapses smoothly to a compact "Message deleted" row (no
animation with reduced motion).
Undo puts the original bubble back. **Right-click a chat in the chat list → Delete
old messages…** bulk-deletes a whole chat's history older than a chosen age
(1 hour / 1 day / 1 week / 5 weeks / 6 months / 1 year); pinned messages are
kept. The same cleanup lives in the chat info sheet under **Old
messages**, next to the **Storage** row (which shows the chat's total
attachment size and recounts after a cleanup):

| Action | What happens |
|---|---|
| **Delete for me** | Removes the message on this device and deletes it from the relay's storage. Other members keep their copy. |
| **Delete for everyone** | Also asks every chat member's device to delete the message. The core sends a hidden, encrypted deletion request (`Chat-Delete` header) that other Delta Chat clients honor. |

"Delete for everyone" is only offered when the core can support it: the
selected messages must be **your own** and **end-to-end encrypted**, and the
chat must not be Saved Messages. Deleting for everyone is a request — members
running clients without deletion support will keep their copy.

Related indicator: encrypted chats show no lock icon (e2e is the default).
Unencrypted 1:1 chats — classic-email contacts that chatmail relays cannot
encrypt to — are marked with a small open-shackle lock in the chat list and
chat header instead.

</details>

<details>
<summary>Reply threads</summary>

When messages quote a bubble, that bubble counts its replies. On a phone the
count ("2 replies") sits next to the time; on every screen a small round
button with a reply icon and the count sits beside the bubble, including
on a phone where the row would otherwise wrap it underneath. Tap it (or
choose **Show replies** in the message menu) to open the thread panel: a
sheet over the lower part of the chat with the original message on top and
every reply beneath. The composer stays visible and replies into the
thread. Close the panel with its X, Escape, or by switching chats.
Editing a message's text or caption does not add a reply to the count. See
[docs/reply-threads.md](docs/reply-threads.md).

</details>

<details>
<summary>Chat list: Unread chip</summary>

The category bar above the chat list has an **Unread** chip that shows
unread chats of every kind. Hide it like the other chips; it is part of the
swipe cycle between categories.

</details>

<details>
<summary>Reading chats: unread position, read marker, go-down</summary>

Opening a chat no longer marks everything read. The chat opens at a stored
**"Read up to here"** marker when unread messages remain below it, otherwise
at the first unread message (marked with an "Unread messages" line),
otherwise — for a fully read chat you had scrolled through — at the exact
position you left it, and otherwise at the newest message.

- **Seen = on screen.** Messages count as read — and read receipts go out —
  only once they actually scroll into view. Read partway and switch away,
  and the rest of the chat keeps its unread badge. Nothing is marked read
  while the app is in the background. The drawer's **Show and send read
  receipts** switch turns receipts off entirely (off also stops
  seen-status sync between your own devices).
- **"Read up to here"** — a marker saved on this device still reopens the
  chat at that dashed line, and the ✕ on the line still removes it. The
  message menu does not set a new marker. The marker lives on this device
  only.
- **Go-down button** — shows when you are scrolled away from the newest
  message and carries the count of unread messages below. Tapping it
  catches up: everything is marked read and you land on the newest
  message.

Local (nearby) chats keep the old behavior: opening marks them read.

</details>

<details>
<summary>Webxdc mini-apps (beta)</summary>

Messages containing a `.xdc` mini-app render as an app card — the app's
icon (or a letter tile with the app initial when the app ships none), the
app's name and summary from its manifest, and a Start button; tap the card to open
the app in a full-screen overlay (opaque-origin sandbox, close button in the
title bar). The iframe runs **without** `allow-same-origin`, so every app
document gets a unique opaque origin: mini-apps can reach neither the host
page nor each other's data, and the injected shim backs
`localStorage`/`sessionStorage` with memory in that origin (app state
syncs to every chat member through end-to-end encrypted status updates,
and the relay's STUN/TURN servers power the connection). The app frame is
themed to match the shell (dark canvas, dark scrollbars), but the app's
own document keeps the web default light scheme unless the app sets its own
`color-scheme` (as in Delta Chat), so apps that paint only a white
background stay readable. `sendToChat` (including file export to a chat)
and the file-picking `importFiles` are wired, and so are realtime
(low-latency) channels via `webxdc.joinRealtimeChannel()`.
`setUpdateListener` stays subscribed and replays stored updates, so apps
such as polls keep their state on reopen and see live votes. Info messages
an app posts (`sendUpdate({info})`) show the app's icon in the chat; tapping
one opens the app at the update's `href`.

**In the browser/PWA** mini-apps run too: the service worker hands the app
frame a loader page under an opaque-origin sandbox, which unpacks the
`.xdc` inside the sandbox; the app gets no network access. Realtime
channels aren't available there yet, so Velta Beam shows "direct transfer
is not available in the Velta web app yet".

**Velta Beam** (formerly "Send directly"). The attach menu's **Velta Beam** posts a
built-in mini-app that sends a file peer-to-peer over the realtime channel
(chunked, re-requested on loss, SHA-256 checked) to everyone who opens it
while the sender is online. The file never goes through the relay.
It opens as a panel directly below the chat header (the chat stays usable
underneath; ⤢ expands to full screen, ✕ closes), and the sender sees each
receiver's progress ("N receivers", a percent bar per person, "done" once
the checksum is verified).
In a group everyone who opens Beam can receive, and whoever already has the
file passes it on: each piece is checked on arrival (per-piece SHA-256 for
files up to ~96 MB), so even a partial download helps others, and someone
who opens Beam after the sender closed it can still get the file from any
member who has it open ("Shared by Ann, Bob"). Copies live in memory, so at
least one holder must have Beam open.

Velta Beam and Velta Circle follow the Velta design system (dark and light,
WCAG AA contrast). Opened outside Velta (e.g. in Delta Chat) they show one
quiet line pointing to velta.cc — never a popup.

</details>

<details>
<summary>Bot commands</summary>

Messages from bots render their slash commands as tappable chips right in
the bubble — tap one and the command lands in the composer, ready to send.
Works for any bot chat; the chips are extracted from the bot's own message
text, so nothing needs to be configured per bot. Every bubble a bot sends
also carries a small bordered **bot** tag next to the timestamp, so bot
messages are distinguishable at a glance.

Typing `/` in the composer opens a popup of the commands you sent recently in
that chat (or across the profile when the chat has none yet); arrow keys and
Enter/Tab insert one without sending it. The attach menu's **Commands**
lists the same commands and inserts one the same way. **Apps** lists
mini-apps you sent or opened recently on this profile, and **Browse apps…**
loads a webxdc catalog. You can add more catalog addresses; if one does not
answer, the next is tried. A download is sent into the chat only when it
is a real `.xdc`.

</details>

### Device messages in Velta's voice

The device chat ("Device Messages") speaks as Velta, not Delta Chat: its
description, the update reminder and the occasional "enjoying" note are
Velta texts, and a new profile gets one Velta welcome message (what Velta
adds on top of chatmail) instead of Delta Chat's welcome photo and text.
Profiles that already existed are left as they are.

## UX (design decisions)

<details>
<summary>Identity avatars &amp; contact profiles</summary>

Every **user** avatar renders a deterministic **color matrix** derived from the
contact's OpenPGP fingerprint: an equal-height 4-row grid (3 squares, 2 rects,
2 rects, 3 squares — one cell per fingerprint group), with a fingerprint glyph
centered on a soft-black badge for photo-less contacts, and the contact's photo
as a padded rounded square (with a thin dark ring) for contacts that set one.
The grid follows the key's fingerprint lines, so the same person looks the
same on desktop and in the browser. Hex in a display name does not change
the tile. A contact with no key yet (or your own profile before it has an
address) is the same pattern in greyscale.
Neighboring cells never share similar hues, all colors are soft (no pure
black/white), and everything is drawn as pure SVG in `app/js/avatar.js` —
painted as a CSS background image per tile (one cached image per fingerprint,
no inline SVG subtrees), so it stays sharp at any size without costing DOM.
On desktop, resting the pointer on a custom photo in the chat header or the
profile sheet fills that tile, the same way a photo on a message does.
Initials and fingerprint tiles stay as they are.

Tapping any avatar in a chat opens the **contact profile** modal: the large
photo avatar beside the captioned identity tile (color names included), the
contact's address and profile key (OpenPGP fingerprint), last-seen info, plus
**Send message**, **Edit name** and **Block** actions. Group chats also show a
**Chats in common** section. Open it to list the groups you share with that
contact. The list is not built when the profile opens, so a large account
does not stall on the avatar tap.

Group avatars intentionally keep a solid color with a full-bleed photo or
initials — the identity matrix is a per-contact feature.

**Verified badge.** A blue rosette next to a contact's name (chat header,
profile sheet) means Delta Chat key-contact verification: you hold their
verified key from a **secure-join QR handshake** — scanned directly, or
introduced by a verifier you already trust (shown as "Verified" in the
profile). The rosette appears once the chat head hydrates the contact
(`refreshChatHeadPresence`), and the profile sheet's Verified row and
"Chats in common" stay the place to inspect the details. It is deliberately
absent from bare chat-list rows: verification is a per-contact property the
chat-list payload does not carry, and hydrating a contact per row would cost
an RPC each. Contact verification is a 1:1 concept — group protection status
is a separate core feature the JSON-RPC chat types don't expose yet.

**Brutal theme** (Settings → Theme → Brutal). A third, always-dark theme
built on neobrutalism principles and translated to Velta's token set — no
React/TypeScript, just a `html[data-theme="brutal"]` block in `main.css`:
flat panels with 2px ink borders, hard offset shadows, small radii, hover
press-down, and a vivid main yellow for selected rows and outgoing bubbles
(ink text on yellow, with dedicated quote/blockquote/meta colors). Like
every Velta theme it avoids pure black and pure white. Being explicit, it
never participates in the Auto (system) switch.

**Chat-list action bar.** The bottom bar in the chat list switches what the
list shows: **Chats** (default), **Contacts** (tap to open the chat),
**Calls** (recent calls on this device), **QR** (your invite code rendered
in place of the list, with **Copy a link** and **Share a link**; on phones a second
**Scan a QR code** tab scans other people's codes), **+** (new chat, group,
channel, or join-via-link) and **Menu** (settings drawer). The header search button
works the same way — it opens a live chat-name search in place of the list
and flips to a cross to close. The search screen has two tabs — **Search**
and **Archived (n)** — and the button always lands on Search. The Archived
tab lists the folder in place of the list; writing a message from an
archived chat moves it back to the main list. The core keeps no call log — calls exist only
as call messages — so the Calls view lists calls ended on this device,
recorded locally and capped at 30. Every view button can be hidden in
Settings → Bottom bar buttons; the Menu and + buttons are always visible,
and when all view buttons are hidden the bar's background turns transparent.
The list renders contact rows through a virtual scroller, so large address
books don't inflate the DOM.

**History loading strip.** While a chat's history loads — opening it or
paging up to older messages — a thin blue gradient sweeps left-to-right just
under the chat header (relay-blue, the same family as the status strip). It
stays on for at least 150 ms so fast loads still register, a new load cancels
a pending fade so back-to-back pages read as one strip, and it is disabled
under `prefers-reduced-motion`.

**Avatar shimmer placeholders.** Photo avatars (contact photos and custom
group photos) show a soft skeleton sweep while their bytes are in flight;
the sweep rides as the image's own background, so it costs zero extra DOM,
disappears the instant the photo decodes, and cached avatars skip it
entirely. Same soft-grey family as the loading strip, disabled under
`prefers-reduced-motion`.

**Times are 24-hour** (`03:21`, never `03:21 AM`) regardless of device
locale; relative times ("last seen", call lists) stay humanized.

</details>

<details>
<summary>Theming and accessibility</summary>

The palette avoids pure black and pure white everywhere — whites live in the `#f2f2f5`/`#f4f4f4` family and blacks in the `#0b0b10`–`#1c1c26` family (the avatar identity tiles already followed this rule). Text and surface pairs are held to **WCAG AA (≥ 4.5:1 contrast)**, measured with the WCAG relative-luminance formula after compositing any translucent layers:

| Pair (dark theme) | Contrast |
|---|---|
| Body text `#f2f2f5` on app background `#0f0f14` | 17.1 : 1 |
| Bubble text on incoming bubble `#1c1c26` | 15.1 : 1 |
| Bubble text on outgoing bubble `#2b5278` | 7.3 : 1 |

Reply quotes use a dedicated palette per bubble and theme (the generic accent/dim colors measured as low as 2.08 : 1 on the blue outgoing bubble): the quote name and text now measure **5.2 – 7.0 : 1** in every theme/side combination. When introducing a new color, composite it over its real background (rgba layers included) and check the ratio before merging.

</details>

<details>
<summary>Known limitations</summary>

- **In-app browser (Android)** — message links open without leaving Velta, through a three-step chain. (1) A Chrome Custom Tab using your real browser session: the tab is launched from the Activity context (launching from the application context crashed on a missing `FLAG_ACTIVITY_NEW_TASK` — modern androidx stopped adding it) and targets an explicit provider, chosen by your default browser first (since 1.4.14: if your default browser can host a Custom Tab it is used, so links no longer land in a non-default browser like Chrome Dev just because it sorts earlier; previously any visible `CustomTabsService` provider was picked by package order, with `CustomTabsClient.getPackageName` as backup) — a bare intent would resolve like `ACTION_VIEW`, so devices whose default browser has no Custom Tabs support (e.g. vivo.browser) opened a full browser task instead. (2) Devices with no provider at all get a native second-`WebView` overlay (`openWebView`, driven by the `open_webview_browser` command): a fullscreen in-app browser with a dark bar (host, open-external, close), BACK-driven history, JS + domStorage on, file/content access off and no bridges exposed. Being a top-level browsing context it is immune to X-Frame-Options, and plain-http sites render (cleartext permitted — see media notes). (3) Only old shells fall back to the JS iframe overlay. The overlay's sandboxed iframe cannot show sites that send X-Frame-Options / frame-ancestors (Chromium blocks with `net::ERR_BLOCKED_BY_RESPONSE`) — the bar's external-open button is the escape hatch. The Custom Tab class (`org.velta.InAppBrowser`) is cached as a JNI global ref at startup (`setApplicationContext` in `lib.rs`) because `find_class` for app classes is unreliable from Rust worker threads. The page title in the overlay is fetched separately by the shell (`fetch_page_title`, 5 s timeout, 256 KB cap).
- Group creation, contact discovery, QR invites, and real-time message rendering all work in basic flows but have not been stress-tested.
- Logging to `velta.log` is disabled in the stable branch; use the status pill and browser/Tauri dev tools to diagnose issues.
- On Windows, the app needs the sidecar binary to talk to the real core. If the sidecar fails to start the frontend falls back to the mock core.
- On Android, the in-process core rides a built-in foreground service (`CoreService`): messages keep syncing and arrive as conversation notifications while the app is backgrounded, including after Home — see [Notifications](#notifications). Screen-off delivery still needs the unrestricted-battery prompt. Since 1.4.50 a persisted 15-minute scheduled fetch also wakes the core when the OS freezes the backgrounded process (up to that cadence, deliveries wait for the next app open or a push wake-up; installing a UnifiedPush distributor restores instant delivery).

</details>

## Privacy &amp; security

<details>
<summary>Privacy: zero analytics &amp; telemetry</summary>

Velta ships **zero analytics, telemetry, or crash reporting** — verified
against the codebase: the frontend's only network calls go to loopback helper
services on your own device, and the Delta Chat core talks exclusively to the
chatmail relays you configure (that is the messaging itself; calls use the
relays' STUN/TURN when needed). If you opt into a SOCKS5 or WebSocket
proxy, that traffic goes through the proxy server you selected.
There is no update-check, no usage tracking, and no crash uploader. One installer-level exception: on Windows, a machine
missing the WebView2 runtime fetches it via Tauri's install bootstrap — that
is the installer, not the app, and it sends nothing about you.

</details>

<details>
<summary>Chat-open freeze fix (1.4.90)</summary>

Opening or switching chats could hang for 30 s or longer, especially with a
saved DNS tunnel whose server was unreachable: restarting mail connections
held a lock that every chat request waited on. 1.4.90 starts and stops mail
connections without that lock, runs DNS-tunnel work off the UI thread, and
no longer stacks repeated requests when you re-tap a chat. A regression test
with the real core runs in CI on every core change.

</details>

<details>
<summary>Profile data encryption &amp; app lock (since 1.4.89)</summary>

**Android:** each profile's message database is encrypted at rest
(SQLCipher) with a key in the Android Keystore (StrongBox when present).
Existing data is migrated once at startup (verified copy, atomic swap, old
file kept until the new one is proven).

**Desktop and browser (PWA): preview.** The same database encryption exists
there (key in the OS keychain, or behind a passphrase/passkey in the
browser) but is not final yet.

**Attachments are not encrypted yet** — work in progress. Until then they
rely on the platform's app isolation and disk encryption.

**Privacy & security** (side drawer, desktop and Android apps) gathers the
lock settings for the whole app, not per profile:

- **App-lock PIN** (desktop, Android, PWA) — 6+ characters; Velta asks for
  it at every start. The PIN replaces the keychain/Keystore as the key's
  root (Argon2id), with growing delays after wrong attempts.
- **Biometric lock** (Android 9+) — fingerprint/face, and on Android 11+
  also the phone's screen-lock PIN, pattern or password, so phones without
  enrolled biometrics can use it. It can be combined with the Velta PIN
  ("Use PIN" on the lock screen).
- **Lock when hidden** — off / 1 / 5 / 15 minutes.

The screen also shows what protects attachments today (Android
file-based encryption; on desktop whether BitLocker/FileVault is on).
Lose the PIN and the keychain/Keystore and the data cannot be opened —
keep a backup.

</details>

<details>
<summary>HTML attachments (isolated in-app rendering)</summary>

HTML files sent into a chat open **inside Velta, isolated**: the attachment
renders in a sandboxed iframe with no `allow-same-origin`, so its scripts run
in an opaque origin that cannot touch the app, your sessions, or cookies
(links inside are inert by design — the sandbox blocks popups and top-level
navigation). The viewer is themed to match dark/light via an injected
`color-scheme`, and the file is never copied to a temp file or opened in the
system browser.

</details>

<details>
<summary>Content Security Policy</summary>

Both delivery paths ship a restrictive CSP rooted in `default-src 'self'`:
the Tauri shell injects it as a response header (`tauri.conf.json` /
`tauri.android.conf.json`), and `app/index.html` carries the same policy as a
meta tag for the browser/PWA path, where no Tauri header exists. Scripts are
strictly same-origin — no inline scripts, no `unsafe-eval`; the pre-paint
interface-scale and chat-appearance snippets are external files
(`app/js/ui-scale.js`, `app/js/chat-appearance.js`) for exactly that reason. `img-src`/`media-src`/`frame-src` open only the app's own media
surfaces: the `blobfile:` custom protocol, the loopback media server, and the
opaque-origin `webxdc:` sandbox. The three policy copies must stay in sync
when origins change.

</details>

<details>
<summary>License</summary>

See [`LICENSE`](LICENSE).

</details>

## Under the hood &amp; building

<details>
<summary>Core upgrades</summary>

The Delta Chat core is vendored in `core/` and consumed three ways: as the
Windows sidecar binary, as the in-process library inside the Android APK, and
as the prebuilt `deltachat-backend/` servers used by the PWA/test rig. The
frontend talks to it over one integration point (`app/js/rpc-core.js`), so a
core change can surface as frontend symptoms (event storms, re-render churn)
rather than clean errors. [COREUPDATE.md](COREUPDATE.md) is the step-by-step
upgrade plan: the RPC/event contract to preserve, offline gates, live and
two-account checks, the event-storm regression pass, device checks, and
rollback rules. What each core release gives Velta — the new features rated
by value with their integration notes — lives in
[CORE-CAPABILITIES.MD](CORE-CAPABILITIES.MD).

</details>

<details>
<summary>Project layout</summary>

```
.
├── app/                        # Velta web frontend (vanilla JS, no build)
├── velta-app/              # Tauri 2 wrapper for Windows + Android
│   ├── soar-tunnel/            # archived DNS-tunnel library (CI build only)
│   └── src-tauri/
│       ├── Cargo.toml          # Rust crate + deltachat-jsonrpc dependency
│       ├── tauri.conf.json     # shared Tauri config
│       ├── tauri.android.conf.json
│       ├── tauri.ios.conf.json
│       ├── gen/android/        # generated Android project
│       └── src/
│           ├── lib.rs          # sidecar + Android in-process core glue
│           ├── p2p.rs          # local chat engine (iroh QUIC pairing + 1:1 chat)
│           ├── proxy.rs        # saved SOCKS5 proxies + shared proxy_url keeper
│           ├── bin/p2p-hub.rs  # headless terminal hub (debug helper)
│           └── main.rs         # Tauri entry point
├── deltachat-backend/          # Prebuilt deltachat-rpc-server binaries
│   ├── windows-x86_64/
│   └── android-arm64/
├── docs/pwa-self-host.md       # host your own wasm PWA; clone branch pwa-dist
├── tools/                      # icon generation, WSL APK build/sign helpers,
│                               # serve-dev.py (no-cache static server for app/)
├── signing/                    # local signing keystore (untracked)
└── core/                       # Vendored Delta Chat core Rust workspace
```

</details>

<details>
<summary>Libraries &amp; dependencies</summary>

The runtime has exactly **two vendored JavaScript libraries** — everything else
in `app/js/` (markdown renderer, avatar matrix, invite parsing, diagnostics)
is hand-rolled for Velta.

| Library | What it does here | Upstream |
|---|---|---|
| [Elena](https://github.com/arielsalminen/elena) (`@elenajs/core` v1.0.1) | Tiny progressive web-components library — powers `<velta-avatar>`, `<velta-chat-item>`, `<velta-chat-head>`, `<velta-video>` | [arielsalminen/elena](https://github.com/arielsalminen/elena) |
| [virtual-scroller](https://github.com/catamphetamine/virtual-scroller) (`virtual-scroller-dom`) | Windowed rendering of the message history with variable-height rows, seamless prepends and scroll restoration | [catamphetamine/virtual-scroller](https://github.com/catamphetamine/virtual-scroller) |
| [Tauri 2](https://github.com/tauri-apps/tauri) | Desktop/Android shell, deep links, sidecar process | [tauri-apps/tauri](https://github.com/tauri-apps/tauri) |
| [Delta Chat core 2.66.0](https://github.com/chatmail/core) | The messaging engine (Rust): contacts, chats, e2e crypto, IMAP/SMTP | [chatmail/core](https://github.com/chatmail/core) |
| [soar](https://github.com/getlantern/soar) v0.2.0 (Go) | Archived DNS-tunnel library, still built by CI but no longer used by the app | [getlantern/soar](https://github.com/getlantern/soar) |

Both JS libraries are vendored under `app/vendor/` (no bundler, no `node_modules`
at runtime). UI icons are individual SVGs from [SVG Repo](https://www.svgrepo.com/).

</details>

<details>
<summary>Requirements</summary>

- Rust **1.89+**
- Node.js **22+** (only for the Tauri tooling)
- `cargo-tauri` v2

```bash
cargo install tauri-cli --version "^2.0" --locked
```

### Windows build

- Windows 10/11
- For building the sidecar from source: Perl + NASM (needed by vendored OpenSSL in `rusqlite`).
- **Encoding:** all repo files are UTF-8 without BOM. On Cyrillic-locale Windows the
  ANSI codepage is CP1251, and PowerShell 5.1 / `cmd` redirection using the default
  encoding silently corrupts non-ASCII (`—` → `вЂ”`, `…` → `вЂ¦`, emoji → `рџ…`). Always
  pass `-Encoding utf8` explicitly (and beware `Set-Content -Encoding UTF8` writing a
  BOM — see AGENTS.md §6.2), or write from WSL. If you ever see stray Cyrillic in
  English prose, fix the write path — never just the characters.

### macOS build

- macOS with the Xcode Command Line Tools (`xcode-select --install`); full Xcode is not needed.
- For a universal build: `rustup target add aarch64-apple-darwin x86_64-apple-darwin`.
- The sidecar builds from the vendored core with the system Perl — no extra tools.

### Android build

- Android SDK + NDK r27 (e.g. `ndk;27.2.12479018`)
- JDK 17
- Targets installed via rustup:
  `aarch64-linux-android`, `armv7-linux-androideabi`, `i686-linux-androideabi`, `x86_64-linux-android`
- Optional: Go 1.25+ for the archived DNS-tunnel library
  (`velta-app/soar-tunnel`). CI still builds `libsoartunnel.so` into
  `gen/android/app/src/main/soarLibs/`; the app no longer loads it.

#### WSL-only NDK note

If you install the NDK inside WSL (e.g. `~/android/sdk/ndk/r27c`) make sure the extracted NDK preserves symlinks. Python's `zipfile` module strips symlinks by default, which breaks the LLVM toolchain. Extract the NDK zip with a symlink-aware tool such as `unzip` or a small Python helper that checks `zipfile.ZipInfo.create_system == 3` before writing entries. After extraction verify that toolchain binaries like `toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android24-clang` resolve correctly.

</details>

<details>
<summary>Build locally</summary>

### Windows installer

Build the sidecar first:

```bash
cd core
cargo build -p deltachat-rpc-server --release
```

Stage it for Tauri:

```powershell
New-Item -ItemType Directory -Force -Path "velta-app/src-tauri/binaries"
Copy-Item "core/target/release/deltachat-rpc-server.exe" `
  "velta-app/src-tauri/binaries/deltachat-rpc-server-x86_64-pc-windows-msvc.exe"
```

Then build the installer:

```bash
cd velta-app
cargo tauri build
```

Output:

- `velta-app/src-tauri/target/release/bundle/msi/*.msi`
- `velta-app/src-tauri/target/release/bundle/nsis/*.exe`

### macOS app

Build the sidecar for your Mac's architecture and stage it under the
target-triple name Tauri's `externalBin` expects (see
`tauri.macos.conf.json`), then build the bundle:

```bash
cd core
cargo build -p deltachat-rpc-server --release --locked
cd ..
mkdir -p velta-app/src-tauri/binaries
cp core/target/release/deltachat-rpc-server \
  "velta-app/src-tauri/binaries/deltachat-rpc-server-$(rustc -vV | sed -n 's/^host: //p')"
cd velta-app
cargo tauri build --bundles app,dmg     # add --target universal-apple-darwin for both archs
```

Output: `velta-app/src-tauri/target/release/bundle/{macos,dmg}/`. The bundle
is ad-hoc signed (`signingIdentity: "-"`); building on the same Mac needs no
quarantine removal. For a universal build, stage
`deltachat-rpc-server-universal-apple-darwin` made with
`lipo -create` from the arm64 and x86_64 sidecars (as `build-macos.yml`
does). `createUpdaterArtifacts` needs `TAURI_SIGNING_PRIVATE_KEY`; without
it, pass `--config '{"bundle":{"createUpdaterArtifacts":false}}'`.

### Releases via GitHub Actions

The `Release` workflow (`.github/workflows/release.yml`) builds both artifacts
and publishes them as a GitHub release. It runs on every `v*` tag push and can
also be triggered manually from the Actions tab (it then creates the matching
tag itself). The release assets are named after the version in
`velta-app/src-tauri/Cargo.toml` — the single source of truth (bump with
`node tools/bump.mjs <version>`, which mirrors it into `tauri.conf.json` —
the tauri-cli Android build reads only the conf field for
`tauri.android.versionName/Code`, so a missing conf version ships the APK
as versionCode 1 / versionName "1.0", the v1.4.58 regression):

- `Velta-<version>-<abi>.apk` — signed Android APK (`build-android.yml`)
- `Velta_<version>_x64-setup.exe` — NSIS Windows installer (`build-windows.yml`),
  plus its `Velta_<version>_x64-setup.exe.sig` updater signature
- `latest.json` — Windows self-update manifest (installer URL + signature, fed
  to `tauri-plugin-updater`). Must stay the **last** asset uploaded: it lives
  at `releases/latest/download/latest.json` and points at the installer in the
  same release — a manifest visible before its installer bricks that update
  cycle.
- `version.txt` — just the version. Apps fetch
  `releases/latest/download/version.txt` at startup and, when it reports a
  newer version than the running build, show an update banner at the bottom
  of the drawer plus a subtle pulsing highlight on the drawer's menu button
  (1.4.14+). Windows 1.4.20+ turns the banner button into a one-click
  **Update** (see above); Android keeps Download APK.

**Release changelog**: the release body is generated automatically — a
"What's changed in Velta <tag>" heading, the user-facing conventional
commits since the previous tag (feat/fix/perf/refactor/revert only;
chore/docs/ci/test/style/build are skipped), plus a compare link — macOS
install notes are appended.

**Changelog feed**: after a tag release publishes successfully (both builds
+ the GitHub release), the `Release` workflow posts a notification to
`ntfy.gluek.info/velta_changelog` — title `What's changed in Velta
<version>`, body = the same filtered changelog minus the compare link plus
a "Download" link to the tag (passed to the notify job as a
workflow artifact), `Velta` + `robot` tags. Builds run only on `v*` tag
pushes (or manual dispatch);
ordinary branch pushes don't build anything. `build-windows-cross.yml`
(Ubuntu sidecar cross-compile build) is manual-dispatch only as well.
Do not add per-job `concurrency` blocks to `build-android.yml` /
`build-windows.yml`: inside a reusable-workflow call `github.job`
evaluates empty, so both calls collapse into one concurrency group and
cancel each other (that is what silently killed the 1.4.6–1.4.8
releases). Serialization belongs to the calling workflow.

APKs are signed with the persistent release keystore stored in the repo
secrets (`ANDROID_KEYSTORE_B64`, `ANDROID_KEYSTORE_PASSWORD`,
`ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`), so every build upgrades in
place over the previous one. Without the secrets (forks/PRs) the workflow
falls back to an ephemeral key and warns — those APKs must not be published.

### Android APK (arm64-v8a phones)

```bash
cd velta-app
cargo tauri android build --apk --target aarch64
```

On this workspace the build runs inside WSL via `build-velta-android-wsl.sh`
(in the parent directory) — it needs **~25 GB free on C:** (the WSL disk is a
file on C: and cannot grow when the drive is full) and exports `RANLIB`/`AR`
pointing at the NDK's `llvm-ranlib`/`llvm-ar`, which openssl's install step
requires (see AGENTS.md §4.3.3).

The unsigned APK will be in:

```
velta-app/src-tauri/gen/android/app/build/outputs/apk/arm64-v8a/release/
```

To sign it locally:

```bash
keytool -genkey -v -keystore velta-debug.keystore -alias velta \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass velta123 -keypass velta123 -dname "CN=Velta"

zipalign -p -f 4 app-arm64-v8a-release-unsigned.apk app-arm64-v8a-release-zipaligned.apk

apksigner sign --ks velta-debug.keystore \
  --ks-pass pass:velta123 --key-pass pass:velta123 \
  --out app-arm64-v8a-release-signed.apk \
  app-arm64-v8a-release-zipaligned.apk
```

Add `--split-per-abi` if you need separate APKs for other architectures.

</details>

<details>
<summary>GitHub Actions</summary>

Pre-configured workflows live in `.github/workflows/`:

| Workflow | What it builds |
|---|---|
| `build-android.yml` | arm64-v8a Android APK on `ubuntu-latest`. Manual runs default to `org.velta.test` / Velta Test so the APK installs beside the main app; release tags keep `org.velta`. Input `side_by_side=false` builds the normal id. |
| `build-windows.yml` | Windows installer on `windows-latest`, compiling the sidecar natively (needs Perl + NASM) |
| `build-macos.yml` | Universal macOS `.app` + DMG + updater tarball on `macos-14`, sidecars for both architectures merged with `lipo`; ad-hoc signed (Developer ID signing/notarization switch on via the `APPLE_*` secrets) |
| `wasm-core-opt-in.yml` | WebAssembly core for the PWA (`packages/velta-wasm`): artifacts `wasm-dist-no-opt` and `dist-pwa` |
| `build-windows-cross.yml` | Windows installer where the sidecar is cross-compiled on Ubuntu to avoid installing Perl/NASM on Windows |

The Android and cross-compiled Windows workflows are the easiest starting points if you just want an artifact.

</details>
