use std::fs::OpenOptions;
use std::path::{Path, PathBuf};
#[cfg(not(target_os = "android"))]
use std::sync::Arc;
use std::sync::Mutex;

#[cfg(not(target_os = "android"))]
use std::io::{BufRead, BufReader};
#[cfg(not(target_os = "android"))]
use std::process::{ChildStdin, Command, Stdio};

#[cfg(windows)]
use std::os::windows::process::CommandExt;

#[cfg(windows)]
const CREATE_NO_WINDOW: u32 = 0x08000000;

use tauri::{Emitter, Manager, State};

// Public so the p2p-hub debug example can drive the engine headlessly.
pub mod p2p;
mod proxy;
mod ws_transport;

static LOG_DIR: Mutex<Option<PathBuf>> = Mutex::new(None);
// OS opens waiting for the page: invite links, notification taps, and
// #97 shares. take_opened_urls drains the lot.
static OPENED_URLS: Mutex<Vec<String>> = Mutex::new(Vec::new());
static SIDECAR_STATUS: Mutex<Option<serde_json::Value>> = Mutex::new(None);

/// Where shell-side state files live (SOCKS5 proxy, WebSocket transport) and
/// who hears their events: the Tauri app while it runs, or on Android the
/// headless core a service, push, job or alarm started in a process whose
/// activity never ran (`Java_org_velta_VeltaCore_startHeadless`).
#[derive(Clone)]
pub struct Host {
    app: Option<tauri::AppHandle>,
}

impl Host {
    pub fn from_app(app: &tauri::AppHandle) -> Self {
        Self { app: Some(app.clone()) }
    }
    /// The Tauri app once it is attached (Android: after setup ran).
    #[cfg_attr(not(target_os = "android"), allow(dead_code))]
    pub fn current() -> Self {
        Self { app: ui_app() }
    }
    #[cfg_attr(not(windows), allow(dead_code))]
    pub fn app(&self) -> Option<&tauri::AppHandle> {
        self.app.as_ref()
    }
    /// Tauri's app-local data dir; on Android the same directory comes from
    /// the Context when no app is attached (both are Context.getDataDir()).
    #[cfg_attr(not(any(target_os = "android", windows)), allow(dead_code))]
    pub fn data_dir(&self) -> Option<PathBuf> {
        if let Some(dir) = self.app.as_ref().and_then(|a| a.path().app_local_data_dir().ok()) {
            return Some(dir);
        }
        #[cfg(target_os = "android")]
        {
            ANDROID_DATA_DIR.lock().unwrap().clone()
        }
        #[cfg(not(target_os = "android"))]
        {
            None
        }
    }
    /// Emits to the page when there is one; a headless core has nobody to tell.
    #[cfg_attr(not(any(target_os = "android", windows)), allow(dead_code))]
    pub fn emit<S: serde::Serialize + Clone>(&self, event: &str, payload: S) {
        if let Some(app) = self.app.clone().or_else(ui_app) {
            let _ = app.emit(event, payload);
        }
    }
}

/// The attached Tauri app (Android only: desktop always has one at hand).
fn ui_app() -> Option<tauri::AppHandle> {
    #[cfg(target_os = "android")]
    {
        APP_HANDLE.lock().unwrap().clone()
    }
    #[cfg(not(target_os = "android"))]
    {
        None
    }
}

// Context.getDataDir() — what Tauri's app_local_data_dir() resolves to on
// Android. Set by setup and by the headless start, whichever runs first.
#[cfg(target_os = "android")]
static ANDROID_DATA_DIR: Mutex<Option<PathBuf>> = Mutex::new(None);

// Non-blocking logger: messages are pushed onto an unbounded mpsc channel and
// written from a dedicated background thread, so log() never blocks the IPC /
// RPC hot path. On Android this is critical -- the WebView event bridge and the
// JSON-RPC session both pass through the main thread context, and a
// synchronous file open+write per RPC round-trip was stalling the startup
// handshake long enough for the frontend's event.listen() to time out and
// fall back to demo mode.
static LOG_TX: Mutex<Option<std::sync::mpsc::Sender<String>>> = Mutex::new(None);
// Runtime logging gate, flipped by set_logging_enabled (Diagnostics chat).
// Default OFF (V-09/#66): the log mirrors message content to disk outside
// the account db; the renderer pushes the persisted choice at boot
// (localStorage `velta-logging`).
static LOG_ENABLED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

// Optional second log location on the shared external storage, where adb can
// read it on non-rooted devices (/storage/emulated/0/Android/data/<id>/files).
static MIRROR_LOG_DIR: Mutex<Option<PathBuf>> = Mutex::new(None);

pub fn set_mirror_log_dir(path: PathBuf) {
    *MIRROR_LOG_DIR.lock().unwrap() = Some(path);
}

fn log_dir() -> PathBuf {
    LOG_DIR
        .lock()
        .unwrap()
        .clone()
        .unwrap_or_else(|| {
            // Fallback when set_log_dir() hasn't run yet. On Android,
            // LOCALAPPDATA is unset and the process CWD is "/" (not writable),
            // so the old fallback silently failed on every log call. Prefer a
            // temp directory so log writes never block. The real path is set
            // by set_log_dir() early in setup() before any meaningful logging.
            if let Ok(local_app_data) = std::env::var("LOCALAPPDATA") {
                if !local_app_data.is_empty() {
                    return Path::new(&local_app_data).join("Velta").join("logs");
                }
            }
            std::env::temp_dir().join("velta-logs")
        })
}

pub fn set_log_dir(path: PathBuf) {
    *LOG_DIR.lock().unwrap() = Some(path);
    // Spawn the writer thread lazily on the first set_log_dir() call so it
    // points at the real log directory.
    ensure_log_writer();
}

fn ensure_log_writer() {
    let mut guard = LOG_TX.lock().unwrap();
    if guard.is_some() {
        return;
    }
    let (tx, rx) = std::sync::mpsc::channel::<String>();
    *guard = Some(tx);
    drop(guard);

    // Capture the directory at spawn time -- it won't change during the session.
    let dir = log_dir();
    std::thread::Builder::new()
        .name("velta-log-writer".into())
        .spawn(move || {
            let _ = std::fs::create_dir_all(&dir);
            for msg in rx {
                let log_file = dir.join("velta.log");
                let res = OpenOptions::new()
                    .create(true)
                    .append(true)
                    .open(&log_file)
                    .and_then(|mut f| {
                        use std::io::Write;
                        f.write_all(msg.as_bytes())
                    });
                // If the log file becomes unwritable (rotated, volume full),
                // don't kill the thread -- just keep draining the channel so
                // log() callers never block.
                if res.is_err() {
                    std::thread::sleep(std::time::Duration::from_millis(100));
                }
                if let Some(mirror) = MIRROR_LOG_DIR.lock().unwrap().clone() {
                    let _ = std::fs::create_dir_all(&mirror);
                    let mirror_file = mirror.join("velta.log");
                    if let Ok(mut f) = OpenOptions::new().create(true).append(true).open(&mirror_file) {
                        use std::io::Write;
                        let _ = f.write_all(msg.as_bytes());
                    }
                }
            }
        })
        .ok();
}

pub fn log(msg: &str) {
    // Runtime gate (Diagnostics chat "Logging" switch): when off, velta.log
    // and its mirror freeze. The in-app Diagnostics chat keeps working —
    // its rows live in the frontend and never pass through here.
    if !LOG_ENABLED.load(std::sync::atomic::Ordering::Relaxed) {
        return;
    }
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default();
    let line = format!("[{}.{:03}] {}\n", now.as_secs(), now.subsec_millis(), msg);
    // Non-blocking send. If the channel doesn't exist yet (before
    // set_log_dir) or the writer thread has died, the message is dropped --
    // never block the caller. On Android this is what was killing startup:
    // every RPC round-trip did a synchronous create_dir_all+open+write under
    // a global Mutex, blocking the JSON-RPC handshake.
    if let Some(tx) = LOG_TX.lock().unwrap().as_ref() {
        let _ = tx.send(line);
    }
}

pub fn maybe_extract_deeplink(arg: &str) -> Option<String> {
    if arg.starts_with("velta:") || arg.starts_with("dcaccount:") || arg.starts_with("https://i.delta.chat/") || arg.starts_with("OPENPGP4FPR:") {
        return Some(arg.to_string());
    }
    if arg.starts_with("web+dcaccount:") {
        return Some(arg.replacen("web+dcaccount:", "", 1));
    }
    if arg.starts_with("web+velta:") {
        return Some(arg.replacen("web+velta:", "", 1));
    }
    if let Some(pos) = arg.find("velta://") {
        return Some(arg[pos..].to_string());
    }
    if let Some(pos) = arg.find("dcaccount:") {
        return Some(arg[pos..].to_string());
    }
    if let Some(pos) = arg.find("https://i.delta.chat/") {
        return Some(arg[pos..].to_string());
    }
    if arg.starts_with("http://") || arg.starts_with("https://") {
        return Some(arg.to_string());
    }
    None
}

fn set_sidecar_status(app: &tauri::AppHandle, status: serde_json::Value) {
    *SIDECAR_STATUS.lock().unwrap() = Some(status.clone());
    app.emit("velta-sidecar-status", status).ok();
}

#[tauri::command]
fn get_sidecar_status() -> serde_json::Value {
    SIDECAR_STATUS.lock().unwrap().clone().unwrap_or_else(|| serde_json::json!({"running": false, "stage": "unknown"}))
}

// Database-encryption lock state (#178): set once the sidecar probe knows
// which accounts could NOT be opened with the key. The UI shows a locked
// screen for these and onboarding never runs over unreadable data. Only the
// desktop probe writes it; Android (phase 2) reports None until then.
static DB_LOCK_STATUS: Mutex<Option<serde_json::Value>> = Mutex::new(None);

#[tauri::command]
fn get_db_lock_status() -> Option<serde_json::Value> {
    DB_LOCK_STATUS.lock().unwrap().clone()
}

// Encryption-off / key-missing notice (#178): "keychain-unavailable" (no OS
// keychain, e.g. no Linux Secret Service — this session is unencrypted) or
// "key-missing" (encrypted profiles exist but the keychain has no key; no
// new key is created, they stay locked). None = encryption healthy.
static DB_KEY_ISSUE: Mutex<Option<&'static str>> = Mutex::new(None);

#[cfg(not(target_os = "android"))]
fn set_db_key_issue(issue: Option<db_key::KeyIssue>) {
    *DB_KEY_ISSUE.lock().unwrap() = issue.map(|i| match i {
        db_key::KeyIssue::KeychainUnavailable => "keychain-unavailable",
        db_key::KeyIssue::KeyMissing => "key-missing",
    });
}

#[tauri::command]
fn get_db_key_issue() -> Option<&'static str> {
    *DB_KEY_ISSUE.lock().unwrap()
}

/// After the sidecar is up: ask it which accounts are actually open. A
/// closed account (wrong/missing key, or a failed migration earlier this
/// session) errors its first config read — those ids go to the locked
/// screen. Config reads on OPEN accounts always succeed, so this cannot
/// misfire on a healthy install.
#[cfg(not(target_os = "android"))]
async fn probe_db_lock(app: tauri::AppHandle) {
    let Ok(ids) = sidecar_call(&app, "get_all_account_ids", serde_json::json!([])).await
        .and_then(|v| serde_json::from_value::<Vec<u32>>(v).map_err(|e| e.to_string()))
    else {
        return; // sidecar dead: the sidecar-status surface reports that
    };
    let mut locked = Vec::new();
    for id in ids {
        if sidecar_call(&app, "get_config", serde_json::json!([id, "addr"]))
            .await
            .is_err()
        {
            locked.push(id);
        }
    }
    if locked.is_empty() {
        return;
    }
    let mut status = serde_json::json!({ "locked": locked });
    // Keep an app-lock PIN marker if the session started locked — the PIN
    // screen must win over the generic retry.
    if let Some(prev) = DB_LOCK_STATUS.lock().unwrap().as_ref() {
        if let Some(mode) = prev.get("mode") {
            status["mode"] = mode.clone();
        }
    }
    *DB_LOCK_STATUS.lock().unwrap() = Some(status.clone());
    app.emit("velta-db-locked", status).ok();
}

// ---- App lock: PIN + auto-lock (#178 phase 4, desktop) --------------------

/// The live sidecar process, so a lock/unlock can respawn it (the key rides
/// the process env, so re-keying means a new process).
#[cfg(not(target_os = "android"))]
static SIDECAR_CHILD: Mutex<Option<std::process::Child>> = Mutex::new(None);

/// Spawn (or respawn) the rpc-server sidecar with `key` as its env. The
/// reader/wait threads ride each spawn; the managed RpcState only has its
/// stdin swapped on a respawn. `first` runs the one-time proxy
/// boots. `probe_db_lock` is the caller's job.
#[cfg(not(target_os = "android"))]
fn spawn_sidecar(app: &tauri::AppHandle, key: Option<String>, first: bool) {
    if let Some(mut child) = SIDECAR_CHILD.lock().unwrap().take() {
        log("stopping the previous sidecar");
        let _ = child.kill();
        let _ = child.wait();
    }
    let accounts = accounts_dir(app);
    let Some(sidecar_path) = find_sidecar(app) else {
        log("sidecar not found; continuing with mock/remote transports available to frontend");
        set_sidecar_status(app, serde_json::json!({"running": false, "stage": "missing", "error": "sidecar not found"}));
        return;
    };
    log(&format!("starting sidecar at {}", sidecar_path.display()));
    set_sidecar_status(app, serde_json::json!({"running": true, "stage": "starting"}));

    let stderr_file = log_dir().join("sidecar-stderr.log");
    let stderr = OpenOptions::new()
        .create(true)
        .append(true)
        .open(&stderr_file)
        .map(Stdio::from)
        .unwrap_or_else(|e| {
            log(&format!("could not open sidecar stderr log: {e}; sending stderr to null"));
            Stdio::null()
        });

    let mut cmd = Command::new(&sidecar_path);
    if let Some(raw) = &key {
        cmd.env("VELTA_DB_KEY", raw);
    }
    #[cfg(windows)]
    cmd.creation_flags(CREATE_NO_WINDOW);
    match cmd
        .current_dir(&accounts)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(stderr)
        .spawn()
    {
        Ok(mut child) => {
            let stdin = child.stdin.take().unwrap();
            let stdout = child.stdout.take().unwrap();
            *SIDECAR_CHILD.lock().unwrap() = Some(child);
            match app.try_state::<RpcState>() {
                Some(st) => {
                    *st.stdin.lock().unwrap() = Some(stdin);
                }
                None => {
                    app.manage(RpcState {
                        wxdc_pending: std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
                        bg_pending: std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
                        web_pending: std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
                        stdin: Arc::new(Mutex::new(Some(stdin))),
                    });
                }
            }
            set_sidecar_status(app, serde_json::json!({"running": true, "stage": "ready"}));
            if first {
                // Re-apply the selected SOCKS5 proxy before the page can start IO.
                proxy::boot(&Host::from_app(app));
                ws_transport::boot(&Host::from_app(app));
            }

            let app_handle = app.clone();
            std::thread::spawn(move || {
                log("sidecar reader thread started");
                let reader = BufReader::new(stdout);
                for line in reader.lines() {
                    match line {
                        Ok(line) => {
                            // NOTE: do not log every line -- it's the
                            // hot path and would grow velta.log
                            // unbounded. Errors are logged below.
                            if line.contains("\"id\":\"wxdc-") {
                                webxdc_resolve_line(&app_handle, &line);
                                continue;
                            }
                            // #49: a WebView command's response goes back
                            // through the rpc command's return value — only
                            // core-pushed lines reach the broadcast.
                            if line.contains("\"id\":") && resolve_web_line(&app_handle, &line) {
                                continue;
                            }
                            app_handle.emit("velta-rpc", line).ok();
                        }
                        Err(e) => {
                            log(&format!("sidecar stdout error: {e}"));
                        }
                    }
                }
                log("sidecar reader thread ended");
                set_sidecar_status(&app_handle, serde_json::json!({"running": false, "stage": "stopped"}));
            });

            if let Some(mut child) = SIDECAR_CHILD.lock().unwrap().take() {
                std::thread::spawn(move || {
                    match child.wait() {
                        Ok(status) => log(&format!("sidecar exited with {status}")),
                        Err(e) => log(&format!("sidecar wait error: {e}"))
                    }
                });
            }
        }
        Err(e) => {
            log(&format!("failed to start sidecar: {e}"));
            set_sidecar_status(app, serde_json::json!({"running": false, "stage": "error", "error": e.to_string()}));
        }
    }
}

/// #178 phase 5 (decision §2.5 A): what the OS tells us about disk
/// encryption on the volume holding the app data — blobs stay plaintext by
/// decision, so this is the honest boundary the settings show. "on" /
/// "off" / "unknown" (Windows Home without the BitLocker module, Linux).
#[tauri::command]
fn volume_encryption_status(app: tauri::AppHandle) -> String {
    #[cfg(target_os = "windows")]
    {
        let drive = accounts_dir(&app)
            .to_string_lossy()
            .chars()
            .next()
            .map(|c| format!("{c}:\\"))
            .unwrap_or_else(|| "C:\\".to_string());
        // Get-BitLockerVolume is absent on Home and needs the module; its
        // VolumeStatus enum prints English names on every locale.
        match std::process::Command::new("powershell")
            .args(["-NoProfile", "-Command", &format!("(Get-BitLockerVolume -MountPoint '{drive}').VolumeStatus")])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            Ok(out) if out.status.success() => {
                let v = String::from_utf8_lossy(&out.stdout).trim().to_string();
                if v.contains("Encrypted") && !v.contains("Decrypted") { "on".to_string() }
                else if v.contains("Decrypted") || v.contains("FullyDecrypted") { "off".to_string() }
                else { "unknown".to_string() }
            }
            _ => "unknown".to_string(),
        }
    }
    #[cfg(target_os = "macos")]
    {
        let _ = &app; // FileVault is per machine, not per data path
        match std::process::Command::new("/usr/bin/fdesetup").arg("isactive").output() {
            Ok(out) if out.status.success() => {
                if String::from_utf8_lossy(&out.stdout).trim() == "true" { "on".to_string() } else { "off".to_string() }
            }
            _ => "unknown".to_string(),
        }
    }
    #[cfg(not(any(target_os = "windows", target_os = "macos")))]
    {
        let _ = app;
        "unknown".to_string()
    }
}

/// The biometric app lock on/off (Android; phase 4).
#[tauri::command]
fn biometric_state(app: tauri::AppHandle) -> bool {
    #[cfg(target_os = "android")]
    {
        let _ = &app;
        android_biometric_pending()
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = app;
        false
    }
}

/// Show the enable/disable prompt (result rides the velta-biometric event).
#[tauri::command]
fn biometric_set(app: tauri::AppHandle, on: bool) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let _ = &app;
        android_biometric_request(on)
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = (app, on);
        Err("not supported on this platform".to_string())
    }
}

/// Persist the auto-lock minutes where the platform checks them.
#[tauri::command]
fn set_autolock_mins(app: tauri::AppHandle, mins: i64) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let _ = &app;
        android_set_autolock_mins(mins)
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = (app, mins);
        Ok(()) // desktop reads the same value from localStorage
    }
}

#[tauri::command]
fn get_db_pin_state(app: tauri::AppHandle) -> bool {
    #[cfg(not(target_os = "android"))]
    {
        db_key::pin_locked(&accounts_dir(&app))
    }
    #[cfg(target_os = "android")]
    {
        let _ = &app;
        android_pin_wrap().is_some_and(|p| p.is_file())
    }
}

/// Set / change the app-lock PIN. `old` must verify when a PIN is already
/// set; the DEK comes from the wrap or the keychain. The session keeps
/// running (same DEK) — only the custody changes.
#[tauri::command]
fn set_db_pin(app: tauri::AppHandle, old: Option<String>, pin: String) -> Result<(), String> {
    #[cfg(not(target_os = "android"))]
    {
        db_key::pin_set(&accounts_dir(&app), old.as_deref(), &pin)
    }
    #[cfg(target_os = "android")]
    {
        let _ = app;
        android_pin_set(old.as_deref(), &pin)
    }
}

#[tauri::command]
fn clear_db_pin(app: tauri::AppHandle, pin: String) -> Result<(), String> {
    #[cfg(not(target_os = "android"))]
    {
        db_key::pin_clear(&accounts_dir(&app), &pin)
    }
    #[cfg(target_os = "android")]
    {
        let _ = app;
        android_pin_clear(&pin)
    }
}

/// Verify the PIN and re-key the session: migrate anything plaintext, then
/// respawn the sidecar with the DEK. Backoff for wrong PINs runs here, so
/// the renderer cannot bypass it.
#[tauri::command]
async fn unlock_with_pin(app: tauri::AppHandle, pin: String) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let _ = app;
        return tauri::async_runtime::spawn_blocking(move || android_pin_unlock(&pin))
            .await
            .map_err(|e| e.to_string())?;
    }
    #[cfg(not(target_os = "android"))]
    {
    let dir = accounts_dir(&app);
    let raw = {
        let dir = dir.clone();
        tauri::async_runtime::spawn_blocking(move || db_key::pin_unlock(&dir, &dir.join("accounts"), &pin))
            .await
            .map_err(|e| e.to_string())??
    };
    spawn_sidecar(&app, Some(raw), false);
    *DB_LOCK_STATUS.lock().unwrap() = None;
    probe_db_lock(app.clone()).await;
    app.emit("velta-db-unlocked", ()).ok();
    Ok(())
    }
}

/// Auto-lock (PIN sessions only): kill the keyed sidecar and respawn
/// keyless — accounts close, the PIN screen returns. The data on disk was
/// already encrypted; nothing else to wipe.
#[tauri::command]
async fn lock_now(app: tauri::AppHandle) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let _ = &app;
        return Err("not supported on this platform".to_string());
    }
    #[cfg(not(target_os = "android"))]
    {
    if !db_key::pin_locked(&accounts_dir(&app)) {
        return Err("no app-lock PIN is set".to_string());
    }
    *DB_LOCK_STATUS.lock().unwrap() = Some(serde_json::json!({ "mode": "pin" }));
    // #178 phase 5: the thumbnail cache is a flat gallery of derived
    // plaintext images — it must not sit at rest while the session is
    // locked; it regenerates on demand after the unlock reload.
    if let Some(parent) = accounts_dir(&app).parent() {
        let _ = std::fs::remove_dir_all(parent.join("thumbs"));
    }
    spawn_sidecar(&app, None, false);
    app.emit("velta-db-locked", serde_json::json!({ "mode": "pin" })).ok();
    Ok(())
    }
}

/// Latest released Velta version for the drawer update banner. Shell-side
/// HTTP on purpose: the renderer's fetch of the cross-origin GitHub URL is
/// blocked by CORS (the release CDN sends no ACAO headers), and shell HTTP
/// is not CSP-bound — this hardcoded URL is the ONLY GitHub reach the app
/// has (see AGENTS.md §8). Bounded read + hard timeout like
/// fetch_page_title; any failure returns an empty string and the frontend
/// just shows no banner.
#[tauri::command]
async fn get_latest_version() -> Result<String, String> {
    const VERSION_URL: &str =
        "https://github.com/pbuzdin/velta/releases/latest/download/version.txt";
    tauri::async_runtime::spawn_blocking(move || {
        let agent = ureq::AgentBuilder::new()
            .timeout(std::time::Duration::from_secs(5))
            .build();
        let resp = match agent.get(VERSION_URL).call() {
            Ok(r) => r,
            Err(_) => return Ok(String::new()),
        };
        let mut body = Vec::new();
        use std::io::Read;
        let _ = resp
            .into_reader()
            .take(64 * 1024)
            .read_to_end(&mut body);
        Ok(String::from_utf8_lossy(&body).trim().to_string())
    })
    .await
    .map_err(|e| e.to_string())?
}

/// #60: stream the release APK into the app cache dir while emitting
/// `update-download` progress events `{received, total}`. GitHub-only by
/// construction (AGENTS.md §8): the URL is built HERE from the version the
/// frontend got from get_latest_version, keeping the app's single hardcoded
/// release-host reach. A failed download removes the partial file.
#[cfg(target_os = "android")]
#[tauri::command]
async fn download_update(app: tauri::AppHandle, version: String) -> Result<String, String> {
    let v = version.trim().trim_start_matches('v').to_string();
    if v.is_empty() || !v.chars().all(|c| c.is_ascii_digit() || c == '.') {
        return Err("bad version".into());
    }
    let url = format!(
        "https://github.com/pbuzdin/velta/releases/download/v{v}/Velta-{v}-arm64.apk"
    );
    tauri::async_runtime::spawn_blocking(move || -> Result<String, String> {
        let agent = ureq::AgentBuilder::new()
            .timeout_connect(std::time::Duration::from_secs(15))
            .build();
        let resp = agent.get(&url).call().map_err(|e| e.to_string())?;
        // ureq 2.x: header lookup is .header(name) — .headers() is private.
        let total: u64 = resp
            .header("content-length")
            .and_then(|v| v.parse().ok())
            .unwrap_or(0);
        let dir = app.path().app_cache_dir().map_err(|e| e.to_string())?;
        std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
        // Earlier downloads are version-suffixed and ~50 MB each; sweep them
        // best-effort so failed/old updates don't pile up in cache.
        if let Ok(entries) = std::fs::read_dir(&dir) {
            for entry in entries.flatten() {
                let name = entry.file_name();
                let name = name.to_string_lossy();
                if name.starts_with("Velta-") && name.ends_with("-arm64.apk") {
                    let _ = std::fs::remove_file(entry.path());
                }
            }
        }
        let path = dir.join(format!("Velta-{v}-arm64.apk"));
        let wipe = |e: String| -> String {
            let _ = std::fs::remove_file(&path);
            e
        };
        let mut out = std::fs::File::create(&path).map_err(|e| wipe(e.to_string()))?;
        let mut reader = resp.into_reader();
        let mut buf = [0u8; 64 * 1024];
        let mut received: u64 = 0;
        let mut next_emit: u64 = 0;
        use std::io::{Read, Write};
        loop {
            let n = reader
                .read(&mut buf)
                .map_err(|e| wipe(e.to_string()))?;
            if n == 0 {
                break;
            }
            out.write_all(&buf[..n]).map_err(|e| wipe(e.to_string()))?;
            received += n as u64;
            if received >= next_emit {
                next_emit = received + 512 * 1024;
                let _ = app.emit(
                    "update-download",
                    serde_json::json!({ "received": received, "total": total }),
                );
            }
        }
        let _ = app.emit(
            "update-download",
            serde_json::json!({ "received": received, "total": total }),
        );
        Ok(path.to_string_lossy().to_string())
    })
    .await
    .map_err(|e| e.to_string())?
}

/// Desktop stub: in-app APK install is Android-only; desktop updates run
/// through the updater plugin (selfUpdate in ui.js).
#[cfg(not(target_os = "android"))]
#[tauri::command]
async fn download_update(_app: tauri::AppHandle, _version: String) -> Result<String, String> {
    Err("in-app APK updates are Android-only".into())
}

/// Best-effort page <title> for the in-app browser bar. Bounded read (256 KB)
/// and a hard timeout — a slow or hostile page must not hang the bar. Any
/// failure is reported as an empty string; the bar falls back to the domain.
#[tauri::command]
async fn fetch_page_title(url: String, proxy: Option<String>) -> Result<String, String> {
    if !url.starts_with("https://") {
        return Err("only https URLs are supported".into());
    }
    // Best-effort: an unusable proxy means no fetch (never a direct one) and
    // the bar keeps the domain, same as a failed fetch.
    let Ok(agent) = link_preview_agent(proxy.as_deref()) else { return Ok(String::new()) };
    tauri::async_runtime::spawn_blocking(move || {
        let Ok(text) = fetch_capped(&agent, &url) else { return Ok(String::new()) };
        let lower = text.to_ascii_lowercase();
        let Some(start) = lower.find("<title") else { return Ok(String::new()) };
        let Some(open_end) = lower[start..].find('>') else { return Ok(String::new()) };
        let from = start + open_end + 1;
        let Some(close) = lower[from..].find("</title") else { return Ok(String::new()) };
        let mut title = html_escape_decode(text[from..from + close].trim());
        if title.len() > 200 {
            title = title.chars().take(200).collect();
        }
        Ok(title)
    })
    .await
    .map_err(|e| e.to_string())?
}

fn html_escape_decode(s: &str) -> String {
    s.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
}

/// Expand a short invite link (e.g. https://deltachat.id/<name>, the Delta
/// Chat username service): the page JS-redirects to the full
/// https://i.delta.chat/#FINGERPRINT… invite URL, so there is no HTTP 3xx to
/// follow — shell-side fetch (renderer fetch is CORS-blocked, same reason as
/// get_latest_version) and extract every URL candidate that carries a
/// 40-hex fingerprint after "/#". The frontend picks the candidate that
/// parses as a registered invite. Bounded read + hard timeout like
/// fetch_page_title; no candidates -> empty vec, and the UI degrades to a
/// plain link.
#[tauri::command]
async fn expand_invite_link(url: String, proxy: Option<String>) -> Result<Vec<String>, String> {
    if !url.starts_with("https://") {
        return Err("only https URLs are supported".into());
    }
    // Fails closed like fetch_link_preview: an unusable proxy is an Err and
    // the frontend renders a plain link instead of fetching directly.
    let agent = link_preview_agent(proxy.as_deref())?;
    tauri::async_runtime::spawn_blocking(move || {
        let Ok(text) = fetch_capped(&agent, &url) else { return Ok(Vec::new()) };
        let mut out = Vec::new();
        let mut from = 0;
        while let Some(pos) = text[from..].find("https://") {
            let start = from + pos;
            let end = text[start..]
                .find(['"', '\'', '<', '>', ' ', ')'])
                .map(|e| start + e)
                .unwrap_or(text.len());
            let candidate = &text[start..end];
            if let Some(fp) = candidate.split("/#").nth(1) {
                if fp.len() >= 40 && fp[..40].bytes().all(|b| b.is_ascii_hexdigit()) {
                    out.push(candidate.to_string());
                }
            }
            from = start + 8;
        }
        Ok(out)
    })
    .await
    .map_err(|e| e.to_string())?
}

/// New-connection reachability probe for a relay domain: does a TLS+HTTP
/// request succeed right now? The core's connectivity dot only reflects the
/// last session state — an established IMAP session can keep it green while
/// the relay refuses new connections (seen live with a dead relay reported
/// "Connected" for hours). Shell-side like fetch_link_preview (renderer
/// fetch is CSP-bound); a bare TCP connect is not enough behind a fake-IP
/// VPN — the local proxy accepts the handshake immediately — so this does a
/// real TLS request. Any response, even 4xx/5xx, means the host accepts new
/// connections; a transport error means it doesn't.
#[tauri::command]
async fn probe_relay(domain: String) -> Result<bool, String> {
    let host = domain.trim().to_lowercase();
    let ok_char =
        |c: char| c.is_ascii_alphanumeric() || c == '.' || c == '-';
    if host.is_empty() || !host.chars().all(ok_char) || !host.contains('.') {
        return Err("invalid domain".into());
    }
    tauri::async_runtime::spawn_blocking(move || {
        let agent = ureq::AgentBuilder::new()
            .timeout(std::time::Duration::from_secs(6))
            .build();
        let resp = agent
            .get(&format!("https://{host}/"))
            .call();
        Ok(resp.is_ok())
    })
    .await
    .map_err(|e| e.to_string())?
}

/// Proxy URL for link-preview fetches, or None for a direct fetch. Takes the
/// first non-empty line (the core's `proxy_url` is a newline-separated list
/// and the first entry is the active one). Only schemes ureq can speak are
/// accepted; `socks5h` is mapped to `socks5`, which ureq already resolves on
/// the proxy side (the tunnel needs that: local DNS may be blocked).
fn link_preview_proxy(proxy: Option<&str>) -> Result<Option<String>, String> {
    let Some(first) = proxy
        .unwrap_or("")
        .lines()
        .map(str::trim)
        .find(|l| !l.is_empty())
    else {
        return Ok(None);
    };
    let (scheme, rest) = first
        .split_once("://")
        .ok_or_else(|| "unsupported proxy for link previews".to_string())?;
    let scheme = match scheme.to_ascii_lowercase().as_str() {
        "socks5" | "socks5h" => "socks5",
        "http" => "http",
        _ => return Err("unsupported proxy for link previews".into()),
    };
    if rest.is_empty() {
        return Err("unsupported proxy for link previews".into());
    }
    Ok(Some(format!("{scheme}://{rest}")))
}

/// GET `url` with `agent` and return at most the first 256 KB as lossy
/// UTF-8. Shared by fetch_page_title, expand_invite_link and
/// fetch_link_preview; a transport error is Err("fetch failed") and each
/// caller maps it to its own semantics. The agent decides direct vs proxy
/// (link_preview_agent: never a direct fallback when a proxy is set).
fn fetch_capped(agent: &ureq::Agent, url: &str) -> Result<String, String> {
    use std::io::Read;
    let resp = agent.get(url).call().map_err(|_| "fetch failed".to_string())?;
    let mut body = Vec::new();
    let _ = resp.into_reader().take(256 * 1024).read_to_end(&mut body);
    Ok(String::from_utf8_lossy(&body).into_owned())
}

/// The ureq agent for fetch_link_preview: direct without a proxy, through it
/// otherwise. Err (no agent at all) when the proxy can't be used.
fn link_preview_agent(proxy: Option<&str>) -> Result<ureq::Agent, String> {
    let mut builder = ureq::AgentBuilder::new().timeout(std::time::Duration::from_secs(5));
    if let Some(p) = link_preview_proxy(proxy)? {
        let p = ureq::Proxy::new(&p).map_err(|_| "unsupported proxy for link previews".to_string())?;
        builder = builder.proxy(p);
    }
    Ok(builder.build())
}

/// Relay signup invite claim (docs/invite-cards.md): GET
/// https://<host>/i/claim?t=<token> on the relay's invite.py, which consumes
/// one use and answers {"email","password"} (or {"error"} with 400/403/409/
/// 410/503). Shell-side because the renderer is CORS-bound. Goes through the
/// profile's proxy when one is set (the selected SOCKS5 / WebSocket proxy
/// SOCKS port) and never falls back to a direct fetch. Returns
/// {"status": u16, "body": JSON|null}; the page maps codes to messages.
/// Credentials are never logged.
#[tauri::command]
async fn relay_invite_claim(host: String, token: String, proxy: Option<String>) -> Result<serde_json::Value, String> {
    let url = relay_claim_url(&host, &token)?;
    let mut builder = ureq::AgentBuilder::new().timeout(std::time::Duration::from_secs(45));
    if let Some(p) = link_preview_proxy(proxy.as_deref())? {
        builder = builder.proxy(ureq::Proxy::new(&p).map_err(|_| "unsupported proxy".to_string())?);
    }
    let agent = builder.build();
    tauri::async_runtime::spawn_blocking(move || {
        use std::io::Read;
        let resp = match agent.get(&url).set("Cache-Control", "no-store").call() {
            Ok(r) => r,
            Err(ureq::Error::Status(_, r)) => r,
            Err(e) => return Err(format!("network error: {}", e.kind())),
        };
        let status = resp.status();
        let mut body = Vec::new();
        let _ = resp.into_reader().take(16 * 1024).read_to_end(&mut body);
        let json = serde_json::from_slice::<serde_json::Value>(&body).unwrap_or(serde_json::Value::Null);
        Ok(serde_json::json!({ "status": status, "body": json }))
    })
    .await
    .map_err(|e| e.to_string())?
}

/// Strict claim URL: DNS host (no port, userinfo or IP), token of 8..=128
/// base64url chars. Anything else is refused before any network I/O.
fn relay_claim_url(host: &str, token: &str) -> Result<String, String> {
    let host = host.trim().trim_end_matches('.').to_ascii_lowercase();
    let labels: Vec<&str> = host.split('.').collect();
    let label_ok = |l: &&str| {
        !l.is_empty() && l.len() <= 63 && !l.starts_with('-') && !l.ends_with('-')
            && l.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
    };
    let tld_ok = labels.last().is_some_and(|t| t.len() >= 2 && t.bytes().all(|b| b.is_ascii_lowercase()));
    if host.len() > 253 || labels.len() < 2 || !labels.iter().all(label_ok) || !tld_ok {
        return Err("bad relay host".into());
    }
    if !(8..=128).contains(&token.len()) || token == "claim"
        || !token.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_') {
        return Err("bad invite token".into());
    }
    Ok(format!("https://{host}/i/claim?t={token}"))
}

/// Open Graph preview for the first link in a message. Same trust model as
/// expand_invite_link: shell-side fetch of a message-derived https URL
/// (renderer fetch is CORS-blocked and CSP-bound), bounded reads + hard
/// timeout. Returns null fields when the page has no OG tags; any transport
/// failure is an Err and the frontend simply renders no card.
///
/// `proxy` is the active account's proxy (`proxy_url` when `proxy_enabled`,
/// the renderer reads it from the core): the user's own SOCKS5/HTTP proxy or
/// the selected SOCKS5 proxy (proxy.rs writes it there).
/// Both the page and its og:image go through it. Fails closed: a proxy this
/// client cannot speak (Shadowsocks, HTTPS proxy, garbage) is an Err, and a
/// dead proxy is a transport Err — never a silent direct fetch.
#[tauri::command]
async fn fetch_link_preview(url: String, proxy: Option<String>) -> Result<serde_json::Value, String> {
    if !url.starts_with("https://") {
        return Err("only https URLs are supported".into());
    }
    let agent = link_preview_agent(proxy.as_deref())?;
    tauri::async_runtime::spawn_blocking(move || {
        let text = fetch_capped(&agent, &url)?;
        let lower = text.to_ascii_lowercase();

        // og: property first, twitter: name second, plain <title>/description
        // last. Bounded to the same 256 KB window we downloaded.
        let meta = |names: &[&str]| -> Option<String> {
            for name in names {
                for marker in [
                    format!("property=\"{}\"", name),
                    format!("name=\"{}\"", name),
                    format!("property='{}'", name),
                    format!("name='{}'", name),
                ] {
                    if let Some(p) = lower.find(&marker) {
                        let rest = &text[p + marker.len()..];
                        if let Some(q) = rest.find("content=\"").or_else(|| rest.find("content='")) {
                            // rest[q..q+9] is `content="` or `content='` — the
                            // delimiter is the char at q+8, and the VALUE starts
                            // at q+9 (reading it as the delimiter grabbed the
                            // value's first char and swallowed HTML up to its
                            // next occurrence: title "Yandex" → "andex"/>…").
                            let delim = rest.as_bytes()[q + 8] as char;
                            let after = &rest[q + 9..];
                            if let Some(end) = after.find(delim) {
                                let v = html_escape_decode(after[..end].trim());
                                if !v.is_empty() {
                                    return Some(v.chars().take(300).collect());
                                }
                            }
                        }
                    }
                }
            }
            None
        };

        let title = meta(&["og:title", "twitter:title"]).or_else(|| {
            // plain <title> fallback, same extraction as fetch_page_title
            let s = lower.find("<title")?;
            let open_end = lower[s..].find('>')?;
            let from = s + open_end + 1;
            let close = lower[from..].find("</title")?;
            let v = html_escape_decode(text[from..from + close].trim());
            if v.is_empty() { None } else { Some(v) }
        });
        let description = meta(&["og:description", "twitter:description", "description"]);
        let image_url = meta(&["og:image", "twitter:image", "twitter:image:src"]);

        // og:image: fetch and inline as a data: URL (CSP img-src allows data:
        // in all three copies; remote hosts are deliberately not allowed).
        // Cap at 512 KB; on any failure just ship no image.
        let mut image_data: Option<String> = None;
        if let Some(img) = image_url {
            if img.starts_with("https://") {
                if let Ok(iresp) = agent.get(&img).call() {
                    let mime = iresp.content_type().to_string();
                    if mime.starts_with("image/") {
                        let mut ib = Vec::new();
                        if read_bounded(iresp, &mut ib) {
                            image_data = Some(format!(
                                "data:{mime};base64,{}",
                                data_encoding::BASE64.encode(&ib)
                            ));
                        }
                    }
                }
            }
        }

        Ok(serde_json::json!({
            "title": title,
            "description": description,
            "image": image_data,
        }))
    })
    .await
    .map_err(|e| e.to_string())?
}

// bounded read helper: returns false when the cap was hit mid-stream (truncated image)
fn read_bounded(resp: ureq::Response, buf: &mut Vec<u8>) -> bool {
    use std::io::Read;
    match resp.into_reader().take(512 * 1024 + 1).read_to_end(buf) {
        Ok(n) => n <= 512 * 1024,
        Err(_) => false,
    }
}

#[tauri::command]
fn get_accounts_dir(app: tauri::AppHandle) -> String {
    accounts_dir(&app).to_string_lossy().to_string()
}

/// #138: write a built-in .xdc (bundled via include_bytes!) into uploads/
/// and return its verified path for the core to send.
#[tauri::command]
fn prepare_builtin_xdc(app: tauri::AppHandle, name: String) -> Result<String, String> {
    use tauri::path::BaseDirectory;
    if builtin_xdc::builtin_bytes(&name).is_none() {
        return Err(format!("unknown built-in app: {name}"));
    }
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let dest = app
        .path()
        .resolve(format!("uploads/{name}-{stamp}.xdc"), BaseDirectory::AppLocalData)
        .map_err(|e| e.to_string())?;
    builtin_xdc::write_builtin(&name, &dest)?;
    Ok(dest.to_string_lossy().to_string())
}

#[tauri::command]
fn resolve_upload_path(app: tauri::AppHandle, filename: String) -> String {
    use tauri::path::BaseDirectory;
    // V-07/#65: the name is renderer-supplied (it may embed peer file names)
    // — reduce it to its final component so the target can never leave
    // uploads/ via ../ or a drive-absolute path.
    let safe = std::path::Path::new(&filename)
        .file_name()
        .map(|n| n.to_os_string())
        .unwrap_or_default();
    if safe.is_empty() {
        return String::new();
    }
    app.path()
        .resolve(format!("uploads/{}", safe.to_string_lossy()), BaseDirectory::AppLocalData)
        .map(|p| {
            // The fs plugin's write_file does not create parent directories;
            // this command hands out paths it must guarantee are writable.
            if let Some(parent) = p.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            p.to_string_lossy().to_string()
        })
        .unwrap_or_default()
}

/// V-05/#63: register the webxdc instance the manager is about to open.
/// webxdc_serve refuses every non-icon blob request whose <account>/<msg>
/// prefix differs from the instance registered here, so an open app cannot
/// read another instance's blobs even though the server sends ACAO: *.
#[tauri::command]
fn webxdc_begin(account: u32, msg: u32) {
    webxdc_serve::set_open_app(account, msg);
}

/// Audit item 5: the manager closed this instance's frame — stop serving it.
#[tauri::command]
fn webxdc_end(account: u32, msg: u32) {
    webxdc_serve::clear_open_app(account, msg);
}

/// V-07/#65: fs plugin file access is scoped — there is no fs:read-all
/// capability any more. The only legitimate arbitrary-path reads are files
/// the user picked in a native dialog or opened Velta with. The renderer's
/// word is not enough: picked::check requires Rust-side evidence (the
/// dialog plugin already scoped the path, the OS handed it to us, or it is
/// inside Velta's own data dirs) before the path is added to the scope.
#[tauri::command]
fn allow_picked_path(app: tauri::AppHandle, path: String) -> Result<(), String> {
    use tauri_plugin_fs::FsExt;
    let p = std::path::PathBuf::from(&path);
    picked::check(&app, &p)?;
    app.fs_scope()
        .allow_file(&p)
        .map_err(|e| e.to_string())
}

mod webxdc_serve;
mod picked;
pub mod builtin_xdc;
pub mod lufi;
pub mod cryptex;
pub mod c3_probe;
use webxdc_serve::{webxdc_resolve_line, webxdc_serve};
mod bg_events;
mod scheduled;
mod scheduled_store;
// Database encryption at rest (#178): desktop keeps the DEK in the OS
// keychain (keyring) and passes it to the sidecar; Android keeps it in the
// Keystore (VeltaKeystore.kt via JNI) and sets it in-process.
mod db_key;

// ---------- blobfile:// -- Range-aware media serving ----------

// The default asset protocol on Android is served by the plain
// WebViewAssetLoader, which ignores Range requests. Video files whose moov
// atom sits at the end of the file (most phone recordings) then can't be
// played: the media player must seek to the end to read the index and back
// into the data. This custom protocol answers Range requests with proper
// 206 responses so <video>/<audio> can seek inside any blob.

fn percent_decode(s: &str) -> String {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        if b[i] == b'%' && i + 2 < b.len() {
            if let Ok(byte) = u8::from_str_radix(std::str::from_utf8(&b[i + 1..i + 3]).unwrap_or(""), 16) {
                out.push(byte);
                i += 3;
                continue;
            }
        }
        out.push(b[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

fn guess_mime(path: &str) -> &'static str {
    let lower = path.to_ascii_lowercase();
    let ext = lower.rsplit('.').next().unwrap_or("");
    match ext {
        "mp4" | "m4v" | "mov" => "video/mp4",
        "webm" => "video/webm",
        "mkv" => "video/x-matroska",
        "avi" => "video/x-msvideo",
        "3gp" => "video/3gpp",
        "jpg" | "jpeg" => "image/jpeg",
        "png" => "image/png",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "bmp" => "image/bmp",
        "mp3" => "audio/mpeg",
        "m4a" => "audio/mp4",
        "ogg" | "oga" | "opus" => "audio/ogg",
        "wav" => "audio/wav",
        "flac" => "audio/flac",
        "pdf" => "application/pdf",
        "txt" => "text/plain",
        "html" | "htm" | "xhtml" => "text/html", // HTML attachments render in the isolated viewer
        // webxdc assets: browsers hard-enforce MIME for module scripts
        // ("Expected a JavaScript-or-Wasm module script") and stylesheets,
        // so octet-stream breaks every bundler-built app.
        "js" | "mjs" => "text/javascript",
        "css" => "text/css",
        "wasm" => "application/wasm",
        "json" | "map" => "application/json",
        "svg" => "image/svg+xml",
        "ico" => "image/x-icon",
        "woff" => "font/woff",
        "woff2" => "font/woff2",
        "ttf" => "font/ttf",
        "otf" => "font/otf",
        _ => "application/octet-stream",
    }
}

// Origins of the app's own main window (Tauri serves the frontend at
// tauri://localhost on macOS/Linux and http(s)://tauri.localhost on
// Windows/Android). Only these may read blob/media responses cross-origin.
const APP_ORIGINS: &[&str] = &["tauri://localhost", "http://tauri.localhost", "https://tauri.localhost"];

/// CORS gate for the blob/media servers. Requests without an Origin header
/// (plain <img>/<video>/<audio> loads) pass and get no ACAO header. A request
/// that carries an Origin must be one of the app's own origins: sandboxed
/// frames (webxdc apps, the HTML viewer) send `Origin: null` and must never
/// be able to read files from the accounts directory.
/// Ok(Some(origin)) -> echo it in Access-Control-Allow-Origin; Err -> 403.
fn media_cors(origin: Option<&str>) -> Result<Option<String>, ()> {
    match origin {
        None => Ok(None),
        Some(o) if APP_ORIGINS.contains(&o) => Ok(Some(o.to_string())),
        Some(_) => Err(()),
    }
}

// "bytes=a-b" | "bytes=a-" | "bytes=-n" → inclusive (start, end)
fn parse_range(header: &str, len: u64) -> Option<(u64, u64)> {
    let rest = header.trim().strip_prefix("bytes=")?;
    let (start_s, end_s) = rest.split_once('-')?;
    if start_s.is_empty() {
        let n: u64 = end_s.parse().ok()?;
        if n == 0 || len == 0 {
            return None;
        }
        let start = len.saturating_sub(n);
        Some((start, len - 1))
    } else {
        let start: u64 = start_s.parse().ok()?;
        if start >= len {
            return None;
        }
        let end = if end_s.is_empty() { len - 1 } else { end_s.parse::<u64>().ok()?.min(len - 1) };
        if start > end {
            return None;
        }
        Some((start, end))
    }
}

fn serve_blob_file(app: &tauri::AppHandle, request: tauri::http::Request<Vec<u8>>) -> tauri::http::Response<Vec<u8>> {
    let not_found = |msg: &str| {
        tauri::http::Response::builder()
            .status(404)
            .header("Access-Control-Allow-Origin", "*")
            .body(msg.as_bytes().to_vec())
            .unwrap()
    };

    let uri = request.uri().to_string();
    log(&format!(
        "blobfile request: uri={} range={:?}",
        uri,
        request.headers().get("range").and_then(|v| v.to_str().ok())
    ));
    // http://blobfile.localhost/<encoded-abs-path> (Windows/Android),
    // blobfile://localhost/<encoded-abs-path>        (macOS/Linux)
    let path_part = match uri.find("localhost/") {
        Some(i) => &uri[i + "localhost/".len()..],
        None => return not_found("bad uri"),
    };
    let path_part = path_part.split('?').next().unwrap_or(path_part);
    let file = percent_decode(path_part);

    // Boot probe from media.js: an <img> load of this path proves the webview
    // dispatches custom-protocol requests at all (WebView2's media stack can
    // bypass them even when images through the same scheme work — the probe
    // is an <img>, so a 200 here vouches for the image pipeline exactly).
    // Anything answering keeps media on the loopback HTTP server chain.
    if path_part == "__velta-probe" {
        return tauri::http::Response::builder()
            .header("Content-Type", "text/plain")
            .header("Access-Control-Allow-Origin", "*")
            .header("Cache-Control", "no-store")
            .body(b"ok".to_vec())
            .unwrap();
    }

    // Only the app's own window may read blobs cross-origin; sandboxed
    // frames (webxdc, HTML viewer) arrive with `Origin: null` and are
    // refused (see media_cors).
    let acao = match media_cors(request.headers().get("origin").and_then(|v| v.to_str().ok())) {
        Ok(acao) => acao,
        Err(()) => {
            log("blobfile FORBIDDEN (foreign origin)");
            return tauri::http::Response::builder().status(403).body(b"forbidden".to_vec()).unwrap();
        }
    };
    let cors = |b: tauri::http::response::Builder| match &acao {
        Some(origin) => b.header("Access-Control-Allow-Origin", origin.as_str()).header("Vary", "Origin"),
        None => b,
    };

    // Only serve files that live inside the accounts directory (blobs,
    // uploads) -- never anything else on the filesystem. Canonicalize both
    // sides: on Android the core reports blobs under /data/user/0 (a symlink
    // to /data/data), so a raw prefix check would wrongly reject everything.
    let accounts = accounts_dir(app);
    let accounts_canon = std::fs::canonicalize(&accounts).unwrap_or(accounts.clone());
    let fpath = std::path::Path::new(&file);
    let fpath_canon = fpath.canonicalize().unwrap_or_else(|_| fpath.to_path_buf());
    log(&format!(
        "blobfile check: accounts_canon={} file_canon={}",
        accounts_canon.display(),
        fpath_canon.display()
    ));
    if !fpath_canon.starts_with(&accounts_canon) {
        log("blobfile FORBIDDEN");
        return not_found("forbidden");
    }
    let serve_path = fpath_canon.to_string_lossy().to_string();

    let meta = match std::fs::metadata(&serve_path) {
        Ok(m) if m.is_file() => m,
        _ => return not_found("not found"),
    };
    let len = meta.len();
    let mime = guess_mime(&serve_path);

    // Thumbnail request: `?w=N` (max dimension in px), full-body GETs only —
    // Range callers (video/audio seeking) always want the original. Only
    // statically-encodable formats are downscaled here; animated gif/webp and
    // everything else serve the original regardless of the query param.
    let thumb_w = if request.headers().get("range").is_none() {
        request
            .uri()
            .query()
            .and_then(|q| {
                q.split('&').find_map(|kv| kv.strip_prefix("w=")).and_then(|v| v.parse::<u32>().ok())
            })
            .filter(|w| (16..=2000).contains(w))
            .filter(|_| matches!(mime, "image/jpeg" | "image/png" | "image/bmp"))
    } else {
        None
    };

    if let Some(w) = thumb_w {
        if let Some(resp) = serve_thumbnail(&accounts, &serve_path, &meta, w, &acao) {
            return resp;
        }
    }

    if let Some(range) = request.headers().get("range").and_then(|v| v.to_str().ok().map(|s| s.to_string())) {
        if let Some((start, end)) = parse_range(&range, len) {
            use std::io::{Read, Seek, SeekFrom};
            let take = (end - start + 1) as usize;
            let mut buf = vec![0u8; take];
            let mut filled = 0usize;
            if let Ok(mut f) = std::fs::File::open(&serve_path) {
                if f.seek(SeekFrom::Start(start)).is_ok() {
                    while filled < take {
                        match f.read(&mut buf[filled..]) {
                            Ok(0) => break,
                            Ok(n) => filled += n,
                            Err(_) => break,
                        }
                    }
                }
            }
            buf.truncate(filled);
            return cors(tauri::http::Response::builder())
                .status(206)
                .header("Content-Type", mime)
                .header("Accept-Ranges", "bytes")
                .header("Access-Control-Expose-Headers", "Content-Range, Content-Length, Accept-Ranges")
                .header("Content-Range", format!("bytes {}-{}/{}", start, start + filled as u64 - 1, len))
                .header("Content-Length", filled)
                .body(buf)
                .unwrap();
        }
        return cors(tauri::http::Response::builder())
            .status(416)
            .header("Content-Range", format!("bytes */{}", len))
            .body(Vec::new())
            .unwrap();
    }

    match std::fs::read(&serve_path) {
        Ok(data) => cors(tauri::http::Response::builder())
            .status(200)
            .header("Content-Type", mime)
            .header("Accept-Ranges", "bytes")
            .header("Access-Control-Expose-Headers", "Content-Range, Content-Length, Accept-Ranges")
            .header("Content-Length", data.len())
            .body(data)
            .unwrap(),
        Err(_) => not_found("read error"),
    }
}

// ---------- blobfile thumbnails (?w=N) ----------
//
// Chat bubbles display photos at a few hundred px, but the WebView decodes
// the full 12 MP original for each row (tens of MB of bitmap RAM per image
// on Android). The frontend appends ?w=720 to bubble image URLs; this side
// downscales once to a JPEG in <accounts-dir>/../thumbs/ and serves that.
// Cache key = sha1(canonical source path + mtime + size + width), so an
// edited or re-saved source invalidates itself and every consumer can
// share the cache. Lightbox and video URLs carry no ?w and keep hitting the
// original bytes.

fn thumb_cache_path(accounts: &std::path::Path, source: &str, meta: &std::fs::Metadata, w: u32) -> std::path::PathBuf {
    use sha1::{Digest, Sha1};
    let mtime = meta
        .modified()
        .ok()
        .and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let mut h = Sha1::new();
    h.update(source.as_bytes());
    h.update(format!("|{mtime}|{}|{w}", meta.len()).as_bytes());
    let hex = data_encoding::HEXLOWER.encode(&h.finalize());
    accounts
        .parent()
        .unwrap_or(accounts)
        .join("thumbs")
        .join(format!("{hex}.jpg"))
}

// None = no thumbnail produced (source already small enough, undecodable, or
// read error) — the caller falls through to serving the original.
fn generate_thumbnail(bytes: &[u8], max_dim: u32) -> Option<Vec<u8>> {
    use image::ImageDecoder;
    let reader = image::ImageReader::new(std::io::Cursor::new(bytes)).with_guessed_format().ok()?;
    let mut decoder = reader.into_decoder().ok()?;
    let orientation = decoder
        .orientation()
        .unwrap_or(image::metadata::Orientation::NoTransforms);
    let mut img = image::DynamicImage::from_decoder(decoder).ok()?;
    img.apply_orientation(orientation);
    if img.width() <= max_dim && img.height() <= max_dim {
        return None;
    }
    let thumb = img.thumbnail(max_dim, max_dim);
    let mut out = Vec::new();
    let encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(&mut out, 80);
    thumb.to_rgb8().write_with_encoder(encoder).ok()?;
    Some(out)
}

fn jpeg_response(acao: &Option<String>, data: Vec<u8>) -> tauri::http::Response<Vec<u8>> {
    let b = tauri::http::Response::builder()
        .status(200)
        .header("Content-Type", "image/jpeg")
        .header("Accept-Ranges", "bytes")
        .header("Access-Control-Expose-Headers", "Content-Range, Content-Length, Accept-Ranges")
        .header("Content-Length", data.len());
    let b = match acao {
        Some(origin) => b.header("Access-Control-Allow-Origin", origin.as_str()).header("Vary", "Origin"),
        None => b,
    };
    b.body(data).unwrap()
}

// Some(resp) = thumbnail served (from cache or freshly generated); None =
// fall through to the original file.
fn serve_thumbnail(
    accounts: &std::path::Path,
    source: &str,
    meta: &std::fs::Metadata,
    w: u32,
    acao: &Option<String>,
) -> Option<tauri::http::Response<Vec<u8>>> {
    let data = load_thumbnail(accounts, source, meta, w)?;
    Some(jpeg_response(acao, data))
}

// Cache-or-generate. None = no thumbnail produced (source already small
// enough, undecodable, or read error) — the caller falls through to serving
// the original bytes.
fn load_thumbnail(
    accounts: &std::path::Path,
    source: &str,
    meta: &std::fs::Metadata,
    w: u32,
) -> Option<Vec<u8>> {
    let cache = thumb_cache_path(accounts, source, meta, w);
    if let Ok(data) = std::fs::read(&cache) {
        if data.starts_with(&[0xFF, 0xD8]) {
            log(&format!("thumb cache hit: {}", cache.display()));
            return Some(data);
        }
    }
    let original = std::fs::read(source).ok()?;
    let thumb = generate_thumbnail(&original, w)?;
    if let Some(dir) = cache.parent() {
        let _ = std::fs::create_dir_all(dir);
        // Write-then-rename so a concurrent first load never reads a torn file.
        let tmp = cache.with_extension("tmp");
        if std::fs::write(&tmp, &thumb).is_ok() {
            let _ = std::fs::rename(&tmp, &cache);
        }
    }
    log(&format!("thumb generated: {} ({} bytes)", cache.display(), thumb.len()));
    Some(thumb)
}

#[cfg(test)]
mod thumb_tests {
    use super::*;

    fn png_bytes(w: u32, h: u32) -> Vec<u8> {
        let img = image::DynamicImage::new_rgb8(w, h);
        let mut out = Vec::new();
        img.write_to(&mut std::io::Cursor::new(&mut out), image::ImageFormat::Png).unwrap();
        out
    }

    #[test]
    fn thumbnail_downscales_to_max_dimension_and_encodes_jpeg() {
        let thumb = generate_thumbnail(&png_bytes(4000, 3000), 720).expect("large image must produce a thumbnail");
        assert_eq!(&thumb[..2], &[0xFF, 0xD8], "output must be JPEG");
        let decoded = image::load_from_memory(&thumb).unwrap();
        assert_eq!(decoded.width(), 720);
        assert!(((decoded.height() as i64) - 540).abs() <= 1, "aspect preserved");
    }

    #[test]
    fn thumbnail_skips_images_already_within_bounds() {
        assert!(generate_thumbnail(&png_bytes(600, 400), 720).is_none(), "small image: serve the original");
    }

    #[test]
    fn thumbnail_rejects_undecodable_bytes() {
        assert!(generate_thumbnail(b"not an image", 720).is_none());
    }

    #[test]
    fn cache_key_tracks_path_size_and_width() {
        let dir = std::env::temp_dir().join(format!("velta-thumb-test-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let f = dir.join("probe.jpg");
        std::fs::write(&f, b"x").unwrap();
        let m = std::fs::metadata(&f).unwrap();
        let accounts = std::path::Path::new("/tmp");
        let a = thumb_cache_path(accounts, "/tmp/probe.jpg", &m, 720);
        let b = thumb_cache_path(accounts, "/tmp/probe.jpg", &m, 360);
        let c = thumb_cache_path(accounts, "/tmp/other.jpg", &m, 720);
        assert_ne!(a, b, "different widths must not share cache entries");
        assert_ne!(a, c, "different sources must not share cache entries");
        assert_eq!(a, thumb_cache_path(accounts, "/tmp/probe.jpg", &m, 720), "same inputs: stable key");
        let _ = std::fs::remove_dir_all(&dir);
    }
}

// ---------- Android: copy a picked content:// attachment to app storage ----------

// The system file picker returns content:// URIs that neither tauri-plugin-fs
// nor the Delta Chat core can read directly. Copy the bytes into our uploads
// directory via the Android ContentResolver and return the real path.
#[cfg(target_os = "android")]
static APP_JAVA_VM: Mutex<Option<jni::JavaVM>> = Mutex::new(None);

// ---------- local media HTTP server ----------
//
// WebView2 (Windows) does not fire WebResourceRequested for <video>/<audio>
// element requests, so custom protocols cannot serve media there. A loopback
// HTTP server with Range support works on every platform and every WebView.
static MEDIA_PORT: std::sync::atomic::AtomicU16 = std::sync::atomic::AtomicU16::new(0);
static MEDIA_TOKEN: Mutex<String> = Mutex::new(String::new());
static MEDIA_CONNECTIONS: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
const MEDIA_MAX_CONNECTIONS: usize = 64;

/// Releases a media-server connection slot when the serving thread ends,
/// panics included.
struct MediaConnectionSlot;

impl Drop for MediaConnectionSlot {
    fn drop(&mut self) {
        MEDIA_CONNECTIONS.fetch_sub(1, std::sync::atomic::Ordering::AcqRel);
    }
}

/// Compares the URL token with the server's without an early exit, so the
/// response time does not reveal how much of a guessed token matched.
fn constant_time_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    a.iter().zip(b).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

#[tauri::command]
fn media_base_url() -> String {
    // Runs on every platform now: the Android asset protocol serves the first
    // range chunk but fails mid-file reads (moov-at-end videos can't demux),
    // so <video> sources ride the loopback server everywhere.
    let port = MEDIA_PORT.load(std::sync::atomic::Ordering::Relaxed);
    let token = MEDIA_TOKEN.lock().unwrap().clone();
    format!("http://127.0.0.1:{port}/{token}")
}

// ---------- scoped media paths ----------

fn scoped_accounts_path(app: &tauri::AppHandle, path: &str) -> Result<PathBuf, String> {
    // The core returns paths RELATIVE to the accounts dir (e.g.
    // accounts\\<uuid>\\dc.db-blobs\\<hash>.mp4) while the process CWD is the
    // install dir - resolve before canonicalizing or every access fails with
    // os error 3.
    let p = std::path::Path::new(path);
    let absolute = if p.is_relative() {
        // the core nests uuid dirs under a literal 'accounts' subdir of
        // accounts_dir (observed on disk: accounts/accounts/<uuid>), so the
        // relative path is used as-is
        accounts_dir(app).join(p)
    } else {
        p.to_path_buf()
    };
    let canon = std::fs::canonicalize(&absolute).map_err(|e| e.to_string())?;
    // Canonicalize both sides: Windows canonical paths carry a \\?\ prefix
    // while the base dirs don't. Scope = the whole AppLocalData root, not
    // just the accounts subdir: uploads/ (resolve_upload_path) is a SIBLING
    // of accounts/ and legitimately holds picked attachments pre-send —
    // read_media_bytes must reach them too.
    use tauri::path::BaseDirectory;
    let base = app
        .path()
        .resolve(".", BaseDirectory::AppLocalData)
        .map_err(|e| e.to_string())?;
    let base_canon = std::fs::canonicalize(&base).unwrap_or(base);
    if !canon.starts_with(&base_canon) {
        return Err("path outside the app data directory".into());
    }
    // Strip the \\?\ prefix before returning: paths handed to the frontend
    // go through convertFileSrc, which percent-encodes it into asset URLs
    // (asset.localhost/%2F%2F%3F%2F... -> 404).
    let stripped = canon.to_string_lossy();
    let cleaned = stripped.strip_prefix(r"\\?\").map(String::from).unwrap_or_else(|| stripped.to_string());
    Ok(PathBuf::from(cleaned))
}

// read_media_bytes hands a full in-memory copy of the media to the WebView --
// refuse to buffer oversized files into the IPC layer.
const MAX_MEDIA_IPC_BYTES: u64 = 128 * 1024 * 1024;

fn checked_media_read(canon: &std::path::Path) -> Result<Vec<u8>, String> {
    let meta = std::fs::metadata(canon).map_err(|e| e.to_string())?;
    if meta.len() > MAX_MEDIA_IPC_BYTES {
        return Err(format!(
            "media file too large to read into memory ({} bytes > {MAX_MEDIA_IPC_BYTES})",
            meta.len()
        ));
    }
    std::fs::read(canon).map_err(|e| e.to_string())
}

#[tauri::command]
async fn read_media_bytes(app: tauri::AppHandle, src: String) -> Result<tauri::ipc::Response, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let canon = scoped_accounts_path(&app, &src)?;
        let bytes = checked_media_read(&canon)?;
        Ok(tauri::ipc::Response::new(bytes))
    })
    .await
    .map_err(|e| e.to_string())?
}

// ---------- notification chat-link token (issue #23) ----------
//
// velta://chat links switch account and open a chat with no confirm, so a
// web page that fires the scheme must not be able to mint one. Notifications
// append &t=<token>. The token is random, persistent (a toast or intent
// outlives this process), and stored in app-local data, which page JS
// cannot read. A per-process nonce would reject a tap after relaunch.

const CHAT_LINK_TOKEN_NAME: &str = "chat-link-token";
static CHAT_LINK_TOKEN: Mutex<Option<String>> = Mutex::new(None);

fn valid_chat_link_token(token: &str) -> bool {
    token.len() == 32 && token.bytes().all(|b| b.is_ascii_hexdigit())
}

fn mint_chat_link_token() -> String {
    data_encoding::HEXLOWER.encode(&random_bytes::<16>())
}

/// N bytes from the OS random source; panics if it fails (as rand's OsRng did).
pub(crate) fn random_bytes<const N: usize>() -> [u8; N] {
    let mut bytes = [0u8; N];
    getrandom::getrandom(&mut bytes).expect("OS random source unavailable");
    bytes
}

/// Read a token file, or create one. A missing or corrupt file is replaced.
/// The new file is renamed into place so two callers (the page fetching the
/// token, and a notification built at the same moment) publish one value:
/// the loser of the rename reads the winner's token. Other IO errors
/// propagate and do not rotate a token already on screen.
fn load_or_create_chat_link_token(path: &Path) -> Result<String, String> {
    match std::fs::read_to_string(path) {
        Ok(raw) if valid_chat_link_token(raw.trim()) => return Ok(raw.trim().to_string()),
        Ok(_) => {
            // Windows rename does not replace an existing file.
            let _ = std::fs::remove_file(path);
        }
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
        Err(e) => return Err(e.to_string()),
    }
    let token = mint_chat_link_token();
    match publish_chat_link_token(path, &token) {
        Ok(()) => Ok(token),
        Err(_) => match std::fs::read_to_string(path) {
            Ok(raw) if valid_chat_link_token(raw.trim()) => Ok(raw.trim().to_string()),
            Ok(_) => Err("chat-link-token is not valid".into()),
            Err(e) => Err(e.to_string()),
        },
    }
}

fn publish_chat_link_token(path: &Path, token: &str) -> Result<(), String> {
    if let Some(dir) = path.parent() {
        if !dir.as_os_str().is_empty() {
            std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
        }
    }
    let tmp = path.with_file_name(format!("{CHAT_LINK_TOKEN_NAME}.{token}.tmp"));
    std::fs::write(&tmp, token.as_bytes()).map_err(|e| e.to_string())?;
    match std::fs::rename(&tmp, path) {
        Ok(()) => Ok(()),
        Err(e) => {
            let _ = std::fs::remove_file(&tmp);
            Err(e.to_string())
        }
    }
}

fn chat_link_token_path(app: &tauri::AppHandle) -> PathBuf {
    use tauri::path::BaseDirectory;
    app.path()
        .resolve(CHAT_LINK_TOKEN_NAME, BaseDirectory::AppLocalData)
        .unwrap_or_else(|_| log_dir().join("..").join(CHAT_LINK_TOKEN_NAME))
}

// Same file as chat_link_token_path (app-local data = Context.getDataDir()),
// without an AppHandle: background notifications of a headless core.
#[cfg(target_os = "android")]
fn android_chat_link_token() -> Result<String, String> {
    if let Some(token) = CHAT_LINK_TOKEN.lock().unwrap().clone() {
        return Ok(token);
    }
    let dir = ANDROID_DATA_DIR.lock().unwrap().clone().ok_or("no data dir yet")?;
    let token = load_or_create_chat_link_token(&dir.join(CHAT_LINK_TOKEN_NAME))?;
    *CHAT_LINK_TOKEN.lock().unwrap() = Some(token.clone());
    Ok(token)
}

fn chat_link_token_for(app: &tauri::AppHandle) -> Result<String, String> {
    if let Some(token) = CHAT_LINK_TOKEN.lock().unwrap().clone() {
        return Ok(token);
    }
    let token = load_or_create_chat_link_token(&chat_link_token_path(app))?;
    *CHAT_LINK_TOKEN.lock().unwrap() = Some(token.clone());
    Ok(token)
}

// Only the Windows toast builds this link. macOS release builds deny dead
// code (`RUSTFLAGS: "-D warnings"`), so the helper has to stay on that cfg.
#[cfg(target_os = "windows")]
fn chat_link_with_token(account: u32, chat_id: u32, token: &str) -> String {
    format!("velta://chat?account={account}&chat={chat_id}&t={token}")
}

/// Drop `t=` values before they reach velta.log. The query delimiter has to
/// precede `t=`, so an unrelated path that happens to contain those letters
/// is left alone.
fn redact_chat_link(url: &str) -> String {
    let mut out = String::with_capacity(url.len());
    let mut rest = url;
    while let Some(rel) = rest.find(['?', '&']) {
        let (head, tail) = rest.split_at(rel + 1);
        out.push_str(head);
        if let Some(value) = tail.strip_prefix("t=") {
            out.push_str("t=…");
            let end = value.find(['&', '#']).unwrap_or(value.len());
            rest = &value[end..];
        } else {
            rest = tail;
        }
    }
    out.push_str(rest);
    out
}

#[tauri::command]
fn chat_link_token(app: tauri::AppHandle) -> Result<String, String> {
    chat_link_token_for(&app)
}

// ---------- incoming-message notifications ----------
//
// The WebView decides WHEN to notify (it knows document.hidden and which
// message is new); this command is only the bridge to the platform
// notification API. Tapping a notification opens its chat (issue #20): both
// platforms hand the WebView a velta://chat?account=<id>&chat=<id>&t=<token>
// link through the existing deep-link path (handleDeeplinkFromUrl in app.js
// checks the token, selects the account, then opens the chat). Android
// builds the link in Notifications.kt as a VIEW intent (surfaced here as
// RunEvent::Opened); Windows emits it from the toast's Activated handler
// below. macOS (plugin notification) still only focuses the app.

// Windows renders the conversation style directly through
// tauri-winrt-notification: up to three text lines (chat name / sender /
// message) plus the sender's avatar cropped circular in the app-logo slot —
// the desktop counterpart of the Android MessagingStyle layout. The AUMID is
// the config identifier, the same identity the notification plugin uses.
#[cfg(target_os = "windows")]
#[tauri::command]
#[allow(clippy::too_many_arguments)] // tauri command: one arg per JS field
fn notify_incoming(
    app: tauri::AppHandle,
    title: String,
    body: String,
    chat_name: Option<String>,
    sender_name: Option<String>,
    sender_avatar: Option<String>,
    account_id: Option<u32>,
    chat_id: Option<u32>,
) -> Result<(), String> {
    use tauri_winrt_notification::{IconCrop, Toast};

    let resolved_title = chat_name
        .as_deref()
        .filter(|s| !s.trim().is_empty())
        .unwrap_or(&title);
    let mut toast = Toast::new(app.config().identifier.as_str()).title(resolved_title);
    // The sender row is meaningful only in groups (1:1 sender == title).
    if let Some(sender) = sender_name.as_deref() {
        if !sender.is_empty() && sender != resolved_title {
            toast = toast.text1(sender);
        }
    }
    toast = toast.text2(&body);
    if let Some(avatar) = sender_avatar.as_deref() {
        let path = std::path::Path::new(avatar);
        if path.exists() {
            toast = toast.icon(path, IconCrop::Circular, "sender avatar");
        }
    }
    // Activation fires in-process while the app runs (toasts are only shown
    // when the window is hidden, so it normally does): bring the window back
    // and park the chat link. The page treats "deeplink" as a wake-up and
    // drains OPENED_URLS, so the link has to be queued or the tap is a no-op.
    // Without a token the toast still shows; its tap only focuses the app,
    // because the page would reject a bare velta://chat link.
    if let Some(chat_id) = chat_id.filter(|&id| id > 0) {
        let account = account_id.unwrap_or(0);
        match chat_link_token_for(&app) {
            Ok(token) => {
                let link = chat_link_with_token(account, chat_id, &token);
                toast = toast.on_activated(move |_action| {
                    focus_main_window(&app);
                    log(&format!("toast activated: {}", redact_chat_link(&link)));
                    queue_opened(link.clone());
                    app.emit("deeplink", link.clone()).ok();
                    Ok(())
                });
            }
            Err(e) => log(&format!("chat link token unavailable: {e}")),
        }
    }
    toast.show().map_err(|e| e.to_string())
}

// Restore and focus the main window on toast activation and on a share.
#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn focus_main_window(app: &tauri::AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        let _ = win.unminimize();
        let _ = win.show();
        let _ = win.set_focus();
    }
}

// The .lnk stores the target path as UTF-16. Recreate only when it does not
// point at this exe (install moved, or dev and release traded the shortcut).
#[cfg(any(windows, test))]
fn lnk_points_at(link: &Path, exe: &Path) -> bool {
    let Ok(bytes) = std::fs::read(link) else {
        return false;
    };
    let needle: Vec<u8> = exe.to_string_lossy().encode_utf16().flat_map(|c| c.to_le_bytes()).collect();
    !needle.is_empty() && bytes.windows(needle.len()).any(|w| w == needle)
}

// ponytail: the Windows 11 Share flyout only lists packaged share targets.
// Send to is the menu an unpackaged exe can join. MSIX shareTarget if we
// ever ship a package identity.
#[cfg(windows)]
fn ensure_sendto_shortcut() {
    let Ok(exe) = std::env::current_exe() else { return };
    let Ok(appdata) = std::env::var("APPDATA") else { return };
    let link = PathBuf::from(appdata).join(r"Microsoft\Windows\SendTo").join("Velta.lnk");
    if lnk_points_at(&link, &exe) {
        return;
    }
    let Some(parent) = link.parent() else { return };
    if std::fs::create_dir_all(parent).is_err() {
        return;
    }
    let q = |s: &str| format!("'{}'", s.replace('\'', "''"));
    let script = format!(
        "$s=(New-Object -ComObject WScript.Shell).CreateShortcut({});$s.TargetPath={};$s.Description='Share to Velta';$s.Save()",
        q(&link.display().to_string()),
        q(&exe.display().to_string()),
    );
    let mut cmd = Command::new("powershell");
    cmd.args(["-NoProfile", "-NonInteractive", "-Command", &script]);
    cmd.creation_flags(CREATE_NO_WINDOW);
    if let Err(e) = cmd.spawn() {
        log(&format!("sendto shortcut: {e}"));
    }
}

#[cfg(not(target_os = "windows"))]
#[tauri::command]
fn notify_incoming(app: tauri::AppHandle, title: String, body: String) -> Result<(), String> {
    use tauri_plugin_notification::NotificationExt;
    app.notification()
        .builder()
        .title(title)
        .body(body)
        .show()
        .map_err(|e| e.to_string())
}

// ---------- background event draining (Android) ----------

// Whether the frontend UI can currently process core events itself. The JS
// side reports visibility via set_ui_visible. On Android that flag alone is
// not enough: pressing Home often leaves document.hidden false while the
// WebView's JS is frozen, so the poller would stay asleep.
static UI_VISIBLE: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

// MainActivity onStart/onStop. Default true so a poller that starts during
// launch does not treat the app as backgrounded before the activity exists.
#[cfg(target_os = "android")]
static ACTIVITY_FOREGROUND: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(true);

#[cfg(target_os = "android")]
fn android_ui_visible() -> bool {
    bg_events::background_poller_paused(
        UI_VISIBLE.load(std::sync::atomic::Ordering::SeqCst),
        ACTIVITY_FOREGROUND.load(std::sync::atomic::Ordering::SeqCst),
    )
}

#[tauri::command]
fn set_ui_visible(visible: bool) {
    UI_VISIBLE.store(visible, std::sync::atomic::Ordering::SeqCst);
}

// ---------- single event reader (Android, #40 / #52) ----------
//
// The Android shell owns get_next_event_batch: the page's rpc-core skips
// its own poll once get_event_reader_mode() says "rust", and the Rust
// poller routes every batch by visibility — forwarded to the page while
// the UI is up, notified natively while hidden. The handshake below keeps
// the poller from forwarding into a receiver the page has not installed
// yet (the Tauri listen() subscription can lag boot by seconds), and it
// aligns the visibility flag in the same round trip so the first polls
// cannot notify while the app is foreground.
#[cfg(target_os = "android")]
static EVENTS_LISTENER_READY: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

#[tauri::command]
fn get_event_reader_mode() -> &'static str {
    #[cfg(target_os = "android")]
    {
        "rust"
    }
    #[cfg(not(target_os = "android"))]
    {
        "webview"
    }
}

#[cfg(target_os = "android")]
#[tauri::command]
fn events_listener_ready(visible: bool) {
    EVENTS_LISTENER_READY.store(true, std::sync::atomic::Ordering::SeqCst);
    UI_VISIBLE.store(visible, std::sync::atomic::Ordering::SeqCst);
    log("events listener ready");
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn events_listener_ready(_visible: bool) {}

#[cfg(target_os = "android")]
#[tauri::command]
fn battery_optimization_exempt() -> bool {
    match battery_is_exempt() {
        Ok(exempt) => exempt,
        Err(e) => {
            log(&format!("battery exemption check failed: {e}"));
            false
        }
    }
}

// ---------------- notification preferences (drawer → shell → poller) ----------------
//
// The drawer owns nine switches; the page persists them in localStorage for
// its own gates AND pushes the full set here. The shell keeps the
// authoritative copy in `notify-prefs.json` (app local data — on Android the
// same filesDir the Kotlin BackgroundFetchJob reads directly) because the
// background poller posts notifications while the page is frozen and cannot
// run a JS gate.

#[derive(serde::Deserialize, serde::Serialize, Clone, Copy)]
#[serde(default)]
struct NotifyPrefs {
    enabled: bool,          // master: any message notification at all
    mentions_only: bool,    // only messages that mention the user
    mentions_in_muted: bool, // muted chats still notify on an @mention of me (default on)
    show_content: bool,     // message text in the preview
    system_new_msgs: bool,  // OS notification layer for new messages
    vibration: bool,        // Android channel
    in_chat_sounds: bool,   // Android channel
    calls: bool,            // call-related notifications
    use_bg_connection: bool, // Android: periodic background fetch stays on
    force_bg_connection: bool, // Android: battery exemption requested
}

impl Default for NotifyPrefs {
    fn default() -> Self {
        Self {
            enabled: true,
            mentions_only: false,
            mentions_in_muted: true,
            show_content: true,
            system_new_msgs: true,
            vibration: true,
            in_chat_sounds: true,
            calls: true,
            use_bg_connection: true,
            force_bg_connection: false,
        }
    }
}

static NOTIFY_PREFS: std::sync::Mutex<Option<NotifyPrefs>> = std::sync::Mutex::new(None);

fn notify_prefs_path(app: &tauri::AppHandle) -> Option<PathBuf> {
    let dir = app.path().app_local_data_dir().ok()?;
    Some(dir.join("notify-prefs.json"))
}

// Also written to the filesDir root under a stable name: the Kotlin
// BackgroundFetchJob reads THIS copy (context.filesDir), the Rust poller
// reads the static loaded from the local-data copy.
fn notify_prefs_files_dir_copy(app: &tauri::AppHandle, json: &str) {
    #[cfg(target_os = "android")]
    if let Ok(dir) = app.path().resolve("notify-prefs.json", tauri::path::BaseDirectory::AppData) {
        let _ = std::fs::write(dir, json);
    }
    #[cfg(not(target_os = "android"))]
    let _ = (app, json);
}

// Headless Android start: no AppHandle, same file (dataDir/notify-prefs.json).
#[cfg(target_os = "android")]
fn notify_prefs_load_path(path: &Path) {
    if let Ok(json) = std::fs::read_to_string(path) {
        match serde_json::from_str::<NotifyPrefs>(&json) {
            Ok(prefs) => *NOTIFY_PREFS.lock().unwrap() = Some(prefs),
            Err(e) => log(&format!("notify prefs parse failed ({e}); using defaults")),
        }
    }
}

fn notify_prefs_load(app: &tauri::AppHandle) {
    let Some(path) = notify_prefs_path(app) else { return };
    match std::fs::read_to_string(&path) {
        Ok(json) => match serde_json::from_str::<NotifyPrefs>(&json) {
            Ok(prefs) => {
                *NOTIFY_PREFS.lock().unwrap() = Some(prefs);
                notify_prefs_files_dir_copy(app, &json);
            }
            Err(e) => log(&format!("notify prefs parse failed ({e}); using defaults")),
        },
        Err(_) => { /* first run — defaults until the page pushes */ }
    }
}

// Read by the Android background poller and bg notifications only.
#[cfg(target_os = "android")]
fn notify_prefs_snapshot() -> NotifyPrefs {
    NOTIFY_PREFS
        .lock()
        .unwrap()
        .unwrap_or_default()
}

#[tauri::command]
fn set_notify_prefs(app: tauri::AppHandle, prefs: NotifyPrefs) -> Result<(), String> {
    #[cfg(target_os = "android")]
    let was_bg = NOTIFY_PREFS.lock().unwrap().unwrap_or_default().use_bg_connection;
    *NOTIFY_PREFS.lock().unwrap() = Some(prefs);
    let json = serde_json::to_string(&prefs).map_err(|e| e.to_string())?;
    if let Some(path) = notify_prefs_path(&app) {
        if let Some(parent) = path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        std::fs::write(&path, &json).map_err(|e| e.to_string())?;
    }
    notify_prefs_files_dir_copy(&app, &json);
    // "Use background connection" toggled: stop / start CoreService so the
    // persistent notification goes away when the user turned it off (the
    // file above is written first: the service re-reads it on start).
    #[cfg(target_os = "android")]
    if was_bg != prefs.use_bg_connection {
        android_core_service(prefs.use_bg_connection);
    }
    Ok(())
}

#[cfg(target_os = "android")]
fn android_core_service(run: bool) {
    let method = if run { "start" } else { "stop" };
    let r = with_android_class(&APP_CORE_SERVICE_CLASS, "CoreService", |env, context, class_ref| {
        env.call_static_method(class_ref, method, "(Landroid/content/Context;)V", &[(&context).into()])
            .map_err(|e| e.to_string())?;
        Ok(())
    });
    match r {
        Ok(()) => log(&format!("background connection {}: CoreService {method}", if run { "on" } else { "off" })),
        Err(e) => log(&format!("CoreService {method} failed: {e}")),
    }
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn battery_optimization_exempt() -> bool {
    true
}

// Build.MANUFACTURER for the battery prompt's dontkillmyapp.com link.
#[cfg(target_os = "android")]
#[tauri::command]
fn device_maker() -> String {
    with_android_class(&APP_BATTERY_CLASS, "Battery", |env, _context, class_ref| {
        let out = env
            .call_static_method(class_ref, "maker", "()Ljava/lang/String;", &[])
            .map_err(|e| e.to_string())?;
        let jstr = jni::objects::JString::from(out.l().map_err(|e| e.to_string())?);
        let maker = env.get_string(&jstr).map_err(|e| e.to_string())?.to_string_lossy().into_owned();
        Ok(maker)
    })
    .unwrap_or_default()
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn device_maker() -> String {
    String::new()
}

#[cfg(target_os = "android")]
#[tauri::command]
fn request_battery_exemption() -> Result<(), String> {
    battery_request_exemption()
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn request_battery_exemption() -> Result<(), String> {
    Err("battery settings are only on Android".into())
}

#[cfg(target_os = "android")]
#[tauri::command]
fn install_update(path: String) -> Result<(), String> {
    install_update_android(path)
}

/// #83: battery level + charging state ("level|charging") for the frontend's
/// low-battery marker (🪫 reaction on the latest outgoing message).
#[cfg(target_os = "android")]
#[tauri::command]
fn get_battery_status() -> Result<String, String> {
    with_android_class(&APP_BATTERY_CLASS, "Battery", |env, context, class_ref| {
        let out = env
            .call_static_method(
                class_ref,
                "status",
                "(Landroid/content/Context;)Ljava/lang/String;",
                &[(&context).into()],
            )
            .map_err(|e| e.to_string())?;
        let jstr = jni::objects::JString::from(out.l().map_err(|e| e.to_string())?);
        // Bind to a local: a tail-expression temporary would outlive the JVM
        // guard's borrow (E0597).
        let s = env
            .get_string(&jstr)
            .map_err(|e| e.to_string())?
            .to_string_lossy()
            .into_owned();
        Ok(s)
    })
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn get_battery_status() -> Result<String, String> {
    Err("battery status is only on Android".into())
}

/// #141: call audio route (CallAudio.kt). `call_audio_start` sets
/// MODE_IN_COMMUNICATION + voice-call focus and routes to the loudspeaker
/// (`speaker`) or the earpiece — a connected headset wins over the earpiece;
/// `call_audio_speaker` switches; `call_audio_stop` restores MODE_NORMAL.
/// `auto` (start: default true, speaker: default false) lets a connected
/// headset keep the audio when the loudspeaker is asked for automatically
/// (video calls, camera on). start/speaker return the route in use ("earpiece", "speaker", "wired",
/// "usb", "bluetooth", "none") for the page's debug log.
#[cfg(target_os = "android")]
fn call_audio_route(method: &str, speaker: bool, auto: bool) -> Result<String, String> {
    with_android_class(&APP_CALL_AUDIO_CLASS, "CallAudio", |env, context, class_ref| {
        let out = env
            .call_static_method(
                class_ref,
                method,
                "(Landroid/content/Context;ZZ)Ljava/lang/String;",
                &[
                    (&context).into(),
                    jni::objects::JValue::Bool(speaker as u8),
                    jni::objects::JValue::Bool(auto as u8),
                ],
            )
            .map_err(|e| e.to_string())?;
        let jstr = jni::objects::JString::from(out.l().map_err(|e| e.to_string())?);
        let s = env.get_string(&jstr).map_err(|e| e.to_string())?.to_string_lossy().into_owned();
        Ok(s)
    })
}

#[cfg(target_os = "android")]
#[tauri::command]
fn call_audio_start(speaker: bool, auto: Option<bool>) -> Result<String, String> {
    let auto = auto.unwrap_or(true);
    let r = call_audio_route("start", speaker, auto);
    log(&format!("[call] audio start speaker={speaker} auto={auto} -> {r:?}"));
    r
}

#[cfg(target_os = "android")]
#[tauri::command]
fn call_audio_speaker(on: bool, auto: Option<bool>) -> Result<String, String> {
    let auto = auto.unwrap_or(false);
    let r = call_audio_route("setSpeaker", on, auto);
    log(&format!("[call] audio speaker={on} auto={auto} -> {r:?}"));
    r
}

#[cfg(target_os = "android")]
#[tauri::command]
fn call_audio_stop() -> Result<(), String> {
    let r = with_android_class(&APP_CALL_AUDIO_CLASS, "CallAudio", |env, context, class_ref| {
        env.call_static_method(class_ref, "stop", "(Landroid/content/Context;)V", &[(&context).into()])
            .map_err(|e| e.to_string())?;
        Ok(())
    });
    log(&format!("[call] audio stop -> {r:?}"));
    r
}

/// Calls: mic/camera runtime permission (CallPermissions.kt). `kind` is
/// "camera" or "microphone"; `request` shows the OS dialog when it can.
/// Returns "granted" | "pending" | "prompt" | "blocked".
#[cfg(target_os = "android")]
#[tauri::command]
fn call_permission(kind: String, request: bool) -> Result<String, String> {
    let r = with_android_class(&APP_CALL_PERMISSIONS_CLASS, "CallPermissions", |env, context, class_ref| {
        let jkind = env.new_string(&kind).map_err(|e| e.to_string())?;
        let out = env
            .call_static_method(
                class_ref,
                "check",
                "(Landroid/content/Context;Ljava/lang/String;Z)Ljava/lang/String;",
                &[(&context).into(), (&jkind).into(), jni::objects::JValue::Bool(request as u8)],
            )
            .map_err(|e| e.to_string())?;
        let jstr = jni::objects::JString::from(out.l().map_err(|e| e.to_string())?);
        let s = env.get_string(&jstr).map_err(|e| e.to_string())?.to_string_lossy().into_owned();
        Ok(s)
    });
    if !matches!(r.as_deref(), Ok("pending")) {
        log(&format!("[call] permission {kind} request={request} -> {r:?}"));
    }
    r
}

// Desktop/PWA: the browser prompt at getUserMedia is the mechanism.
#[cfg(not(target_os = "android"))]
#[tauri::command]
fn call_permission(kind: String, request: bool) -> Result<String, String> {
    let _ = (kind, request);
    Ok("prompt".into())
}

// Desktop has no earpiece: the page hides the speaker button off Android.
#[cfg(not(target_os = "android"))]
#[tauri::command]
fn call_audio_start(speaker: bool, auto: Option<bool>) -> Result<String, String> {
    let _ = (speaker, auto);
    Err("call audio routing is only on Android".into())
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn call_audio_speaker(on: bool, auto: Option<bool>) -> Result<String, String> {
    let _ = (on, auto);
    Err("call audio routing is only on Android".into())
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn call_audio_stop() -> Result<(), String> {
    Err("call audio routing is only on Android".into())
}

/// #140: UnifiedPush state for Settings → Push notifications, as the JSON
/// string UnifiedPushBridge.status builds (distributors with app labels,
/// saved distributor, explicit Off, last push / endpoint time in ms).
#[cfg(target_os = "android")]
#[tauri::command]
fn push_status() -> Result<String, String> {
    with_android_class(&APP_UNIFIEDPUSH_CLASS, "UnifiedPushBridge", |env, context, class_ref| {
        let out = env
            .call_static_method(class_ref, "status", "(Landroid/content/Context;)Ljava/lang/String;", &[(&context).into()])
            .map_err(|e| e.to_string())?;
        let jstr = jni::objects::JString::from(out.l().map_err(|e| e.to_string())?);
        let s = env.get_string(&jstr).map_err(|e| e.to_string())?.to_string_lossy().into_owned();
        Ok(s)
    })
}

/// #140: use this distributor now (saveDistributor + register).
#[cfg(target_os = "android")]
#[tauri::command]
fn push_select(package: String) -> Result<(), String> {
    with_android_class(&APP_UNIFIEDPUSH_CLASS, "UnifiedPushBridge", |env, context, class_ref| {
        let jpkg = env.new_string(&package).map_err(|e| e.to_string())?;
        env.call_static_method(class_ref, "select", "(Landroid/content/Context;Ljava/lang/String;)V", &[(&context).into(), (&jpkg).into()])
            .map_err(|e| e.to_string())?;
        Ok(())
    })
}

/// #140: explicit Off (unregister + removeDistributor, persisted so the
/// start-up auto-register does not override it).
#[cfg(target_os = "android")]
#[tauri::command]
fn push_off() -> Result<(), String> {
    with_android_class(&APP_UNIFIEDPUSH_CLASS, "UnifiedPushBridge", |env, context, class_ref| {
        env.call_static_method(class_ref, "off", "(Landroid/content/Context;)V", &[(&context).into()])
            .map_err(|e| e.to_string())?;
        Ok(())
    })
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn push_status() -> Result<String, String> {
    Err("push settings are only on Android".into())
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn push_select(package: String) -> Result<(), String> {
    let _ = package;
    Err("push settings are only on Android".into())
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn push_off() -> Result<(), String> {
    Err("push settings are only on Android".into())
}

/// #37: system share sheet for a plain-text payload (the QR screen's "Share a
/// link"), via Share.kt. Desktop/Windows use the page's Web Share API instead.
#[cfg(target_os = "android")]
#[tauri::command]
fn share_text(text: String, title: String) -> Result<(), String> {
    with_android_class(&APP_SHARE_CLASS, "Share", |env, context, class_ref| {
        let text_j = env.new_string(text).map_err(|e| e.to_string())?;
        let title_j = env.new_string(title).map_err(|e| e.to_string())?;
        let shown = env
            .call_static_method(
                class_ref,
                "text",
                "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z",
                &[(&context).into(), (&text_j).into(), (&title_j).into()],
            )
            .map_err(|e| e.to_string())?
            .z()
            .map_err(|e| e.to_string())?;
        if shown { Ok(()) } else { Err("no app can handle the share request".into()) }
    })
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn share_text(_text: String, _title: String) -> Result<(), String> {
    Err("native sharing is only on Android".into())
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
fn install_update(_path: String) -> Result<(), String> {
    Err("in-app APK updates are Android-only".into())
}

fn start_media_server(accounts: PathBuf) {
    std::thread::Builder::new()
        .name("media-http".into())
        .spawn(move || {
            // An ephemeral port, never a fixed one: two Velta builds on one
            // device (e.g. a fork installed next to the store app) used to
            // race for 20810, and the loser's media URLs were CSP-blocked.
            // The CSP allows http://127.0.0.1:* for this reason; the
            // per-launch token below is what keeps other local processes out.
            let listener = match std::net::TcpListener::bind("127.0.0.1:0") {
                Ok(l) => l,
                Err(e) => {
                    log(&format!("media server bind failed: {e}"));
                    return;
                }
            };
            let port = match listener.local_addr() {
                Ok(a) => a.port(),
                Err(_) => return,
            };
            MEDIA_PORT.store(port, std::sync::atomic::Ordering::Relaxed);
            log(&format!("media http server on 127.0.0.1:{port}"));
            for stream in listener.incoming() {
                let Ok(mut stream) = stream else { continue };
                // Any local process can connect to a loopback port: cap the
                // thread-per-connection fan-out so one can't exhaust threads.
                // The WebView needs a handful (images + a few media ranges).
                if MEDIA_CONNECTIONS.fetch_add(1, std::sync::atomic::Ordering::AcqRel) >= MEDIA_MAX_CONNECTIONS {
                    MEDIA_CONNECTIONS.fetch_sub(1, std::sync::atomic::Ordering::AcqRel);
                    eprintln!("[media] connection limit reached; dropping one");
                    continue;
                }
                let accounts = accounts.clone();
                std::thread::spawn(move || {
                    let _slot = MediaConnectionSlot;
                    // Connection-level diagnostics reach logcat via stderr.
                    let peer = stream.peer_addr().map(|a| a.to_string()).unwrap_or_else(|_| "?".into());
                    eprintln!("[media] accept from {peer}");
                    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        serve_media_connection(&mut stream, &accounts);
                    }));
                    if result.is_err() {
                        eprintln!("[media] serve_media_connection PANICKED for {peer}");
                    }
                    eprintln!("[media] done {peer}");
                });
            }
        })
        .ok();
}

fn serve_media_connection(stream: &mut std::net::TcpStream, accounts: &PathBuf) {
    use std::io::{Read, Seek, SeekFrom, Write};
    let _ = stream.set_read_timeout(Some(std::time::Duration::from_secs(10)));

    // Read the request head (request line + headers) up to the blank line.
    // The terminator must be spelled with escapes: a raw CR/LF inside the
    // literal is normalized by rustc to a bare "\n\n", which never matches a
    // 4-byte window -- every request then sat until the 10 s read timeout.
    let mut head = Vec::new();
    let mut buf = [0u8; 2048];
    loop {
        match stream.read(&mut buf) {
            Ok(0) => break,
            Ok(n) => {
                head.extend_from_slice(&buf[..n]);
                if head.windows(4).any(|w| w == b"\r\n\r\n") || head.len() > 64 * 1024 {
                    break;
                }
            }
            Err(_) => break,
        }
    }
    let head = String::from_utf8_lossy(&head);
    let mut lines = head.split("\r\n");
    let request_line = lines.next().unwrap_or("");
    let mut path = "";
    let mut range: Option<String> = None;
    let mut origin: Option<String> = None;
    for part in request_line.split(' ') {
        if part.starts_with('/') {
            path = part;
        }
    }
    for line in lines {
        let Some((name, value)) = line.split_once(':') else { continue };
        let value = value.trim();
        if name.eq_ignore_ascii_case("range") {
            range = Some(value.to_string());
        } else if name.eq_ignore_ascii_case("origin") {
            origin = Some(value.to_string());
        }
    }

    let mut not_found = || {
        let _ = stream.write_all(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
    };

    // Same CORS gate as the blobfile protocol: sandboxed frames send
    // `Origin: null` and must not read account files (see media_cors).
    let cors = match media_cors(origin.as_deref()) {
        Ok(Some(o)) => format!("Access-Control-Allow-Origin: {o}\r\nVary: Origin\r\n"),
        Ok(None) => String::new(),
        Err(()) => {
            eprintln!("[media] 403: foreign origin {origin:?}");
            return not_found();
        }
    };

    // path: /<token>/<percent-encoded-abs-path>
    let rest = match path.split_once('/') {
        Some((_, rest)) => rest,
        None => return not_found(),
    };
    let token = MEDIA_TOKEN.lock().unwrap().clone();
    let (url_token, enc_path) = match rest.split_once('/') {
        Some(v) => v,
        None => {
            eprintln!("[media] 404: no token/path separator in {path:?}");
            return not_found();
        }
    };
    // A literal '?' is a query separator (encodeURIComponent encodes any in
    // the path itself as %3F) — the thumbnail param lives there.
    let (enc_path, query) = match enc_path.split_once('?') {
        Some((p, q)) => (p, Some(q.to_string())),
        None => (enc_path, None),
    };
    if !constant_time_eq(url_token.as_bytes(), token.as_bytes()) {
        eprintln!("[media] 404: token mismatch");
        return not_found();
    }
    let file = percent_decode(enc_path);
    eprintln!("[media] request {file} range={range:?}");

    let accounts_canon = std::fs::canonicalize(accounts).unwrap_or_else(|_| accounts.clone());
    let fpath = std::path::Path::new(&file);
    let fpath_canon = fpath.canonicalize().unwrap_or_else(|_| fpath.to_path_buf());
    if !fpath_canon.starts_with(&accounts_canon) {
        return not_found();
    }
    let serve_path = fpath_canon.to_string_lossy().to_string();
    let meta = match std::fs::metadata(&serve_path) {
        Ok(m) if m.is_file() => m,
        _ => return not_found(),
    };
    let len = meta.len();
    let mime = guess_mime(&serve_path);

    // Same thumbnail contract as the blobfile protocol: `?w=N` on a plain
    // GET downscales once and caches; Range callers and every other format
    // get the original bytes.
    let thumb_w = if range.is_none() {
        query
            .as_deref()
            .and_then(|q| q.split('&').find_map(|kv| kv.strip_prefix("w=")).and_then(|v| v.parse::<u32>().ok()))
            .filter(|w| (16..=2000).contains(w))
            .filter(|_| matches!(mime, "image/jpeg" | "image/png" | "image/bmp"))
    } else {
        None
    };
    if let Some(w) = thumb_w {
        if let Some(data) = load_thumbnail(accounts, &serve_path, &meta, w) {
            let head = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nAccept-Ranges: bytes\r\n{cors}Content-Length: {}\r\nConnection: close\r\n\r\n",
                data.len()
            );
            let _ = stream.write_all(head.as_bytes());
            let _ = stream.write_all(&data);
            return;
        }
    }

    let mut file = match std::fs::File::open(&serve_path) {
        Ok(f) => f,
        Err(_) => return not_found(),
    };

    // Range request: seek to the offset and stream exactly the requested
    // interval. (The old path truncated the file from byte 0 without seeking,
    // serving the wrong bytes labelled as start-end and breaking video
    // seeking / moov-at-end demuxing.) An unusable Range header gets 416 --
    // never a whole-file read.
    if let Some(header) = &range {
        let Some((start, end)) = parse_range(header, len) else {
            let _ = stream.write_all(
                format!(
                    "HTTP/1.1 416 Range Not Satisfiable\r\n{cors}Content-Range: bytes */{len}\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
                )
                .as_bytes(),
            );
            return;
        };
        let take = end - start + 1;
        if file.seek(SeekFrom::Start(start)).is_err() {
            return not_found();
        }
        let headers = format!(
            "HTTP/1.1 206 Partial Content\r\nContent-Type: {mime}\r\nAccept-Ranges: bytes\r\n{cors}Content-Range: bytes {start}-{end}/{len}\r\nContent-Length: {take}\r\nConnection: close\r\n\r\n"
        );
        if stream.write_all(headers.as_bytes()).is_err() {
            return;
        }
        let mut remaining = take;
        let mut chunk = [0u8; 64 * 1024];
        while remaining > 0 {
            let want = std::cmp::min(chunk.len() as u64, remaining) as usize;
            match file.read(&mut chunk[..want]) {
                Ok(0) => break,
                Ok(n) => {
                    if stream.write_all(&chunk[..n]).is_err() {
                        break;
                    }
                    remaining -= n as u64;
                }
                Err(_) => break,
            }
        }
        let _ = stream.flush();
        return;
    }

    // Full GET: stream in chunks -- a large video must never be buffered whole.
    let headers = format!(
        "HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\nAccept-Ranges: bytes\r\n{cors}Content-Length: {len}\r\nConnection: close\r\n\r\n"
    );
    if stream.write_all(headers.as_bytes()).is_err() {
        return;
    }
    let mut chunk = [0u8; 64 * 1024];
    loop {
        match file.read(&mut chunk) {
            Ok(0) => break,
            Ok(n) => {
                if stream.write_all(&chunk[..n]).is_err() {
                    break;
                }
            }
            Err(_) => break,
        }
    }
    let _ = stream.flush();
}
/// Android JNI entry for the shell commands: locks the application context,
/// then the JVM, attaches the current thread and runs `f` with the env and
/// the context. Lock order (APP_CONTEXT -> APP_JAVA_VM -> class cache in
/// with_android_class) is the one every command used before this helper;
/// keep it, or two commands can deadlock.
#[cfg(target_os = "android")]
fn with_android_env<R>(
    f: impl FnOnce(&mut jni::JNIEnv<'_>, &jni::objects::JObject<'_>) -> Result<R, String>,
) -> Result<R, String> {
    let ctx_guard = APP_CONTEXT.lock().unwrap();
    let context = ctx_guard
        .as_ref()
        .map(|r| r.as_obj())
        .ok_or("application context was not handed over yet")?;
    let vm_guard = APP_JAVA_VM.lock().unwrap();
    let vm_ref = vm_guard.as_ref().ok_or("jvm was not handed over yet")?;
    let mut env = vm_ref.attach_current_thread().map_err(|e| format!("jvm attach: {e}"))?;
    f(&mut env, context)
}

/// with_android_env plus one of the Kotlin helper classes cached at startup
/// (setApplicationContext); `name` only feeds the not-cached error.
#[cfg(target_os = "android")]
fn with_android_class<R>(
    class: &Mutex<Option<jni::objects::GlobalRef>>,
    name: &str,
    f: impl FnOnce(&mut jni::JNIEnv<'_>, &jni::objects::JObject<'_>, &jni::objects::GlobalRef) -> Result<R, String>,
) -> Result<R, String> {
    with_android_env(|env, context| {
        let class_guard = class.lock().unwrap();
        let class_ref = class_guard
            .as_ref()
            .ok_or_else(|| format!("{name} class was not cached at startup"))?;
        f(env, context, class_ref)
    })
}

#[cfg(target_os = "android")]
static APP_CONTEXT: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.InAppBrowser cached as a global ref: JNI FindClass for app
// classes is unreliable from Rust worker threads attached via
// attach_current_thread (wrong classloader context), so it is resolved once
// in setApplicationContext while running on a Java thread.
#[cfg(target_os = "android")]
static APP_INAPP_BROWSER_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.Notifications cached as a global ref for the same classloader
// reason as APP_INAPP_BROWSER_CLASS: messaging-style incoming-message
// notifications are posted from Rust through this Kotlin helper.
#[cfg(target_os = "android")]
static APP_NOTIFICATIONS_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.Battery — isExempt / request. Cached here for the same
// classloader reason: the commands run on a Rust worker thread.
#[cfg(target_os = "android")]
static APP_BATTERY_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);
#[cfg(target_os = "android")]
static APP_NETINFO_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.UpdateInstall — #60: hands a downloaded APK to the system
// package installer. Cached for the same classloader reason as above.
#[cfg(target_os = "android")]
static APP_UPDATE_INSTALL_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.Share — #37: system share sheet for the QR screen's invite link.
#[cfg(target_os = "android")]
static APP_SHARE_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.UnifiedPushBridge — #140 Settings → Push notifications
// (distributor list/picker, explicit Off, last push time).
#[cfg(target_os = "android")]
static APP_UNIFIEDPUSH_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.ScheduledAlarm — scheduled messages: alarm re-arm + exact-alarm
// permission (scheduled.rs).
#[cfg(target_os = "android")]
static APP_SCHEDULED_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.VeltaKeystore — #178 phase 2: DEK custody for database
// encryption at rest (AndroidKeyStore KEK + wrapped blob in noBackupFilesDir).
#[cfg(target_os = "android")]
static APP_KEYSTORE_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);
// #178 phase 4: the biometric app lock (VeltaLock.kt).
#[cfg(target_os = "android")]
static APP_LOCK_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.CallAudio — #141 call audio route (earpiece / loudspeaker /
// headset, MODE_IN_COMMUNICATION while a call is up).
#[cfg(target_os = "android")]
static APP_CALL_AUDIO_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.CallPermissions — mic/camera runtime permission for calls.
#[cfg(target_os = "android")]
static APP_CALL_PERMISSIONS_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// org.velta.CoreService — start/stop when "Use background connection" flips.
#[cfg(target_os = "android")]
static APP_CORE_SERVICE_CLASS: Mutex<Option<jni::objects::GlobalRef>> = Mutex::new(None);

// --- UnifiedPush (Android) ---
// Handles for the JNI callbacks from UnifiedPushService.kt. The accounts
// manager and the request channel are set once init_android_core finishes;
// a push endpoint arriving earlier is parked in PENDING_PUSH_TOKEN and
// applied at the end of that function. The app handle gives the push
// wake-up access to managed state.
#[cfg(target_os = "android")]
static ANDROID_ACCOUNTS: Mutex<Option<std::sync::Arc<tokio::sync::RwLock<deltachat_jsonrpc::api::Accounts>>>>
    = Mutex::new(None);
#[cfg(target_os = "android")]
static PENDING_PUSH_TOKEN: Mutex<Option<String>> = Mutex::new(None);
#[cfg(target_os = "android")]
static ANDROID_RPC_TX: Mutex<Option<tokio::sync::mpsc::UnboundedSender<String>>> = Mutex::new(None);
#[cfg(target_os = "android")]
static APP_HANDLE: Mutex<Option<tauri::AppHandle>> = Mutex::new(None);

// Called from MainActivity.onCreate (Kotlin) with the application context.
// Storing it lets Rust commands use the Android ContentResolver (e.g. for
// reading content:// attachments picked through the system file picker).
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_MainActivity_setApplicationContext(
    mut env: jni::JNIEnv,
    _class: jni::objects::JClass,
    context: jni::objects::JObject,
) {
    // The page runs in this process from now on: it starts IO itself (and
    // honours "sync only the active account"), so a core started headless
    // a moment later must not.
    ACTIVITY_LAUNCHED.store(true, std::sync::atomic::Ordering::SeqCst);
    store_app_context(&mut env, &context);
}

// MainActivity.onCreate was called in this process.
#[cfg(target_os = "android")]
static ACTIVITY_LAUNCHED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

// #178 phase 4: the DEK handed over by VeltaLock after a successful
// BiometricPrompt (raw x'<hex>' form). While the biometric app lock is
// on, init_android_core refuses to run without it — a headless cold
// start (push/job) has no user, so the core stays down (plan §2.4).
#[cfg(target_os = "android")]
static ANDROID_DEK_OVERRIDE: Mutex<Option<String>> = Mutex::new(None);

// VeltaApp.onCreate (Application): every process start, before any service,
// receiver or job runs, so the JNI helpers have a context and the classes.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_VeltaCore_setContext(
    mut env: jni::JNIEnv,
    _this: jni::objects::JObject,
    context: jni::objects::JObject,
) {
    store_app_context(&mut env, &context);
}

#[cfg(target_os = "android")]
fn store_app_context(env: &mut jni::JNIEnv, context: &jni::objects::JObject) {
    let vm = match env.get_java_vm() {
        Ok(vm) => vm,
        Err(e) => {
            log(&format!("setApplicationContext: get_java_vm failed: {e}"));
            return;
        }
    };
    let global = match env.new_global_ref(context) {
        Ok(g) => g,
        Err(e) => {
            log(&format!("setApplicationContext: new_global_ref failed: {e}"));
            return;
        }
    };
    *APP_JAVA_VM.lock().unwrap() = Some(vm);
    *APP_CONTEXT.lock().unwrap() = Some(global);
    // Global refs to the app's helper classes for later Rust commands
    // (network, media, notifications and other native helpers).
    let classes: [(&str, &Mutex<Option<jni::objects::GlobalRef>>); 13] = [
        ("InAppBrowser", &APP_INAPP_BROWSER_CLASS),
        ("Notifications", &APP_NOTIFICATIONS_CLASS),
        ("Battery", &APP_BATTERY_CLASS),
        ("NetInfo", &APP_NETINFO_CLASS),
        ("UpdateInstall", &APP_UPDATE_INSTALL_CLASS),
        ("Share", &APP_SHARE_CLASS),
        ("UnifiedPushBridge", &APP_UNIFIEDPUSH_CLASS),
        ("CallAudio", &APP_CALL_AUDIO_CLASS),
        ("CallPermissions", &APP_CALL_PERMISSIONS_CLASS),
        ("ScheduledAlarm", &APP_SCHEDULED_CLASS),
        ("CoreService", &APP_CORE_SERVICE_CLASS),
        ("VeltaKeystore", &APP_KEYSTORE_CLASS),
        ("VeltaLock", &APP_LOCK_CLASS),
    ];
    for (name, slot) in classes {
        match env.find_class(format!("org/velta/{name}")) {
            Ok(class) => match env.new_global_ref(&class) {
                Ok(g) => *slot.lock().unwrap() = Some(g),
                Err(e) => log(&format!("setApplicationContext: {name} global ref failed: {e}")),
            },
            Err(e) => log(&format!("setApplicationContext: {name} find_class failed: {e}")),
        }
    }
    log("application context stored for Rust commands");
}

// --- UnifiedPush JNI callbacks (called from UnifiedPushService.kt) ---

// onNewEndpoint: the serialized "webpush:<endpoint>|<pubkey>|<auth>" token.
// Applied to the accounts manager immediately when the core is ready — the
// core then registers it with the relay automatically (IMAP METADATA
// /private/devicetoken, core push.rs + imap.rs register_token) — otherwise
// parked in PENDING_PUSH_TOKEN and applied at the end of init_android_core.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_UnifiedPushService_pushEndpointReceived(
    mut env: jni::JNIEnv,
    _class: jni::objects::JClass,
    token: jni::objects::JString,
) {
    let Ok(jtoken) = env.get_string(&token) else { return };
    let token: String = jtoken.to_string_lossy().into_owned();
    PUSH_ENDPOINT_SET.store(true, std::sync::atomic::Ordering::SeqCst);
    // Log the scheme only — the endpoint URL is a capability URL.
    log(&format!(
        "push endpoint received ({})",
        token.split(':').next().unwrap_or("?")
    ));
    let accounts = ANDROID_ACCOUNTS.lock().unwrap().clone();
    match accounts {
        Some(accounts) => {
            if let Err(e) = accounts.blocking_read().set_push_device_token(&token) {
                log(&format!("push endpoint apply failed: {e}"));
            } else {
                log("push endpoint applied to the accounts manager");
                if let Some(app) = APP_HANDLE.lock().unwrap().clone() {
                    let _ = app.emit("velta-push", serde_json::json!({"stage": "endpoint"}));
                }
            }
        }
        None => {
            *PENDING_PUSH_TOKEN.lock().unwrap() = Some(token);
            log("push endpoint parked until the core is ready");
        }
    }
}

// Activity lifecycle. Home freezes the WebView without clearing
// document.hidden, so the poller must key off this flag too. Coming back
// interrupts a dead IDLE (opening the app is otherwise the only thing that
// unsticks a socket Android stopped delivering) and tells the page to
// refetch what the poller consumed.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_MainActivity_setActivityForeground(
    _env: jni::JNIEnv,
    _class: jni::objects::JClass,
    foreground: jni::sys::jboolean,
) {
    let foreground = foreground != 0;
    ACTIVITY_FOREGROUND.store(foreground, std::sync::atomic::Ordering::SeqCst);
    log(&format!("activity foreground: {foreground}"));
    if foreground {
        if let Some(app) = APP_HANDLE.lock().unwrap().clone() {
            let _ = app.emit("velta-foreground", ());
        }
        // Always interrupt on resume, even if a network callback just did.
        kick_maybe_network(true);
        tauri::async_runtime::spawn(proxy::log_resume_state());
    } else {
        kick_maybe_network(false);
    }
}

// Default-network changes from CoreService. A backgrounded IDLE socket can
// sit half-open until the activity returns; this is the reconnect.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_CoreService_networkAvailable(
    _env: jni::JNIEnv,
    _this: jni::objects::JClass,
    available: jni::sys::jboolean,
) {
    // Tell the page too: if its watcher paused core IO (stop_io), only a
    // start_io from there brings it back — maybe_network alone is a no-op.
    if let Some(app) = APP_HANDLE.lock().unwrap().clone() {
        let _ = app.emit("velta-network", available != 0);
    }
    // Lost: nothing to do. The core notices dead sockets itself and the
    // next onAvailable kicks it (there is no maybe_network_lost JSON-RPC
    // method; the old call always failed with "method not found").
    if available != 0 {
        kick_maybe_network(false);
    }
}

// onMessage: run one bounded background_fetch so the IMAP loop drains the
// relay; incoming messages surface through the background poller's parked
// get_next_event_batch and go out as notifications. No-op when the core is
// not initialized (cold process start — see AGENTS.md §9.4 for the ceiling).
// Shared with BackgroundFetchJob (the scheduled-fetch fallback, #52 L3):
// the job wakes the exact same path when no push distributor is installed
// or the process was frozen between pushes.
#[cfg(target_os = "android")]
fn push_wakeup_impl() {
    tauri::async_runtime::spawn(async move {
        let _ = background_fetch_once().await;
    });
}

/// Core-side bound of one background fetch (was 30 s).
#[cfg(target_os = "android")]
const BG_FETCH_TIMEOUT_SECS: f64 = 15.0;

/// One bounded background_fetch (BG_FETCH_TIMEOUT_SECS core-side). Returns when the core
/// reports the fetch finished (the JSON-RPC call resolves after
/// AccountsBackgroundFetchDone), or Err when it could not run.
#[cfg(target_os = "android")]
async fn background_fetch_once() -> Result<(), String> {
    // Drawer "Use background connection" OFF: the scheduled fetch and any
    // non-push wake are skipped entirely (push distributor wakes still
    // arrive but the gates below decide what they may post).
    if !notify_prefs_snapshot().use_bg_connection {
        println!("push wakeup: skipped (background connection off)");
        log("push wakeup: skipped (background connection off)");
        return Err("background connection off".into());
    }
    // Mirrored to logcat (println → RustStdoutStderr): a wake can happen
    // while the process is half-frozen by an OEM, where the buffered file
    // log may never flush — logcat is the reliable trace (#52).
    // Kotlin started the core (VeltaCore.ensureStarted) just before; on a
    // cold start it may still be initializing, so wait for it a while.
    // Foreground: the page runs IO itself and a fetch only adds an IO
    // restart (Velta core patch #12 after 10 s) that holds the scheduler
    // while tasks stuck on a dead proxy wind down. Never compete with the UI.
    if android_ui_visible() {
        log("push wakeup: skipped (app in foreground)");
        return Err("app in foreground".into());
    }
    if android_core().is_none() {
        println!("push wakeup: core not initialized");
        log("push wakeup: core not initialized");
        return Err("core not initialized".into());
    }
    println!("push wakeup: running background fetch");
    let Some((state, tx)) = android_core_tx(std::time::Duration::from_secs(20)).await else {
        println!("push wakeup: rpc channel not ready");
        log("push wakeup: rpc channel not ready");
        return Err("rpc channel not ready".into());
    };
    match bg_rpc(&tx, state, "background_fetch", serde_json::json!([BG_FETCH_TIMEOUT_SECS])).await {
        Ok(_) => {
            println!("push wakeup: background fetch done");
            log("push wakeup: background fetch done");
            Ok(())
        }
        Err(e) => {
            println!("push wakeup: {e}");
            log(&format!("push wakeup: {e}"));
            Err(e)
        }
    }
}

#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_UnifiedPushService_pushWakeup(
    _env: jni::JNIEnv,
    _class: jni::objects::JClass,
) {
    LAST_PUSH_SECS.store(unix_secs(), std::sync::atomic::Ordering::SeqCst);
    push_wakeup_impl();
}

// onUnregistered (distributor removed, user picked Off): the reconnect
// nudge is needed again.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_UnifiedPushService_pushUnregistered(
    _env: jni::JNIEnv,
    _class: jni::objects::JClass,
) {
    PUSH_ENDPOINT_SET.store(false, std::sync::atomic::Ordering::SeqCst);
    LAST_PUSH_SECS.store(0, std::sync::atomic::Ordering::SeqCst);
}

// Scheduled-fetch fallback (#52 L3): BackgroundFetchJob runs this on a
// worker thread so the core fetches even without a push distributor and
// after the OS froze the process (a job unfreezes it for its duration).
// Blocks until the fetch is done (or `max_secs`), then gives the event
// poller a moment to post the notifications for what it fetched. true =
// the fetch completed.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_BackgroundFetchJob_fetchBlocking(
    _env: jni::JNIEnv,
    _this: jni::objects::JObject,
    max_secs: jni::sys::jint,
) -> jni::sys::jboolean {
    let max = std::time::Duration::from_secs(max_secs.max(1) as u64);
    let done = tauri::async_runtime::block_on(async move {
        match tokio::time::timeout(max, background_fetch_once()).await {
            Ok(Ok(())) => {
                tokio::time::sleep(std::time::Duration::from_millis(1500)).await;
                true
            }
            _ => false,
        }
    });
    done as jni::sys::jboolean
}

// onStopJob: the system took the slot back early — interrupt the fetch so
// the core does not keep working in a process about to be frozen.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_BackgroundFetchJob_stopFetch(
    _env: jni::JNIEnv,
    _this: jni::objects::JObject,
) {
    let accounts = ANDROID_ACCOUNTS.lock().unwrap().clone();
    if let Some(accounts) = accounts {
        tauri::async_runtime::spawn(async move {
            accounts.read().await.stop_background_fetch();
            log("scheduled fetch: stopped early by the system");
        });
    }
}

// Desktop has no ContentResolver; the command exists on every platform so the
// frontend can always call it -- on desktop it just reports unsupported.
#[cfg(not(target_os = "android"))]
#[tauri::command]
async fn resolve_content_uri(_app: tauri::AppHandle, _uri: String, _filename: String) -> Result<String, String> {
    Err("picking attachments is only supported on mobile".into())
}

// Desktop keeps its system-browser convention for message links; the in-app
// Custom Tab is an Android behavior.
#[cfg(not(target_os = "android"))]
#[tauri::command]
fn open_in_app_browser(_url: String) -> Result<(), String> {
    Err("in-app browser is only supported on Android".into())
}

/// Android: launch the URL in a Chrome Custom Tab (native, Telegram-style)
/// via InAppBrowser.kt. Uses the application context handed over from
/// MainActivity.onCreate. InAppBrowser.open falls back to a plain ACTION_VIEW
/// launch when no Custom Tabs provider resolves the session intent.
#[cfg(target_os = "android")]
#[tauri::command]
fn open_in_app_browser(url: String) -> Result<(), String> {
    with_android_class(&APP_INAPP_BROWSER_CLASS, "InAppBrowser", |env, context, class_ref| {
        let url_j = env.new_string(url).map_err(|e| e.to_string())?;
        let opened = env
            .call_static_method(
                class_ref,
                "open",
                "(Landroid/content/Context;Ljava/lang/String;)Z",
                &[(&context).into(), (&url_j).into()],
            )
            .map_err(|e| e.to_string())?
            .z()
            .map_err(|e| e.to_string())?;
        if !opened {
            // No Custom Tabs provider on the device: the frontend opens the
            // native WebView overlay next (better than a full browser switch).
            return Err("no custom tabs provider".into());
        }
        Ok(())
    })
}

/// Android: second-WebView browser overlay (the no-Custom-Tabs-provider
/// fallback; a top-level browsing context, so X-Frame-Options cannot block
/// it). Desktop keeps its system-browser convention.
#[cfg(not(target_os = "android"))]
#[tauri::command]
fn open_webview_browser(_url: String) -> Result<(), String> {
    Err("webview browser is only supported on Android".into())
}

#[cfg(target_os = "android")]
#[tauri::command]
fn open_webview_browser(url: String) -> Result<(), String> {
    with_android_class(&APP_INAPP_BROWSER_CLASS, "InAppBrowser", |env, context, class_ref| {
        let url_j = env.new_string(url).map_err(|e| e.to_string())?;
        // openWebView posts to the main looper itself; it returns void and never
        // fails visibly (a missing activity attachment is logged in Kotlin).
        env.call_static_method(
            class_ref,
            "openWebView",
            "(Landroid/content/Context;Ljava/lang/String;)V",
            &[(&context).into(), (&url_j).into()],
        )
        .map_err(|e| e.to_string())?;
        Ok(())
    })
}

#[cfg(target_os = "android")]
#[tauri::command]
async fn resolve_content_uri(app: tauri::AppHandle, uri: String, filename: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || resolve_content_uri_blocking(app, uri, filename))
        .await
        .map_err(|e| e.to_string())?
}

/// Cache directory the core can write a backup tar into. Android then copies
/// that tar onto the content URI from the system save dialog.
#[tauri::command]
fn backup_scratch_dir(app: tauri::AppHandle) -> Result<String, String> {
    let dir = app
        .path()
        .app_cache_dir()
        .map_err(|e| e.to_string())?
        .join("backup-export");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    Ok(dir.to_string_lossy().into_owned())
}

#[cfg(target_os = "android")]
fn newest_backup_tar(dir: &std::path::Path) -> Result<std::path::PathBuf, String> {
    let mut best: Option<(std::time::SystemTime, std::path::PathBuf)> = None;
    for entry in std::fs::read_dir(dir).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("tar") {
            continue;
        }
        let modified = entry
            .metadata()
            .and_then(|m| m.modified())
            .unwrap_or(std::time::SystemTime::UNIX_EPOCH);
        if best.as_ref().map(|(t, _)| modified >= *t).unwrap_or(true) {
            best = Some((modified, path));
        }
    }
    best.map(|(_, path)| path).ok_or_else(|| "the core produced no backup file".into())
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
async fn publish_backup(_dir: String, _uri: String) -> Result<(), String> {
    Err("saving a backup to a chosen location is only supported on Android".into())
}

#[cfg(target_os = "android")]
#[tauri::command]
async fn publish_backup(dir: String, uri: String) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || publish_backup_blocking(dir, uri))
        .await
        .map_err(|e| e.to_string())?
}

#[cfg(target_os = "android")]
fn publish_backup_blocking(dir: String, uri: String) -> Result<(), String> {
    let src = newest_backup_tar(std::path::Path::new(&dir))?;
    let copied = copy_path_to_content_uri(&src, &uri);
    if let Ok(entries) = std::fs::read_dir(&dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) == Some("tar") {
                let _ = std::fs::remove_file(path);
            }
        }
    }
    copied
}

// Java stream copy through one reusable byte[] buffer; `*_label` name the
// streams in error messages. The caller closes both streams.
#[cfg(target_os = "android")]
fn jni_copy_stream(
    env: &mut jni::JNIEnv<'_>,
    input: &jni::objects::JObject<'_>,
    output: &jni::objects::JObject<'_>,
    buf: &jni::objects::JObject<'_>,
    read_label: &str,
    write_label: &str,
) -> Result<(), String> {
    loop {
        let n = env
            .call_method(input, "read", "([B)I", &[buf.into()])
            .and_then(|v| v.i())
            .map_err(|e| format!("{read_label}.read: {e}"))?;
        if n < 0 {
            return Ok(());
        }
        env.call_method(
            output,
            "write",
            "([BII)V",
            &[buf.into(), jni::objects::JValue::Int(0), jni::objects::JValue::Int(n)],
        )
        .map_err(|e| format!("{write_label}.write: {e}"))?;
    }
}

#[cfg(target_os = "android")]
pub(crate) fn copy_path_to_content_uri(src: &std::path::Path, uri: &str) -> Result<(), String> {
    with_android_env(|env, context| {
        let uri_j = env.new_string(uri).map_err(|e| e.to_string())?;
        let uri_class = env.find_class("android/net/Uri").map_err(|e| e.to_string())?;
        let uri_obj = env
            .call_static_method(&uri_class, "parse", "(Ljava/lang/String;)Landroid/net/Uri;", &[(&uri_j).into()])
            .map_err(|e| e.to_string())?
            .l()
            .map_err(|e| e.to_string())?;
        let cr = env
            .call_method(context, "getContentResolver", "()Landroid/content/ContentResolver;", &[])
            .map_err(|e| e.to_string())?
            .l()
            .map_err(|e| e.to_string())?;
        let os = env
            .call_method(&cr, "openOutputStream", "(Landroid/net/Uri;)Ljava/io/OutputStream;", &[(&uri_obj).into()])
            .map_err(|e| e.to_string())?
            .l()
            .map_err(|e| e.to_string())?;
        if env.exception_check().map_err(|e| e.to_string())? || os.is_null() {
            let _ = env.exception_clear();
            return Err("openOutputStream failed for this save location".into());
        }

        let src_str = src.to_string_lossy().into_owned();
        let src_j = env.new_string(&src_str).map_err(|e| e.to_string())?;
        let is = env
            .new_object("java/io/FileInputStream", "(Ljava/lang/String;)V", &[(&src_j).into()])
            .map_err(|e| e.to_string())?;
        let buf = env.new_byte_array(64 * 1024).map_err(|e| e.to_string())?;
        let buf_obj: jni::objects::JObject = buf.into();
        let copy_result = jni_copy_stream(env, &is, &os, &buf_obj, "FileInputStream", "OutputStream");
        if let Err(e) = env.call_method(&os, "flush", "()V", &[]) {
            log(&format!("output stream flush: {e}"));
        }
        if let Err(e) = env.call_method(&os, "close", "()V", &[]) {
            log(&format!("output stream close: {e}"));
        }
        if let Err(e) = env.call_method(&is, "close", "()V", &[]) {
            log(&format!("input stream close: {e}"));
        }
        let _ = env.exception_clear();
        copy_result
    })
}

// Android save dialog returns a content URI. Copy the account-scoped file there.
#[cfg(target_os = "android")]
#[tauri::command]
async fn save_attachment(app: tauri::AppHandle, src: String, uri: String) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || {
        let canon = scoped_accounts_path(&app, &src)?;
        copy_path_to_content_uri(&canon, &uri)
    })
    .await
    .map_err(|e| e.to_string())?
}

#[cfg(not(target_os = "android"))]
#[tauri::command]
async fn save_attachment(src: String, uri: String) -> Result<(), String> {
    let _ = (src, uri);
    Err("saving to a chosen location is only supported on Android".into())
}

/// PWA backup downloads arrive gzip-compressed (CompressionStream export);
/// the core's imex only reads plain tars. Sniff the gzip magic and
/// decompress to a temp file when needed; anything else passes through.
fn prep_backup_blocking(path: String) -> Result<String, String> {
    use std::io::Read;
    let gz = std::fs::File::open(&path)
        .and_then(|mut f| {
            let mut magic = [0u8; 2];
            f.read_exact(&mut magic)?;
            Ok(magic == [0x1f, 0x8b])
        })
        .unwrap_or(false);
    if !gz {
        return Ok(path);
    }
    let dir = std::env::temp_dir().join("velta-backup");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let stem = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let dest = dir.join(format!("backup-{stem}.tar"));
    let mut decoder = flate2::read::GzDecoder::new(std::fs::File::open(&path).map_err(|e| e.to_string())?);
    let mut out = std::fs::File::create(&dest).map_err(|e| e.to_string())?;
    std::io::copy(&mut decoder, &mut out).map_err(|e| e.to_string())?;
    Ok(dest.to_string_lossy().into_owned())
}

#[tauri::command]
async fn prep_backup(app: tauri::AppHandle, path: String) -> Result<String, String> {
    picked::check(&app, std::path::Path::new(&path))?;
    tauri::async_runtime::spawn_blocking(move || prep_backup_blocking(path))
        .await
        .map_err(|e| e.to_string())?
}

#[cfg(target_os = "android")]
fn resolve_content_uri_blocking(app: tauri::AppHandle, uri: String, filename: String) -> Result<String, String> {
    use tauri::path::BaseDirectory;

    // The application context was handed over from MainActivity.onCreate
    // (see setApplicationContext below) and is stored as a global ref.
    with_android_env(|env, context| {
        let uri_j = env.new_string(&uri).map_err(|e| e.to_string())?;
        let uri_class = env.find_class("android/net/Uri").map_err(|e| e.to_string())?;
        let uri_obj = env
            .call_static_method(&uri_class, "parse", "(Ljava/lang/String;)Landroid/net/Uri;", &[(&uri_j).into()])
            .map_err(|e| e.to_string())?
            .l()
            .map_err(|e| e.to_string())?;

        let cr = env
            .call_method(context, "getContentResolver", "()Landroid/content/ContentResolver;", &[])
            .map_err(|e| e.to_string())?
            .l()
            .map_err(|e| e.to_string())?;

        // Query the display name (keeps the real filename + extension, so the
        // attachment is sent as image/video instead of a generic file).
        let mut display_name = String::new();
        let proj_str = env.new_string("_display_name").map_err(|e| e.to_string())?;
        let proj = env
            .new_object_array(1, "java/lang/String", &proj_str)
            .map_err(|e| e.to_string())?;
        let null_obj = jni::objects::JObject::null();
        let cursor = env
            .call_method(
                &cr,
                "query",
                "(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;",
                &[
                    (&uri_obj).into(),
                    (&proj).into(),
                    (&null_obj).into(),
                    (&null_obj).into(),
                    (&null_obj).into(),
                ],
            )
            .map_err(|e| e.to_string())?
            .l()
            .map_err(|e| e.to_string())?;
        let _ = env.exception_clear();
        if !cursor.is_null() {
            if let Err(e) = env.call_method(&cursor, "moveToFirst", "()Z", &[]) {
                log(&format!("cursor moveToFirst: {e}"));
            }
            let _ = env.exception_clear();
            let name_obj = env
                .call_method(&cursor, "getString", "(I)Ljava/lang/String;", &[jni::objects::JValue::Int(0)])
                .map_err(|e| e.to_string())?
                .l()
                .map_err(|e| e.to_string())?;
            if !name_obj.is_null() {
                let name_jstr = jni::objects::JString::from(name_obj);
                display_name = env.get_string(&name_jstr).map_err(|e| e.to_string())?.to_string_lossy().into_owned();
            }
            if let Err(e) = env.call_method(&cursor, "close", "()V", &[]) {
                log(&format!("cursor close: {e}"));
            }
            let _ = env.exception_clear();
        }

        // Keep the real filename (with extension) so the attachment is typed as
        // image/video rather than a generic file.
        let base_name = if display_name.is_empty() {
            if filename.is_empty() { "attachment.bin".to_string() } else { filename.clone() }
        } else {
            display_name.replace(['/', '\\'], "_")
        };
        let dest = app
            .path()
            .resolve(format!("uploads/{}", base_name), BaseDirectory::AppLocalData)
            .map_err(|e| e.to_string())?;
        if let Some(parent) = dest.parent() {
            std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        let is = env
            .call_method(&cr, "openInputStream", "(Landroid/net/Uri;)Ljava/io/InputStream;", &[(&uri_obj).into()])
            .map_err(|e| e.to_string())?
            .l()
            .map_err(|e| e.to_string())?;
        if env.exception_check().map_err(|e| e.to_string())? {
            let _ = env.exception_clear();
            return Err("openInputStream failed for this content uri".into());
        }

        let dest_str = dest.to_string_lossy().to_string();
        let _ = &display_name;
        let dest_j = env.new_string(&dest_str).map_err(|e| e.to_string())?;
        let file_obj = env
            .new_object("java/io/File", "(Ljava/lang/String;)V", &[(&dest_j).into()])
            .map_err(|e| e.to_string())?;
        let parent = env
            .call_method(&file_obj, "getParentFile", "()Ljava/io/File;", &[])
            .map_err(|e| e.to_string())?
            .l()
            .map_err(|e| e.to_string())?;
        if !parent.is_null() {
            if let Err(e) = env.call_method(&parent, "mkdirs", "()Z", &[]) {
                log(&format!("mkdirs error: {e}"));
            }
            let _ = env.exception_clear();
        }

        let fos = env
            .new_object("java/io/FileOutputStream", "(Ljava/io/File;)V", &[(&file_obj).into()])
            .map_err(|e| e.to_string())?;

        let buf = env.new_byte_array(64 * 1024).map_err(|e| e.to_string())?;
        let buf_obj: jni::objects::JObject = buf.into();
        let copy_result = jni_copy_stream(env, &is, &fos, &buf_obj, "InputStream", "FileOutputStream");

        if let Err(e) = env.call_method(&fos, "close", "()V", &[]) {
            log(&format!("fos close error: {e}"));
        }
        if let Err(e) = env.call_method(&is, "close", "()V", &[]) {
            log(&format!("is close error: {e}"));
        }
        let _ = env.exception_clear();

        copy_result?;
        log(&format!("resolve_content_uri copied {} -> {}", uri, dest_str));
        // PWA backup exports are gzipped — route through the same sniff the
        // desktop pick path uses so the core always sees a plain tar.
        prep_backup_blocking(dest_str)
    })
}

fn queue_opened(url: String) {
    if url.is_empty() {
        return;
    }
    // V-07/#65: a file the OS opened Velta with counts as a user pick.
    if let Some(p) = picked::opened_file_path(&url) {
        picked::record(&p);
    }
    let mut q = OPENED_URLS.lock().unwrap();
    // argv and RunEvent::Opened can both report the same link.
    if !q.iter().any(|u| u == &url) {
        q.push(url);
    }
}

#[cfg(any(target_os = "macos", target_os = "ios", target_os = "android"))]
fn log_opened(url: &str) {
    if url.starts_with("data:") || url.starts_with("content:") || url.starts_with("file:") || Path::new(url).is_file() {
        log("opened share payload");
    } else {
        // A proxy link can contain credentials: never write it to the log.
        if url.to_ascii_lowercase().starts_with("velta://proxy") {
            log("deeplink opened: velta://proxy?…");
        } else if url.to_ascii_lowercase().starts_with("velta://ws") {
            log("deeplink opened: velta://ws?…");
        } else {
            log(&format!("deeplink opened: {}", redact_chat_link(url)));
        }
    }
}

// Deeplink-shaped args, plus paths of files that exist (Windows Send to,
// "Open with"). Flags are not files.
pub fn collect_startup_args(args: impl IntoIterator<Item = impl AsRef<str>>, is_file: impl Fn(&str) -> bool) -> Vec<String> {
    args.into_iter()
        .filter_map(|a| {
            let a = a.as_ref();
            if maybe_extract_deeplink(a).is_some() || (!a.starts_with('-') && is_file(a)) {
                Some(a.to_string())
            } else {
                None
            }
        })
        .collect()
}

pub fn set_initial_deeplink_from_env() {
    for url in collect_startup_args(std::env::args().skip(1), |a| Path::new(a).is_file()) {
        queue_opened(url);
    }
}

#[tauri::command]
fn js_log(msg: String) {
    log(&msg);
}

// Diagnostics chat "Logging" switch: gate the shell log writer at runtime.
#[tauri::command]
fn set_logging_enabled(enabled: bool) {
    LOG_ENABLED.store(enabled, std::sync::atomic::Ordering::Relaxed);
}

// Diagnostics chat "DevTools" switch.
// Desktop: opens/closes the WebView inspector (the `devtools` cargo feature
// is enabled in all builds). Android: flips WebView remote debugging —
// chrome://inspect over USB. The static setWebContentsDebuggingEnabled call
// MUST run on the Android UI thread (off-thread it throws the Java exception
// from issue #12), so Rust posts the flag through org/velta/DevTools.kt,
// which hops to the main looper.
#[tauri::command]
fn set_devtools(_app: tauri::AppHandle, enabled: bool) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let vm_guard = APP_JAVA_VM.lock().unwrap();
        let vm = vm_guard.as_ref().ok_or("jvm was not handed over yet")?;
        let mut env = vm
            .attach_current_thread()
            .map_err(|e| format!("jvm attach: {e}"))?;
        let class = env
            .find_class("org/velta/DevTools")
            .map_err(|e| format!("DevTools class: {e}"))?;
        env.call_static_method(
            &class,
            "set",
            "(Z)V",
            &[jni::objects::JValue::Bool(enabled as u8)],
        )
        .map_err(|e| format!("DevTools.set: {e}"))?;
        Ok(())
    }
    #[cfg(not(target_os = "android"))]
    {
        let Some(win) = _app.get_webview_window("main") else {
            return Err("main window not found".into());
        };
        if enabled {
            win.open_devtools();
        } else {
            win.close_devtools();
        }
        Ok(())
    }
}

#[tauri::command]
fn take_opened_urls() -> Vec<String> {
    std::mem::take(&mut *OPENED_URLS.lock().unwrap())
}

#[derive(Clone)]
struct RpcState {
    // webxdc asset serving does request/response round-trips from Rust-side
    // protocol handlers (the WebView cannot relay its own asset fetches).
    // Those requests use string ids prefixed "wxdc-" so the response
    // forwarders hand them back here instead of emitting to the WebView.
    wxdc_pending: std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, tokio::sync::oneshot::Sender<String>>>>,
    // Background event poller (Android): get_next_event_batch round-trips
    // use ids prefixed "bg-", routed back here by the response forwarder.
    #[cfg_attr(not(target_os = "android"), allow(dead_code))]
    bg_pending: std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, tokio::sync::oneshot::Sender<String>>>>,
    // WebView command round-trips (#49): the rpc command parks the request's
    // JSON-RPC id here and RETURNS the response line instead of relying on
    // the velta-rpc broadcast, which re-encoded every answer and woke every
    // listener. Keyed by the id as a string (number ids via Value::to_string).
    #[cfg_attr(target_os = "android", allow(dead_code))]
    web_pending: std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, tokio::sync::oneshot::Sender<String>>>>,
    // Shared with the background init task: setup() stores None immediately
    // and the async core-init task fills it in once the RPC session is ready.
    #[cfg(target_os = "android")]
    tx: std::sync::Arc<std::sync::Mutex<Option<tokio::sync::mpsc::UnboundedSender<String>>>>,

    #[cfg(not(target_os = "android"))]
    stdin: Arc<Mutex<Option<ChildStdin>>>,
}

impl RpcState {
    fn send_rpc(&self, request: &str) -> Result<(), String> {
        #[cfg(target_os = "android")]
        {
            write_rpc_tx(&self.tx, request)
        }
        #[cfg(not(target_os = "android"))]
        {
            write_rpc_stdin(&self.stdin, request)
        }
    }
}

#[cfg(target_os = "android")]
fn write_rpc_tx(
    tx: &std::sync::Arc<std::sync::Mutex<Option<tokio::sync::mpsc::UnboundedSender<String>>>>,
    request: &str,
) -> Result<(), String> {
    let guard = tx.lock().map_err(|e| e.to_string())?;
    if let Some(tx) = guard.as_ref() {
        tx.send(request.to_string()).map_err(|e| e.to_string())
    } else {
        Err("Delta Chat core is not running".to_string())
    }
}

#[cfg(not(target_os = "android"))]
fn write_rpc_stdin(stdin: &Arc<Mutex<Option<ChildStdin>>>, request: &str) -> Result<(), String> {
    use std::io::Write;
    let mut guard = stdin.lock().map_err(|e| e.to_string())?;
    if let Some(stdin) = guard.as_mut() {
        stdin.write_all(request.as_bytes()).map_err(|e| e.to_string())?;
        stdin.write_all(b"\n").map_err(|e| e.to_string())?;
        stdin.flush().map_err(|e| e.to_string())
    } else {
        Err("Delta Chat core sidecar is not running".to_string())
    }
}

#[tauri::command]
async fn rpc(request: String, state: State<'_, RpcState>) -> Result<String, String> {
    // NOTE: do not log every request here. This command is on the JSON-RPC
    // hot path -- even with the non-blocking logger, formatting a string per
    // RPC adds alloc pressure and grows velta.log unbounded. Use js_log from
    // the frontend for targeted diagnostics.
    //
    // Desktop (#49): the command's return value is the response path. The
    // request's JSON-RPC id is parked in web_pending and the sidecar's
    // response line for it is returned here; the velta-rpc broadcast then
    // carries only what the core PUSHES (event notifications). Android keeps
    // the write-only arm — its WebView speaks through the VeltaBridge and
    // its response forwarder still emits every line.
    #[cfg(target_os = "android")]
    {
        let tx = state.tx.clone();
        tauri::async_runtime::spawn_blocking(move || write_rpc_tx(&tx, &request))
            .await
            .map_err(|e| e.to_string())??;
        Ok(String::new())
    }
    #[cfg(not(target_os = "android"))]
    {
        let id_key = serde_json::from_str::<serde_json::Value>(&request)
            .ok()
            .and_then(|v| v.get("id").cloned())
            .and_then(|id| match id {
                serde_json::Value::String(s) => Some(s),
                n if n.is_number() => Some(n.to_string()),
                _ => None,
            });
        let Some(id_key) = id_key else {
            // No usable id (never the case for rpc-core traffic): plain write.
            let stdin = state.stdin.clone();
            tauri::async_runtime::spawn_blocking(move || write_rpc_stdin(&stdin, &request))
                .await
                .map_err(|e| e.to_string())??;
            return Ok(String::new());
        };
        let (tx, rx) = tokio::sync::oneshot::channel::<String>();
        {
            // Register the waiter BEFORE writing — a fast response must not
            // arrive while no one is registered (same rule as wxdc_rpc).
            state
                .web_pending
                .lock()
                .unwrap()
                .insert(id_key.clone(), tx);
        }
        let stdin = state.stdin.clone();
        let write = tauri::async_runtime::spawn_blocking(move || write_rpc_stdin(&stdin, &request))
            .await
            .map_err(|e| e.to_string());
        if let Err(e) = write {
            state.web_pending.lock().unwrap().remove(&id_key);
            return Err(e);
        }
        // Generous ceiling: rpc-core has its own per-call timeouts; this only
        // stops a dead sidecar from leaking the parked entry forever.
        match tokio::time::timeout(std::time::Duration::from_secs(180), rx).await {
            Ok(Ok(line)) => Ok(line),
            Ok(Err(_)) => Err("rpc response channel dropped (sidecar restart?)".to_string()),
            Err(_) => {
                state.web_pending.lock().unwrap().remove(&id_key);
                Err("rpc response timed out (180s)".to_string())
            }
        }
    }
}

/// One JSON-RPC call to the sidecar from the shell itself (the proxy keeper
/// keeps the accounts' proxy settings in line, proxy.rs). Rides the same
/// web_pending round-trip as the rpc command, with "velta-shell-" string ids
/// that never collide with the page's numeric ones. Returns `result`.
#[cfg(not(target_os = "android"))]
#[cfg_attr(not(windows), allow(dead_code))]
pub(crate) async fn sidecar_call(app: &tauri::AppHandle, method: &str, params: serde_json::Value) -> Result<serde_json::Value, String> {
    use std::sync::atomic::{AtomicU64, Ordering};
    static NEXT: AtomicU64 = AtomicU64::new(1);
    let state = app.try_state::<RpcState>().ok_or("Delta Chat core sidecar is not running")?;
    let id = format!("velta-shell-{}", NEXT.fetch_add(1, Ordering::Relaxed));
    let request = serde_json::json!({"jsonrpc": "2.0", "id": id, "method": method, "params": params}).to_string();
    let (tx, rx) = tokio::sync::oneshot::channel::<String>();
    state.web_pending.lock().unwrap().insert(id.clone(), tx);
    let stdin = state.stdin.clone();
    let write = tauri::async_runtime::spawn_blocking(move || write_rpc_stdin(&stdin, &request))
        .await
        .map_err(|e| e.to_string())
        .and_then(|r| r);
    if let Err(e) = write {
        state.web_pending.lock().unwrap().remove(&id);
        return Err(e);
    }
    let line = match tokio::time::timeout(std::time::Duration::from_secs(30), rx).await {
        Ok(Ok(line)) => line,
        Ok(Err(_)) => return Err("rpc response channel dropped (sidecar restart?)".to_string()),
        Err(_) => {
            state.web_pending.lock().unwrap().remove(&id);
            return Err(format!("{method}: no answer from the core (30s)"));
        }
    };
    let mut v: serde_json::Value = serde_json::from_str(&line).map_err(|e| e.to_string())?;
    if let Some(err) = v.get("error") {
        return Err(err.get("message").and_then(|m| m.as_str()).map_or_else(|| err.to_string(), str::to_string));
    }
    Ok(v.get_mut("result").map(serde_json::Value::take).unwrap_or(serde_json::Value::Null))
}

// Resolve a parked WebView rpc response from a forwarder line (#49). Returns
// true when the line completed a web_pending round-trip — the caller must
// NOT emit it to the WebView in that case. Desktop only: the Android WebView
// speaks through the VeltaBridge, not this command.
#[cfg(not(target_os = "android"))]
fn resolve_web_line(app: &tauri::AppHandle, line: &str) -> bool {
    let Ok(value) = serde_json::from_str::<serde_json::Value>(line) else { return false; };
    let id = match value.get("id") {
        Some(serde_json::Value::String(s)) => s.clone(),
        Some(n) if n.is_number() => n.to_string(),
        _ => return false,
    };
    let state = app.state::<RpcState>();
    let sender = state.web_pending.lock().unwrap().remove(&id);
    match sender {
        Some(tx) => {
            let _ = tx.send(line.to_string());
            true
        }
        None => false,
    }
}

// Windows ships the sidecar as a bundle resource; macOS as a Tauri
// externalBin, which lands next to the main executable (Contents/MacOS)
// with the target-triple suffix stripped.
#[cfg(windows)]
const SIDECAR_NAME: &str = "deltachat-rpc-server.exe";
#[cfg(not(any(windows, target_os = "android")))]
const SIDECAR_NAME: &str = "deltachat-rpc-server";

#[cfg(not(target_os = "android"))]
fn find_sidecar(app: &tauri::AppHandle) -> Option<PathBuf> {
    use tauri::path::BaseDirectory;

    let candidates = [
        app.path().resolve(SIDECAR_NAME, BaseDirectory::Resource).ok(),
        std::env::current_exe().ok().and_then(|p| p.parent().map(|p| p.join(SIDECAR_NAME))),
        std::env::current_exe().ok().and_then(|p| p.parent().map(|p| p.join("resources").join(SIDECAR_NAME))),
        std::env::current_exe().ok().and_then(|p| p.parent().map(|p| p.join("..").join("resources").join(SIDECAR_NAME))).map(|p| p.canonicalize().unwrap_or(p)),
    ];

    candidates.into_iter().flatten().find(|c| c.is_file())
}

fn accounts_dir(app: &tauri::AppHandle) -> PathBuf {
    use tauri::path::BaseDirectory;
    app.path()
        .resolve("accounts", BaseDirectory::AppLocalData)
        .unwrap_or_else(|_| log_dir().join("..").join("accounts"))
}

#[cfg(target_os = "android")]
fn android_core_status(status: serde_json::Value) {
    *SIDECAR_STATUS.lock().unwrap() = Some(status.clone());
    Host::current().emit("velta-sidecar-status", status);
}

#[cfg(target_os = "android")]
fn ui_emit_rpc(line: &str) {
    if let Some(app) = ui_app() {
        if let Err(e) = app.emit("velta-rpc", line) {
            log(&format!("android emit error: {e}"));
        }
    }
}

// The one in-process core (Android). Created by whichever comes first: the
// Tauri setup (activity) or a headless start (CoreService restart, push,
// periodic job, scheduled-send alarm, boot). The other one reuses it, so
// there is never a second Accounts on the same directory.
#[cfg(target_os = "android")]
static ANDROID_CORE: std::sync::OnceLock<RpcState> = std::sync::OnceLock::new();
#[cfg(target_os = "android")]
static ANDROID_RT: std::sync::OnceLock<tokio::runtime::Runtime> = std::sync::OnceLock::new();

#[cfg(target_os = "android")]
fn android_core() -> Option<&'static RpcState> {
    ANDROID_CORE.get()
}

/// Starts the core once (non-blocking: init continues on its runtime).
#[cfg(target_os = "android")]
fn ensure_android_core(accounts_dir: PathBuf) -> &'static RpcState {
    ANDROID_CORE.get_or_init(|| {
        let rt = ANDROID_RT.get_or_init(|| tokio::runtime::Runtime::new().expect("tokio runtime"));
        log("initializing embedded Android core (non-blocking)");
        let _ = std::fs::create_dir_all(&accounts_dir);
        let state = RpcState {
            wxdc_pending: std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            bg_pending: std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            web_pending: std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new())),
            tx: std::sync::Arc::new(std::sync::Mutex::new(None)),
        };
        let tx_holder = state.tx.clone();
        let bg_pending = state.bg_pending.clone();
        rt.spawn(async move {
            // #178 phase 4: an app-locked start is retried once the activity
            // unlocks (VeltaCore.startWithDek) — nothing was opened, so
            // Accounts::new simply runs again with the provided DEK.
            loop {
            match init_android_core(accounts_dir.clone(), bg_pending.clone()).await {
                Ok(tx) => {
                    log("android core RPC session ready");
                    // Proxies first (audit item 5): every profile points at
                    // the selected SOCKS5 / WS proxy BEFORE anything can start
                    // IO — the page cannot call start_io until tx is published
                    // below, and the headless start_io comes last.
                    proxy::boot(&Host::current());
                    ws_transport::boot_now(&Host::current()).await;
                    proxy::reapply_proxy().await;
                    start_bg_event_poller(tx.clone());
                    start_bg_fetch_kicker(tx.clone());
                    *tx_holder.lock().unwrap() = Some(tx);
                    android_core_status(serde_json::json!({"running": true, "stage": "ready"}));
                    // Headless (no activity in this process): nobody else
                    // starts IO. With the page up, rpc-core starts it.
                    if !ACTIVITY_LAUNCHED.load(std::sync::atomic::Ordering::SeqCst) {
                        let accounts = ANDROID_ACCOUNTS.lock().unwrap().clone();
                        if let Some(accounts) = accounts {
                            accounts.write().await.start_io().await;
                            log("headless core: IO started for all accounts");
                        }
                    }
                    break;
                }
                Err(e) if e.to_string().contains("app-locked") => {
                    android_core_status(serde_json::json!({"running": false, "stage": "app-locked"}));
                    while ANDROID_DEK_OVERRIDE.lock().unwrap().is_none() {
                        tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                    }
                    log("db-key: DEK provided; retrying the core init");
                }
                Err(e) => {
                    log(&format!("embedded Android core initialization failed: {e}"));
                    android_core_status(serde_json::json!({"running": false, "stage": "error", "message": e.to_string()}));
                    break;
                }
            }
            }
        });
        state
    })
}

/// The core's request channel, waiting up to `max` for a core that is still
/// initializing (a cold start by a push or job races Accounts::new).
#[cfg(target_os = "android")]
async fn android_core_tx(max: std::time::Duration) -> Option<(&'static RpcState, tokio::sync::mpsc::UnboundedSender<String>)> {
    let start = std::time::Instant::now();
    loop {
        if let Some(state) = android_core() {
            if let Some(tx) = state.tx.lock().unwrap().clone() {
                return Some((state, tx));
            }
        }
        if start.elapsed() >= max {
            return None;
        }
        tokio::time::sleep(std::time::Duration::from_millis(200)).await;
    }
}

// Kotlin VeltaCore.ensureStarted (CoreService, UnifiedPushService,
// BackgroundFetchJob, ScheduledAlarmReceiver): start the core without the
// activity. dataDir = Context.getDataDir() (Tauri's app_local_data_dir),
// extDir = getExternalFilesDir(null) for the adb-readable log mirror (may be
// empty). Returns false when "Use background connection" is off and the
// core is not already running; true when it runs or is starting.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_VeltaCore_startHeadless(
    mut env: jni::JNIEnv,
    _this: jni::objects::JObject,
    data_dir: jni::objects::JString,
    ext_dir: jni::objects::JString,
) -> jni::sys::jboolean {
    if android_core().is_some() {
        return 1;
    }
    let Ok(data) = env.get_string(&data_dir).map(|s| PathBuf::from(s.to_string_lossy().into_owned())) else { return 0 };
    let ext = env.get_string(&ext_dir).map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
    {
        let mut dir = ANDROID_DATA_DIR.lock().unwrap();
        if dir.is_none() {
            *dir = Some(data.clone());
        }
    }
    if LOG_DIR.lock().unwrap().is_none() {
        set_log_dir(data.join("logs"));
        if !ext.is_empty() {
            set_mirror_log_dir(PathBuf::from(ext).join("logs"));
        }
    }
    if NOTIFY_PREFS.lock().unwrap().is_none() {
        notify_prefs_load_path(&data.join("notify-prefs.json"));
    }
    if !notify_prefs_snapshot().use_bg_connection {
        log("headless start: skipped (background connection off)");
        return 0;
    }
    if !ACTIVITY_LAUNCHED.load(std::sync::atomic::Ordering::SeqCst) {
        // No activity in this process: the app is not in the foreground.
        ACTIVITY_FOREGROUND.store(false, std::sync::atomic::Ordering::SeqCst);
    }
    log("headless start: no activity, starting the core from a background entry point");
    ensure_android_core(data.join("accounts"));
    1
}

// Kotlin VeltaCore.isRunning: the core finished initializing.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_VeltaCore_isRunning(
    _env: jni::JNIEnv,
    _this: jni::objects::JObject,
) -> jni::sys::jboolean {
    android_core().is_some_and(|s| s.tx.lock().unwrap().is_some()) as jni::sys::jboolean
}

// #178 phase 4: VeltaCore.startWithDek — the DEK from the successful
// BiometricPrompt. Rust stores it as the override; the app-locked init
// retry loop (ensure_android_core) picks it up.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_VeltaCore_provideDek(
    mut env: jni::JNIEnv,
    _this: jni::objects::JObject,
    dek: jni::objects::JString,
) -> jni::sys::jboolean {
    let hex = match env.get_string(&dek) {
        Ok(h) => h.to_string_lossy().into_owned(),
        Err(_) => return 0,
    };
    if hex.len() != 64 || !hex.chars().all(|c| c.is_ascii_hexdigit()) {
        log("db-key: provideDek refused (bad key shape)");
        return 0;
    }
    *ANDROID_DEK_OVERRIDE.lock().unwrap() = Some(format!("x'{hex}'"));
    1
}

// #178 phase 4: VeltaLock.notifyResult — the enable/disable prompt finished;
// the settings row follows the velta-biometric event.
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "system" fn Java_org_velta_VeltaLock_notifyResult(
    mut env: jni::JNIEnv,
    _class: jni::objects::JClass,
    on: jni::sys::jboolean,
    ok: jni::sys::jboolean,
    detail: jni::objects::JString,
) {
    // The prompt's error code + message (or the pre-prompt reason) so a
    // failed toggle is diagnosable from velta.log / the toast.
    let detail: String = env
        .get_string(&detail)
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_default();
    if ok == 0 {
        log(&format!("app-lock: biometric {} failed: {detail}", if on != 0 { "enable" } else { "disable" }));
    }
    Host::current().emit(
        "velta-biometric",
        serde_json::json!({ "on": on != 0, "ok": ok != 0, "detail": detail }),
    );
}

/// #178 phase 2: the database-encryption DEK from the Keystore, as 64 hex
/// chars. `None` = Keystore lost or unusable — the caller runs keyless and
/// encrypted databases stay closed (never recreated).
#[cfg(target_os = "android")]
fn android_keystore_dek() -> Option<String> {
    with_android_class(&APP_KEYSTORE_CLASS, "VeltaKeystore", |env, context, class_ref| {
        let out = env
            .call_static_method(
                class_ref,
                "getOrCreateDek",
                "(Landroid/content/Context;)Ljava/lang/String;",
                &[(&context).into()],
            )
            .map_err(|e| e.to_string())?;
        let obj = out.l().map_err(|e| e.to_string())?;
        if obj.is_null() {
            // Why (no key material): logged so a keyless start is diagnosable.
            let why = env
                .call_static_method(class_ref, "getLastError", "()Ljava/lang/String;", &[])
                .ok()
                .and_then(|v| v.l().ok())
                .filter(|o| !o.is_null())
                .and_then(|o| env.get_string(&jni::objects::JString::from(o)).ok().map(|s| s.to_string_lossy().into_owned()))
                .unwrap_or_else(|| "no reason recorded".to_string());
            log(&format!("db-key: keystore gave no DEK: {why}"));
            return Ok(None);
        }
        let jstr = jni::objects::JString::from(obj);
        let hex = env.get_string(&jstr).map_err(|e| e.to_string())?.to_string_lossy().into_owned();
        Ok(if hex.len() == 64 && !hex.is_empty() { Some(hex) } else { None })
    })
    .map_err(|e| {
        log(&format!("db-key: keystore call failed: {e}"));
        e
    })
    .ok()
    .flatten()
}


// ---- #178 phase 4: app-lock PIN on Android --------------------------------
// Same Argon2id wrap as desktop (db_key::pin_wrap_*), stored in
// noBackupFilesDir/dbkey.pin.wrap (never backed up). While it exists the
// plain Keystore wrap is gone: cold starts wait for the PIN (or the
// biometric overlay) before any database opens.

#[cfg(target_os = "android")]
fn android_pin_wrap() -> Option<PathBuf> {
    with_android_class(&APP_KEYSTORE_CLASS, "VeltaKeystore", |env, context, class_ref| {
        let out = env
            .call_static_method(class_ref, "noBackupDir", "(Landroid/content/Context;)Ljava/lang/String;", &[(&context).into()])
            .map_err(|e| e.to_string())?;
        let jstr = jni::objects::JString::from(out.l().map_err(|e| e.to_string())?);
        let dir = env.get_string(&jstr).map_err(|e| e.to_string())?.to_string_lossy().into_owned();
        Ok(PathBuf::from(dir).join("dbkey.pin.wrap"))
    })
    .map_err(|e| log(&format!("db-key: pin wrap path failed: {e}")))
    .ok()
}

/// The DEK the running core opened with (64 hex), if it runs keyed.
#[cfg(target_os = "android")]
fn android_current_dek() -> Option<String> {
    let raw = std::env::var("VELTA_DB_KEY").ok()?;
    let hex = raw.strip_prefix("x'")?.strip_suffix('\'')?;
    (hex.len() == 64 && hex.chars().all(|c| c.is_ascii_hexdigit())).then(|| hex.to_string())
}

#[cfg(target_os = "android")]
fn android_keystore_call(method: &str, sig: &str, extra: Option<&str>) -> Result<bool, String> {
    with_android_class(&APP_KEYSTORE_CLASS, "VeltaKeystore", |env, context, class_ref| {
        let out = match extra {
            Some(s) => {
                let js = env.new_string(s).map_err(|e| e.to_string())?;
                env.call_static_method(class_ref, method, sig, &[(&context).into(), (&js).into()])
            }
            None => env.call_static_method(class_ref, method, sig, &[(&context).into()]),
        }
        .map_err(|e| e.to_string())?;
        Ok(out.z().unwrap_or(true))
    })
}

#[cfg(target_os = "android")]
fn android_pin_set(old: Option<&str>, pin: &str) -> Result<(), String> {
    let path = android_pin_wrap().ok_or("no-key")?;
    let dek = if path.is_file() {
        let Some(old) = old else { return Err("current-pin-required".to_string()) };
        match db_key::pin_wrap_open(&path, old) {
            db_key::PinOpen::Dek(d) => d,
            db_key::PinOpen::Wrong { delay_secs, .. } => return Err(format!("retry:{delay_secs}")),
            db_key::PinOpen::Corrupt => return Err("corrupt".to_string()),
        }
    } else {
        android_current_dek().ok_or_else(|| {
            log("app-lock: PIN refused — the core runs without a database key");
            "no-key".to_string()
        })?
    };
    db_key::pin_wrap_write(&path, pin, &dek)?;
    if !matches!(db_key::pin_wrap_open(&path, pin), db_key::PinOpen::Dek(_)) {
        let _ = std::fs::remove_file(&path);
        return Err("wrap verify failed".to_string());
    }
    // The PIN replaces the plain Keystore wrap as the key root.
    let _ = android_keystore_call("deletePlainWrap", "(Landroid/content/Context;)V", None);
    log("app-lock: PIN is now the key root on Android; plain wrap removed");
    Ok(())
}

#[cfg(target_os = "android")]
fn android_pin_clear(pin: &str) -> Result<(), String> {
    let path = android_pin_wrap().ok_or("corrupt")?;
    let dek = match db_key::pin_wrap_open(&path, pin) {
        db_key::PinOpen::Dek(d) => d,
        db_key::PinOpen::Wrong { delay_secs, .. } => return Err(format!("retry:{delay_secs}")),
        db_key::PinOpen::Corrupt => return Err("corrupt".to_string()),
    };
    // With the biometric lock on it stays the root; otherwise the DEK goes
    // back into the plain Keystore wrap BEFORE the PIN wrap is removed.
    if !android_biometric_pending() {
        let ok = android_keystore_call("storePlainWrapHex", "(Landroid/content/Context;Ljava/lang/String;)Z", Some(&dek))?;
        if !ok {
            return Err("keychain-unavailable".to_string());
        }
    }
    let _ = std::fs::remove_file(&path);
    log("app-lock: PIN removed on Android");
    Ok(())
}

#[cfg(target_os = "android")]
fn android_pin_unlock(pin: &str) -> Result<(), String> {
    let path = android_pin_wrap().ok_or("corrupt")?;
    match db_key::pin_wrap_open(&path, pin) {
        db_key::PinOpen::Dek(hex) => {
            log("app-lock: PIN verified; handing the DEK to the core init");
            *ANDROID_DEK_OVERRIDE.lock().unwrap() = Some(format!("x'{hex}'"));
            Ok(())
        }
        db_key::PinOpen::Wrong { attempts, delay_secs } => {
            log(&format!("app-lock: wrong PIN (attempt {attempts}, wait {delay_secs} s)"));
            Err(format!("retry:{delay_secs}"))
        }
        db_key::PinOpen::Corrupt => Err("corrupt".to_string()),
    }
}

/// The biometric app lock is on: the DEK only opens after a prompt.
#[cfg(target_os = "android")]
fn android_biometric_pending() -> bool {
    with_android_class(&APP_LOCK_CLASS, "VeltaLock", |env, context, class_ref| {
        let out = env
            .call_static_method(class_ref, "on", "(Landroid/content/Context;)Z", &[(&context).into()])
            .map_err(|e| e.to_string())?;
        Ok(out.z().map_err(|e| e.to_string())?)
    })
    .map_err(|e| {
        log(&format!("db-key: biometric-state call failed: {e}"));
        e
    })
    .unwrap_or(false)
}

/// VeltaLock.request from a command: the activity (registered by
/// MainActivity) runs the prompt; the result comes back as the
/// velta-biometric event via Java_org_velta_VeltaLock_notifyResult.
#[cfg(target_os = "android")]
fn android_biometric_request(on: bool) -> Result<(), String> {
    // The running core's DEK (never logged): lets the enable flow wrap the
    // key the databases are actually open with, also when the plain wrap is
    // gone because the app-lock PIN is the key root.
    let current = android_current_dek().unwrap_or_default();
    with_android_class(&APP_LOCK_CLASS, "VeltaLock", |env, context, class_ref| {
        let dek = env.new_string(&current).map_err(|e| e.to_string())?;
        env.call_static_method(
            class_ref,
            "requestFromContext",
            "(Landroid/content/Context;ZLjava/lang/String;)Z",
            &[(&context).into(), jni::objects::JValue::from(on), (&dek).into()],
        )
        .map_err(|e| e.to_string())?
        .z()
        .map_err(|e| e.to_string())
    })
    .map_err(|e| {
        log(&format!("db-key: biometric request failed: {e}"));
        e
    })
    .and_then(|queued| {
        if queued { Ok(()) } else { Err("no activity is up to run the prompt".to_string()) }
    })
}

/// The auto-lock minutes reach Kotlin's SharedPreferences (the resume
/// check lives there); the desktop keeps the same setting in localStorage.
#[cfg(target_os = "android")]
fn android_set_autolock_mins(mins: i64) -> Result<(), String> {
    with_android_class(&APP_LOCK_CLASS, "VeltaLock", |env, context, class_ref| {
        env.call_static_method(
            class_ref,
            "setAutoLockMinutes",
            "(Landroid/content/Context;I)V",
            &[(&context).into(), jni::objects::JValue::from(mins.clamp(0, 240) as i32)],
        )
        .map(|_| ())
        .map_err(|e| e.to_string())
    })
    .map_err(|e| {
        log(&format!("db-key: autolock pref failed: {e}"));
        e
    })
}

#[cfg(target_os = "android")]
async fn init_android_core(
    accounts_dir: PathBuf,
    bg_pending: bg_events::PendingMap,
) -> anyhow::Result<tokio::sync::mpsc::UnboundedSender<String>> {
    use deltachat_jsonrpc::api::{Accounts, CommandApi};
    use futures_util::StreamExt;
    use std::sync::Arc;
    use tokio::sync::RwLock;
    use yerpc::{RpcClient, RpcSession};

    log(&format!("android accounts directory: {}", accounts_dir.display()));
    // Tell the frontend we're past the "starting" stage so the status pill
    // shows progress instead of looking stuck during Accounts::new().
    android_core_status(serde_json::json!({"running": true, "stage": "initializing"}));

    // #178 phase 2: load the DEK from the Keystore and migrate any plaintext
    // databases BEFORE Accounts::new opens them in-process. The key reaches
    // the core through the same VELTA_DB_KEY env var as the desktop sidecar
    // (quilt patch #20); no UI is involved, so push/job cold starts unlock
    // without user authentication.
    let override_raw = ANDROID_DEK_OVERRIDE.lock().unwrap().take();
    let pin_on = android_pin_wrap().is_some_and(|p| p.is_file());
    if let Some(raw) = override_raw {
        // Unlocked DEK (biometric or PIN): run the same prepare/migration as
        // the plain-wrap start, so databases still plaintext (the lock was
        // turned on while the core ran keyless) are encrypted, not misread.
        log("db-key: using the DEK from the app-lock unlock");
        let hex = raw.trim_start_matches("x'").trim_end_matches('\'').to_string();
        let report = db_key::prepare(&accounts_dir, Some(&hex));
        log(&format!(
            "db-key: unlock prepare: {} migrated, {} already encrypted, {} locked, key {}",
            report.migrated, report.already, report.locked, if report.use_key { "active" } else { "off" }
        ));
        if report.use_key {
            std::env::set_var("VELTA_DB_KEY", raw);
        }
        *DB_LOCK_STATUS.lock().unwrap() = None;
        Host::current().emit("velta-db-unlocked", serde_json::json!({}));
    } else if pin_on {
        // App-lock PIN is the key root: the page shows the PIN screen
        // (get_db_lock_status / velta-db-locked) and unlock_with_pin
        // hands the DEK over; the biometric overlay, when also on, offers
        // "Use PIN".
        log("db-key: app-lock PIN is on; core start waits for the PIN unlock");
        *DB_LOCK_STATUS.lock().unwrap() = Some(serde_json::json!({ "mode": "pin" }));
        Host::current().emit("velta-db-locked", serde_json::json!({ "mode": "pin" }));
        anyhow::bail!("app-locked");
    } else if android_biometric_pending() {
        // Nothing has been opened yet: Accounts::new will run again once
        // VeltaCore.startWithDek hands over the unlocked DEK.
        log("db-key: biometric app lock is on; core start waits for the activity unlock");
        anyhow::bail!("app-locked");
    } else if let Some(raw) = db_key::android_startup(&accounts_dir) {
        std::env::set_var("VELTA_DB_KEY", raw);
    }

    let accounts = Accounts::new(accounts_dir, true).await?;
    let accounts = Arc::new(RwLock::new(accounts));
    // UnifiedPush: expose the accounts manager to the JNI callbacks
    // (UnifiedPushService.kt) and apply an endpoint that arrived before the
    // core was ready.
    *ANDROID_ACCOUNTS.lock().unwrap() = Some(accounts.clone());
    // Take the token out of the mutex BEFORE awaiting — the if-let scrutinee
    // temporary (a non-Send MutexGuard) would otherwise be held across the
    // await and make this future non-Send.
    let pending_token = PENDING_PUSH_TOKEN.lock().unwrap().take();
    if let Some(token) = pending_token {
        if let Err(e) = accounts.read().await.set_push_device_token(&token) {
            log(&format!("parked push endpoint apply failed: {e}"));
        } else {
            log("parked push endpoint applied to the accounts manager");
            Host::current().emit("velta-push", serde_json::json!({"stage": "endpoint"}));
        }
    }
    android_core_status(serde_json::json!({"running": true, "stage": "configuring"}));

    let state = CommandApi::from_arc(accounts.clone()).await;

    let (client, mut out_receiver) = RpcClient::new();
    let session = RpcSession::new(client.clone(), state);
    let (req_tx, mut req_rx) = tokio::sync::mpsc::unbounded_channel::<String>();
    // UnifiedPush: the push wake-up uses this channel for background_fetch.
    *ANDROID_RPC_TX.lock().unwrap() = Some(req_tx.clone());

    // Forward JSON-RPC responses and events to the WebView (when one is
    // attached: a headless core only has the "bg-" round-trips).
    tokio::spawn(async move {
        while let Some(message) = out_receiver.next().await {
            let is_wxdc = match &message {
                yerpc::Message::Response(response) => matches!(
                    &response.id,
                    Some(yerpc::Id::String(id)) if id.starts_with("wxdc-")
                ),
                _ => false,
            };
            if is_wxdc {
                if let (Ok(line), Some(app)) = (serde_json::to_string(&message), ui_app()) {
                    webxdc_resolve_line(&app, &line);
                }
                continue;
            }
            let bg_id = match &message {
                yerpc::Message::Response(response) => match &response.id {
                    Some(yerpc::Id::String(id)) if id.starts_with("bg-") => Some(id.clone()),
                    _ => None,
                },
                _ => None,
            };
            if let Some(id) = bg_id {
                if let Ok(line) = serde_json::to_string(&message) {
                    let pending = bg_pending.clone();
                    // A batch arriving while the UI is visible (the request
                    // was parked before the app came back) is the WebView's.
                    let line = if bg_events::is_event_batch_id(&id) {
                        let visible = android_ui_visible();
                        let (fwd, to_poller) = bg_events::route_event_batch(&id, line, visible);
                        if let Some(fwd) = fwd {
                            ui_emit_rpc(&fwd);
                        }
                        to_poller
                    } else {
                        line
                    };
                    if let Some(orphan) = bg_events::deliver(&pending, &id, line) {
                        // Nobody waits for it any more (#21/#22): an event
                        // batch taken off the core's queue belongs to the
                        // WebView then — dropping it lost those events.
                        if bg_events::is_event_batch_id(&id) {
                            if let Some(fwd) = bg_events::forwarded_events_line(&orphan) {
                                log(&format!("bg event batch {id} had no waiter: forwarded to the WebView"));
                                ui_emit_rpc(&fwd);
                            }
                        } else {
                            log(&format!("bg rpc response {id} arrived after its caller gave up"));
                        }
                    }
                }
                continue;
            }
            let line = match serde_json::to_string(&message) {
                Ok(line) => line,
                Err(e) => {
                    log(&format!("jsonrpc serialize error: {e}"));
                    continue;
                }
            };
            // The page's own poll may be the waiter. Notify when the user
            // is not looking (page hidden or activity stopped) and still
            // hand the batch to the WebView. The page does not post on
            // Android, so this is the only card for a page-poll batch,
            // including the moment after the page hides and before onStop.
            // bg- responses never reach this arm; the poller notifies those.
            if !android_ui_visible() {
                let hits = bg_events::incoming_hits(&line);
                if !hits.is_empty() {
                    let tx = ANDROID_RPC_TX.lock().unwrap().clone();
                    if let (Some(tx), Some(state)) = (tx, android_core()) {
                        tauri::async_runtime::spawn(async move {
                            bg_notify_incoming(&tx, state, hits).await;
                        });
                    }
                }
            }
            // NOTE: do not log every response -- it's the hot path and would
            // grow velta.log unbounded. Errors are still logged below.
            ui_emit_rpc(&line);
        }
    });

    // Process incoming JSON-RPC requests.
    // Stall diagnostics (Refs #176): every request is tracked while the core
    // works on it; >= 2 s logs "core rpc slow", and a watchdog names the
    // oldest calls still inside the core plus any runtime stall, so a
    // frozen chat open shows WHICH core call hogs it (vs a lost response).
    let inflight: std::sync::Arc<std::sync::Mutex<std::collections::HashMap<u64, (String, std::time::Instant)>>> =
        Default::default();
    start_core_rpc_watchdog(inflight.clone());
    tokio::spawn(async move {
        let mut seq: u64 = 0;
        while let Some(line) = req_rx.recv().await {
            // NOTE: do not log every request here either.
            let session = session.clone();
            seq = seq.wrapping_add(1);
            let key = seq;
            let method = rpc_method_of(&line);
            let inflight = inflight.clone();
            inflight.lock().unwrap().insert(key, (method.clone(), std::time::Instant::now()));
            tokio::spawn(async move {
                let started = std::time::Instant::now();
                session.handle_incoming(&line).await;
                inflight.lock().unwrap().remove(&key);
                let ms = started.elapsed().as_millis();
                if ms >= 2000 && !rpc_parks_by_design(&method) {
                    log(&format!("core rpc slow: {method} took {ms} ms"));
                }
            });
        }
    });

    log("android core RPC session and response forwarder ready");
    Ok(req_tx)
}

/// The "method" of a JSON-RPC request line (diagnostics only).
#[cfg_attr(not(target_os = "android"), allow(dead_code))]
fn rpc_method_of(line: &str) -> String {
    #[derive(serde::Deserialize)]
    struct M<'a> {
        #[serde(borrow)]
        method: Option<std::borrow::Cow<'a, str>>,
    }
    serde_json::from_str::<M>(line)
        .ok()
        .and_then(|m| m.method.map(|c| c.into_owned()))
        .unwrap_or_else(|| "?".to_string())
}

/// Long polls that wait for work by design (not a stall).
#[cfg_attr(not(target_os = "android"), allow(dead_code))]
fn rpc_parks_by_design(method: &str) -> bool {
    matches!(method, "get_next_event_batch" | "get_next_event" | "background_fetch" | "wait_next_msgs")
}

/// One line per stall episode: the oldest in-flight core calls ("core rpc
/// in flight (N): get_chatlist_items_by_entries 12.0s, ..."), at most every
/// 10 s while a call is older than 8 s; plus "core runtime stalled" when the
/// watchdog's own 2 s tick ran >= 1.5 s late (a blocked tokio worker).
#[cfg_attr(not(target_os = "android"), allow(dead_code))]
fn summarize_inflight(
    rows: &std::collections::HashMap<u64, (String, std::time::Instant)>,
    now: std::time::Instant,
    min_age: std::time::Duration,
) -> Option<String> {
    let mut v: Vec<(&str, std::time::Duration)> = rows
        .values()
        .filter(|(m, _)| !rpc_parks_by_design(m))
        .map(|(m, t)| (m.as_str(), now.saturating_duration_since(*t)))
        .collect();
    v.sort_by(|a, b| b.1.cmp(&a.1));
    if v.first().map_or(true, |(_, age)| *age < min_age) {
        return None;
    }
    let top: Vec<String> = v.iter().take(8).map(|(m, a)| format!("{m} {:.1}s", a.as_secs_f64())).collect();
    Some(format!("core rpc in flight ({}): {}", v.len(), top.join(", ")))
}

#[cfg(target_os = "android")]
fn start_core_rpc_watchdog(
    inflight: std::sync::Arc<std::sync::Mutex<std::collections::HashMap<u64, (String, std::time::Instant)>>>,
) {
    tokio::spawn(async move {
        let tick = std::time::Duration::from_secs(2);
        let mut last_report: Option<std::time::Instant> = None;
        loop {
            let before = std::time::Instant::now();
            tokio::time::sleep(tick).await;
            let now = std::time::Instant::now();
            let late = now.duration_since(before).saturating_sub(tick);
            if late >= std::time::Duration::from_millis(1500) {
                log(&format!("core runtime stalled: watchdog tick {} ms late", late.as_millis()));
            }
            if last_report.is_some_and(|t| now.duration_since(t) < std::time::Duration::from_secs(10)) {
                continue;
            }
            let line = summarize_inflight(&inflight.lock().unwrap(), now, std::time::Duration::from_secs(8));
            if let Some(line) = line {
                log(&line);
                last_report = Some(now);
            }
        }
    });
}

// Interrupt IDLE so a socket Android stopped delivering actually fetches.
// force skips the short debounce (resume, and the background safety net).
#[cfg(target_os = "android")]
static LAST_MAYBE_NETWORK_MS: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

#[cfg(target_os = "android")]
fn kick_maybe_network(force: bool) {
    if !force {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis() as u64)
            .unwrap_or(0);
        let prev = LAST_MAYBE_NETWORK_MS.load(std::sync::atomic::Ordering::SeqCst);
        if now.saturating_sub(prev) < 3_000 {
            return;
        }
        LAST_MAYBE_NETWORK_MS.store(now, std::sync::atomic::Ordering::SeqCst);
    }
    spawn_core_rpc("maybe_network", force);
}

#[cfg(target_os = "android")]
fn spawn_core_rpc(method: &'static str, log_ok: bool) {
    let Some(state) = android_core() else {
        log(&format!("{method}: core not initialized"));
        return;
    };
    let Some(tx) = ANDROID_RPC_TX.lock().unwrap().clone() else {
        log(&format!("{method}: rpc channel not ready"));
        return;
    };
    tauri::async_runtime::spawn(async move {
        match bg_rpc(&tx, state, method, serde_json::json!([])).await {
            Ok(_) => {
                if log_ok {
                    log(&format!("{method}: done"));
                }
            }
            Err(e) => log(&format!("{method}: {e}")),
        }
    });
}

// While the activity is stopped, break a half-open IDLE every 10 min
// (bg_events::BG_KICK_INTERVAL_SECS; was 90 s). A healthy connection is
// interrupted and goes straight back to IDLE; a dead one fetches. Skipped
// while UnifiedPush is delivering (bg_events::bg_kick_due). The poller does
// not do this — it only reads events.
#[cfg(target_os = "android")]
static PUSH_ENDPOINT_SET: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
// Unix seconds of the last push received in this process; 0 = none.
#[cfg(target_os = "android")]
static LAST_PUSH_SECS: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

#[cfg(target_os = "android")]
fn unix_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| d.as_secs())
}

#[cfg(target_os = "android")]
fn bg_kick_due_now() -> bool {
    let last = LAST_PUSH_SECS.load(std::sync::atomic::Ordering::SeqCst);
    let age = (last != 0).then(|| unix_secs().saturating_sub(last));
    bg_events::bg_kick_due(
        android_ui_visible(),
        PUSH_ENDPOINT_SET.load(std::sync::atomic::Ordering::SeqCst),
        age,
    )
}

#[cfg(target_os = "android")]
fn start_bg_fetch_kicker(tx: tokio::sync::mpsc::UnboundedSender<String>) {
    tauri::async_runtime::spawn(async move {
        loop {
            tokio::time::sleep(std::time::Duration::from_secs(bg_events::BG_KICK_INTERVAL_SECS)).await;
            if !bg_kick_due_now() {
                continue;
            }
            let Some(state) = android_core() else { continue };
            if let Err(e) = bg_rpc(&tx, state, "maybe_network", serde_json::json!([])).await {
                log(&format!("background maybe_network: {e}"));
            }
        }
    });
}

// Round-trip a JSON-RPC call from Rust while the UI is hidden. Requests use
// ids prefixed "bg-"; the response forwarder routes them back through
// bg_pending (same pattern as the "wxdc-" webxdc round-trips).
// Not android-gated (like bg_rpc_with), so desktop builds type-check it.
#[cfg_attr(not(target_os = "android"), allow(dead_code))]
static BG_RPC_COUNTER: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

#[cfg(target_os = "android")]
async fn bg_rpc(
    tx: &tokio::sync::mpsc::UnboundedSender<String>,
    state: &RpcState,
    method: &str,
    params: serde_json::Value,
) -> Result<serde_json::Value, String> {
    bg_rpc_with(tx, state, "bg-", method, params, Some(std::time::Duration::from_secs(60))).await
}

// timeout None: wait as long as the core takes (the event long poll parks
// by design — timing it out left the request parked in the core, which then
// handed its next batch to a caller that was gone). The PendingGuard clears
// the bg_pending entry however this future ends (#21/#22).
#[cfg_attr(not(target_os = "android"), allow(dead_code))]
async fn bg_rpc_with(
    tx: &tokio::sync::mpsc::UnboundedSender<String>,
    state: &RpcState,
    id_prefix: &str,
    method: &str,
    params: serde_json::Value,
    timeout: Option<std::time::Duration>,
) -> Result<serde_json::Value, String> {
    let id = format!("{id_prefix}{}", BG_RPC_COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed));
    let request = serde_json::json!({"jsonrpc": "2.0", "id": id, "method": method, "params": params});
    let (_guard, resp_rx) = bg_events::PendingGuard::register(&state.bg_pending, id);
    tx.send(request.to_string()).map_err(|_| "core rpc channel closed".to_string())?;
    let line = match timeout {
        Some(limit) => tokio::time::timeout(limit, resp_rx)
            .await
            .map_err(|_| "bg rpc timed out".to_string())?,
        None => resp_rx.await,
    }
    .map_err(|_| "bg rpc dropped".to_string())?;
    let value: serde_json::Value = serde_json::from_str(&line).map_err(|e| e.to_string())?;
    if let Some(err) = value.get("error") {
        return Err(format!("bg rpc error: {err}"));
    }
    Ok(value.get("result").cloned().unwrap_or(serde_json::Value::Null))
}

// Post notifications for a drain cycle's incoming messages — one
// conversation per chat (MessagingStyle via org.velta.Notifications):
// group name as title, sender name as the second line, plain message text
// (never a "Group: text" prefix), sender avatar on the left, chat avatar
// on the right, and consecutive messages of one chat grouped into a single
// conversation. Falls back to plain title/body when the Kotlin side is not
// reachable (application context not handed over yet).
#[cfg(any(target_os = "android", test))]
/// "@Name" mention of `name` in `text`: case-insensitive, "@" at a word
/// start (not an e-mail "a@b"), word boundary after the name. Mirrors
/// mentions.js findMentions for a single member (docs/mentions.md).
fn text_mentions_name(text: &str, name: &str) -> bool {
    let name = name.trim().to_lowercase();
    if name.is_empty() {
        return false;
    }
    let lower = text.to_lowercase();
    let word = |c: char| c.is_alphanumeric() || c == '_';
    let bad_before = |c: char| word(c) || ".@+-%&/:#".contains(c);
    for (i, _) in lower.match_indices('@') {
        if lower[..i].chars().next_back().is_some_and(bad_before) {
            continue;
        }
        let rest = &lower[i + 1..];
        if rest.starts_with(&name) && !rest[name.len()..].chars().next().is_some_and(word) {
            return true;
        }
    }
    false
}

/// Notification body for a background message: its text, or for an
/// uncaptioned attachment a short label by view type (empty = skip).
#[cfg(any(target_os = "android", test))]
fn bg_notify_text(text: &str, view_type: &str, file_name: Option<&str>) -> String {
    let text = text.trim();
    if !text.is_empty() {
        return text.to_string();
    }
    let file = file_name.map(str::trim).filter(|f| !f.is_empty());
    match view_type {
        "Image" => "Photo".into(),
        "Gif" => "GIF".into(),
        "Sticker" => "Sticker".into(),
        "Video" => "Video".into(),
        "Voice" => "Voice message".into(),
        "Audio" => file.map_or("Audio".into(), |f| format!("Audio: {f}")),
        "File" => file.map_or("File".into(), |f| format!("File: {f}")),
        "Webxdc" => file.map_or("App".into(), |f| format!("App: {f}")),
        "Vcard" => "Contact".into(),
        _ => String::new(),
    }
}

#[cfg(test)]
mod bg_notify_text_tests {
    use super::bg_notify_text;
    #[test]
    fn labels() {
        assert_eq!(bg_notify_text(" hi ", "Image", None), "hi");
        assert_eq!(bg_notify_text("", "Image", Some("a.jpg")), "Photo");
        assert_eq!(bg_notify_text("", "Voice", None), "Voice message");
        assert_eq!(bg_notify_text("", "File", Some("doc.pdf")), "File: doc.pdf");
        assert_eq!(bg_notify_text("", "File", None), "File");
        assert_eq!(bg_notify_text("", "Text", None), "");
    }
}

#[cfg(test)]
mod mention_tests {
    use super::text_mentions_name;
    #[test]
    fn mentions() {
        assert!(text_mentions_name("hey @Pavel B (1A2B) look", "Pavel B"));
        assert!(text_mentions_name("@pavel!", "Pavel"));
        assert!(!text_mentions_name("mail pavel@x.org", "Pavel"));
        assert!(!text_mentions_name("@Pavelka hi", "Pavel"));
        assert!(!text_mentions_name("a@Pavel", "Pavel"));
        assert!(!text_mentions_name("@Pavel", ""));
        assert!(text_mentions_name("(@Пётр) ок", "пётр"));
    }
}

#[cfg(target_os = "android")]
async fn bg_notify_incoming(
    tx: &tokio::sync::mpsc::UnboundedSender<String>,
    state: &RpcState,
    hits: Vec<(u32, u32, u32)>, // (account, chatId, msgId)
) {
    use tauri_plugin_notification::NotificationExt;

    // Drawer notification prefs (page pushes them; defaults until it does).
    let prefs = notify_prefs_snapshot();
    if !prefs.enabled || !prefs.system_new_msgs {
        return;
    }

    // Oldest first so the newest message lands last in each conversation;
    // cap a burst so a 50-message flood does not spin 50 RPC round trips.
    let recent: Vec<&(u32, u32, u32)> = hits.iter().rev().take(8).collect();
    // "Mentions only" heuristic: the message mentions the user when the
    // text contains their display name or any @-name. Core has no mention
    // flag on the wire yet; cheap and conservative in the notify-more
    // direction only when the name collides.
    let own_name = if prefs.mentions_only {
        let account = recent.first().map(|h| h.0).unwrap_or(1);
        bg_rpc(tx, state, "get_config", serde_json::json!([account, "displayname"]))
            .await
            .ok()
            .and_then(|v| v.as_str().map(str::to_string))
    } else {
        None
    };
    for &&(account, chat_id, msg_id) in recent.iter().rev() {
        // Muted chats must not notify while hidden (#52 L1): the same
        // is_chat_muted() readback the UI path is documented to gate on
        // (core api.rs); timed mutes resolve inside the core. A lookup
        // failure notifies — better a redundant card than a lost one.
        let muted = matches!(
            bg_rpc(
                tx,
                state,
                "is_chat_muted",
                serde_json::json!([account, chat_id]),
            )
            .await,
            Ok(serde_json::Value::Bool(true))
        );
        if muted && !prefs.mentions_in_muted {
            continue;
        }
        let Ok(msg) = bg_rpc(tx, state, "get_message", serde_json::json!([account, msg_id])).await
        else {
            continue;
        };
        let text = msg.get("text").and_then(|t| t.as_str()).unwrap_or("").trim().to_string();
        // A photo / voice note / file without caption has empty text; it
        // used to be skipped, so media never notified in the background.
        let text = bg_notify_text(
            &text,
            msg.get("viewType").and_then(|v| v.as_str()).unwrap_or(""),
            msg.get("fileName").and_then(|v| v.as_str()),
        );
        if text.is_empty() {
            continue;
        }
        // Muted chat: only an "@<my display name>" mention gets through
        // (docs/mentions.md — name match only here; the fingerprint code
        // check runs in the page).
        if muted {
            let me = bg_rpc(tx, state, "get_config", serde_json::json!([account, "displayname"]))
                .await
                .ok()
                .and_then(|v| v.as_str().map(str::to_string))
                .unwrap_or_default();
            if !text_mentions_name(&text, &me) {
                continue;
            }
        }
        // "Mentions only": skip messages that neither name the user nor
        // carry any @-mention.
        if let Some(own) = &own_name {
            let lower = text.to_lowercase();
            if !lower.contains('@') && !lower.contains(&own.to_lowercase()) {
                continue;
            }
        }
        // "Show message content" OFF: the card stays, the text goes.
        let text = if prefs.show_content {
            text
        } else {
            "New message".to_string()
        };
        let from_id = msg.get("fromId").and_then(|v| v.as_u64()).unwrap_or(0) as u32;
        let ts_ms = (msg.get("sortTimestamp").and_then(|v| v.as_i64()).unwrap_or(0) * 1000).max(0);

        let (chat_name, chat_avatar, chat_type) = match bg_rpc(
            tx,
            state,
            "get_basic_chat_info",
            serde_json::json!([account, chat_id]),
        )
        .await
        {
            Ok(c) => (
                c.get("name")
                    .and_then(|n| n.as_str())
                    .unwrap_or("Velta")
                    .trim()
                    .to_string(),
                c.get("profileImage").and_then(|n| n.as_str()).map(str::to_string),
                c.get("chatType")
                    .and_then(|n| n.as_str())
                    .unwrap_or("Single")
                    .to_string(),
            ),
            Err(_) => ("Velta".to_string(), None, "Single".to_string()),
        };
        let is_group = chat_type != "Single";

        let (sender_name, sender_avatar) =
            match bg_rpc(tx, state, "get_contact", serde_json::json!([account, from_id])).await {
                Ok(c) => (
                    c.get("displayName")
                        .and_then(|v| v.as_str())
                        .filter(|s| !s.trim().is_empty())
                        .or_else(|| c.get("name").and_then(|v| v.as_str()))
                        .unwrap_or("Contact")
                        .to_string(),
                    c.get("profileImage").and_then(|v| v.as_str()).map(str::to_string),
                ),
                Err(_) => (if is_group { "Contact".to_string() } else { chat_name.clone() }, None),
            };

        if kotlin_notify_incoming(
            account,
            chat_id,
            is_group,
            &chat_name,
            chat_avatar.as_deref(),
            &sender_name,
            sender_avatar.as_deref(),
            &text,
            ts_ms,
        )
        .is_ok()
        {
            continue;
        }

        // Fallback: plain title/body (no "Group:" prefix — that was the bug).
        let title = if is_group { chat_name.clone() } else { sender_name.clone() };
        if let Some(app) = ui_app() {
            let _ = app.notification().builder().title(title).body(text).show();
        }
    }
}

// Bridge to org.velta.Notifications.show over JNI (see the Kotlin source for
// the layout contract). Fails when the application context or the cached
// class is missing — the caller falls back to the plugin notification.
#[cfg(target_os = "android")]
#[allow(clippy::too_many_arguments)]
fn kotlin_notify_incoming(
    account: u32,
    chat_id: u32,
    is_group: bool,
    chat_name: &str,
    chat_avatar: Option<&str>,
    sender_name: &str,
    sender_avatar: Option<&str>,
    text: &str,
    timestamp_ms: i64,
) -> Result<(), String> {
    with_android_class(&APP_NOTIFICATIONS_CLASS, "Notifications", |env, context, class_ref| {
        let token = android_chat_link_token()?;
        let chat_key = env.new_string(format!("{account}:{chat_id}")).map_err(|e| e.to_string())?;
        let chat_name_j = env.new_string(chat_name).map_err(|e| e.to_string())?;
        let chat_avatar_j = opt_jstring(env, chat_avatar)?;
        let sender_name_j = env.new_string(sender_name).map_err(|e| e.to_string())?;
        let sender_avatar_j = opt_jstring(env, sender_avatar)?;
        let text_j = env.new_string(text).map_err(|e| e.to_string())?;
        let token_j = env.new_string(token).map_err(|e| e.to_string())?;

        env.call_static_method(
            class_ref,
            "show",
            "(Landroid/content/Context;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V",
            &[
                (&context).into(),
                (&chat_key).into(),
                jni::objects::JValue::Bool(is_group as u8),
                (&chat_name_j).into(),
                (&chat_avatar_j).into(),
                (&sender_name_j).into(),
                (&sender_avatar_j).into(),
                (&text_j).into(),
                jni::objects::JValue::Long(timestamp_ms),
                (&token_j).into(),
            ],
        )
        .map_err(|e| e.to_string())?;
        Ok(())
    })
}

#[cfg(target_os = "android")]
fn battery_is_exempt() -> Result<bool, String> {
    with_android_class(&APP_BATTERY_CLASS, "Battery", |env, context, class_ref| {
        env.call_static_method(class_ref, "isExempt", "(Landroid/content/Context;)Z", &[(&context).into()])
            .map_err(|e| e.to_string())?
            .z()
            .map_err(|e| e.to_string())
    })
}

#[cfg(target_os = "android")]
fn battery_request_exemption() -> Result<(), String> {
    with_android_class(&APP_BATTERY_CLASS, "Battery", |env, context, class_ref| {
        env.call_static_method(class_ref, "request", "(Landroid/content/Context;)V", &[(&context).into()])
            .map_err(|e| e.to_string())?;
        Ok(())
    })
}

// #60: hand the downloaded APK to the system installer via UpdateInstall.kt
// (FileProvider URI + ACTION_VIEW package-archive). Ok only when the
// installer activity actually launched.
#[cfg(target_os = "android")]
fn install_update_android(path: String) -> Result<(), String> {
    with_android_class(&APP_UPDATE_INSTALL_CLASS, "UpdateInstall", |env, context, class_ref| {
        let jpath = env.new_string(&path).map_err(|e| e.to_string())?;
        let ok = env
            .call_static_method(
                class_ref,
                "install",
                "(Landroid/content/Context;Ljava/lang/String;)Z",
                &[(&context).into(), (&jpath).into()],
            )
            .map_err(|e| e.to_string())?;
        if ok.z().map_err(|e| e.to_string())? {
            Ok(())
        } else {
            Err("installer did not open — APK missing?".into())
        }
    })
}

#[cfg(target_os = "android")]
fn opt_jstring<'local>(
    env: &mut jni::JNIEnv<'local>,
    value: Option<&str>,
) -> Result<jni::objects::JObject<'local>, String> {
    match value {
        Some(s) => Ok(env.new_string(s).map_err(|e| e.to_string())?.into()),
        None => Ok(jni::objects::JObject::null()),
    }
}

// Drain the core's event queue while the UI cannot: with the foreground
// service keeping the process alive, this is what turns background mail
// into notifications. The poller runs when the page is hidden or the
// activity is stopped. Events it consumes never reach the frontend; resume
// refetches via visibilitychange and the velta-foreground event.
#[cfg(target_os = "android")]
fn start_bg_event_poller(tx: tokio::sync::mpsc::UnboundedSender<String>) {
    tauri::async_runtime::spawn(async move {
        log("background event poller started");
        loop {
            // Single reader (#40): the page no longer polls on Android, so
            // unlike the pre-#40 pause the poller does NOT sleep while the
            // UI is up — it is the only reader and routes each batch by
            // visibility (forward while visible, notify while hidden). It
            // only waits for the page's listener handshake so no batch is
            // forwarded into a receiver the page has not installed yet.
            // A headless core (no page in this process) has no listener
            // to wait for: it reads and notifies right away.
            if ui_app().is_some() && !EVENTS_LISTENER_READY.load(std::sync::atomic::Ordering::SeqCst) {
                tokio::time::sleep(std::time::Duration::from_millis(500)).await;
                continue;
            }
            let Some(state) = android_core() else {
                tokio::time::sleep(std::time::Duration::from_millis(500)).await;
                continue;
            };
            // One parked request at a time, never timed out (see bg_rpc_with).
            match bg_rpc_with(
                &tx,
                state,
                bg_events::EVENT_BATCH_ID_PREFIX,
                "get_next_event_batch",
                serde_json::json!([]),
                None,
            )
            .await
            {
                Ok(result) => {
                    // Batches that arrived while the UI was visible were
                    // already forwarded to the WebView by the response
                    // forwarder; they reach here empty (used to be dropped).
                    if android_ui_visible() {
                        // UI came back between the forwarder and here: hand
                        // the batch over instead of dropping it.
                        if let Some(fwd) = bg_events::forwarded_events_from_result(&result) {
                            ui_emit_rpc(&fwd);
                        }
                        continue;
                    }
                    let events = result.as_array().cloned().unwrap_or_default();
                    let mut hits: Vec<(u32, u32, u32)> = Vec::new();
                    for ev in &events {
                        if ev.pointer("/event/kind").and_then(|k| k.as_str()) != Some("IncomingMsg") {
                            continue;
                        }
                        hits.push((
                            ev.get("contextId").and_then(|v| v.as_u64()).unwrap_or(0) as u32,
                            ev.pointer("/event/chatId").and_then(|v| v.as_u64()).unwrap_or(0) as u32,
                            ev.pointer("/event/msgId").and_then(|v| v.as_u64()).unwrap_or(0) as u32,
                        ));
                    }
                    if !hits.is_empty() {
                        bg_notify_incoming(&tx, state, hits).await;
                    }
                }
                Err(_) => {
                    // Core not ready yet or the round-trip was dropped: back off.
                    tokio::time::sleep(std::time::Duration::from_secs(5)).await;
                }
            }
        }
    });
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let mut builder = tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .setup(|app| {
            let log_dir_path = {
                #[cfg(target_os = "android")]
                {
                    app.path().app_local_data_dir().unwrap_or_else(|_| PathBuf::from(".")).join("logs")
                }
                #[cfg(windows)]
                {
                    let local_app_data = std::env::var("LOCALAPPDATA").unwrap_or_default();
                    Path::new(&local_app_data).join("Velta").join("logs")
                }
                // macOS/Linux have no LOCALAPPDATA: the Windows branch would
                // yield the relative "Velta/logs", i.e. "/" as CWD for an
                // .app bundle (unwritable) — logs silently lost. Use the
                // platform log dir (~/Library/Logs/org.velta on macOS).
                #[cfg(not(any(windows, target_os = "android")))]
                {
                    app.path()
                        .app_log_dir()
                        .unwrap_or_else(|_| std::env::temp_dir().join("velta-logs"))
                }
            };
            // set_log_dir() must run BEFORE the first log() call, otherwise
            // the very first "setup started" line goes to the fallback path
            // (temp dir on Android) and the writer thread is bound to the
            // wrong directory for the whole session.
            set_log_dir(log_dir_path);
            notify_prefs_load(app.handle());            #[cfg(target_os = "android")]
            {
                let ext_logs = PathBuf::from("/storage/emulated/0/Android/data")
                    .join(app.config().identifier.clone())
                    .join("files")
                    .join("logs");
                set_mirror_log_dir(ext_logs);
            }
            // The loopback media server runs on every platform: Android's
            // asset protocol (WebViewAssetLoader) answers the first range
            // request but fails mid-file reads, so moov-at-end videos die in
            // the demuxer there; the server's real 206 responses fix playback.
            {
                // 128 random bits: the token is the only thing standing
                // between other local processes/users and the account files
                // this server can read, so it must not be derivable from the
                // start time or the PID.
                *MEDIA_TOKEN.lock().unwrap() = {
                    data_encoding::HEXLOWER.encode(&random_bytes::<16>())
                };
                start_media_server(accounts_dir(app.handle()));
            }

            log("setup started");
            #[cfg(windows)]
            ensure_sendto_shortcut();

            let accounts = accounts_dir(app.handle());
            let _ = std::fs::create_dir_all(&accounts);
            log(&format!("accounts directory: {}", accounts.display()));

            // Local-only P2P chat engine -- independent of the Delta Chat core,
            // runs on Tauri's async runtime on every platform. Manage the exact
            // type the commands expect (P2pState itself, NOT a wrapper -- a
            // mismatch surfaces as "state not managed" at command time); the
            // engine fills in asynchronously so early p2p_* calls report
            // "still starting" instead of failing with an unmanaged-state error.
            {
                let p2p_dir = app
                    .path()
                    .resolve("p2p", tauri::path::BaseDirectory::AppLocalData);
                let state = p2p::P2pState::empty();
                let slot = state.slot();
                let enabled = state.enabled_flag();
                // Media blobs must sit under the accounts dir: the blobfile /
                // media-server pipeline refuses to serve anything outside it.
                let blobs_dir = accounts_dir(app.handle()).join("p2p-blobs");
                if let Ok(dir) = p2p_dir {
                    state.set_dir(dir.clone());
                    state.set_blobs(blobs_dir.clone());
                    p2p::spawn_startup(app.handle().clone(), slot, enabled, dir, blobs_dir);
                } else {
                    log("p2p data dir unavailable");
                }
                app.manage(state);
            }

            #[cfg(target_os = "android")]
            {
                // Setup must return immediately so WebView creation is not
                // delayed; core init continues on its own runtime. Until
                // tx is set, rpc() calls report "not running", which lets
                // the frontend retry instead of dead-ending on startup.
                // A core a service/push/job/alarm already started headless
                // in this process is reused, not created twice; the app
                // handle is attached so its events reach the page now.
                if let Ok(dir) = app.path().app_local_data_dir() {
                    ANDROID_DATA_DIR.lock().unwrap().get_or_insert(dir);
                }
                let reused = android_core().is_some();
                *APP_HANDLE.lock().unwrap() = Some(app.handle().clone());
                let state = ensure_android_core(accounts);
                app.manage(state.clone());
                if reused {
                    log("android core already running (started headless): attached the UI");
                    let st = SIDECAR_STATUS.lock().unwrap().clone();
                    if let Some(st) = st {
                        set_sidecar_status(app.handle(), st);
                    }
                    // Tunnel/proxy events reach the page through
                    // Host::emit's fallback to the attached app.
                }
            }

            #[cfg(not(target_os = "android"))]
            {
                let app_handle = app.app_handle().clone();
                // #178: load the DEK from the keychain and migrate any
                // plaintext databases BEFORE the sidecar opens them — the
                // files must be untouched while sqlcipher_export runs.
                // #178: load the DEK from the keychain and migrate any plaintext
                // databases BEFORE the sidecar opens them — the files must be
                // untouched while sqlcipher_export runs. An app-lock PIN wrap
                // starts the session LOCKED: the sidecar spawns keyless and
                // unlock_with_pin respawns it keyed after the PIN is entered.
                let (db_key, key_issue, pin_locked) = db_key::startup(&accounts);
                set_db_key_issue(key_issue);
                if pin_locked {
                    *DB_LOCK_STATUS.lock().unwrap() = Some(serde_json::json!({ "mode": "pin" }));
                }
                spawn_sidecar(&app_handle, db_key, true);
                // Once the sidecar answers, report accounts the key could not
                // open (locked screen in the UI); probe keeps a PIN marker.
                tauri::async_runtime::spawn(probe_db_lock(app_handle.clone()));
            }
            Ok(())
        })
        .register_asynchronous_uri_scheme_protocol("webxdc", move |ctx, request, responder| {
    let app = ctx.app_handle().clone();
    tauri::async_runtime::spawn(async move {
        let response = webxdc_serve(app, request).await;
        responder.respond(response);
    });
})
.register_asynchronous_uri_scheme_protocol("blobfile", |ctx, request, responder| {
            let app = ctx.app_handle().clone();
            // Decode and file IO stay off the UI thread. A 12 MP JPEG
            // thumbnail is about 160 ms on desktop.
            tauri::async_runtime::spawn(async move {
                let response = tauri::async_runtime::spawn_blocking(move || {
                    let mut response = serve_blob_file(&app, request);
                    // Blob URLs are content-deduplicated by the core (same name =
                    // same bytes), so media is immutable: let the WebView cache it.
                    // Reopening a chat then decodes images from memory/disk cache
                    // instead of re-reading and re-decoding every blob.
                    response.headers_mut().insert("Cache-Control", "max-age=31536000, immutable".parse().unwrap());
                    response
                })
                .await
                .unwrap_or_else(|_| {
                    tauri::http::Response::builder()
                        .status(500)
                        .body(b"blobfile task failed".to_vec())
                        .unwrap()
                });
                responder.respond(response);
            });
        })
        .invoke_handler(tauri::generate_handler![js_log, rpc, set_ui_visible, get_event_reader_mode, events_listener_ready, battery_optimization_exempt, request_battery_exemption, device_maker, get_latest_version, download_update, fetch_page_title, expand_invite_link, fetch_link_preview, relay_invite_claim, probe_relay, c3_probe::probe_c3_relay, lufi::lufi_open_file, lufi::lufi_read_slice, lufi::lufi_close_file, lufi::lufi_config, lufi::lufi_ws_open, lufi::lufi_ws_send, lufi::lufi_ws_close, lufi::lufi_delete, cryptex::cryptex_new_password, cryptex::cryptex_create, cryptex::cryptex_progress, cryptex::cryptex_cancel, cryptex::cryptex_open, cryptex::cryptex_destroy, cryptex::cryptex_fetch, allow_picked_path, webxdc_begin, webxdc_end, set_notify_prefs, set_logging_enabled, set_devtools, open_in_app_browser, open_webview_browser, take_opened_urls, chat_link_token, get_sidecar_status, get_db_lock_status, get_db_key_issue, get_db_pin_state, set_db_pin, clear_db_pin, unlock_with_pin, lock_now, biometric_state, biometric_set, set_autolock_mins, volume_encryption_status, get_accounts_dir, resolve_upload_path, prepare_builtin_xdc, resolve_content_uri, prep_backup, backup_scratch_dir, publish_backup, save_attachment, media_base_url, read_media_bytes, notify_incoming, install_update, get_battery_status, push_status, push_select, push_off, call_audio_start, call_audio_speaker, call_audio_stop, call_permission, share_text,proxy::proxy_install, proxy::proxy_list, proxy::proxy_select, proxy::proxy_rename, proxy::proxy_delete, proxy::proxy_link, proxy::proxy_status, proxy::proxy_backup_begin, proxy::proxy_backup_end, proxy::proxy_reapply, ws_transport::ws_transport_status, ws_transport::ws_transport_add, ws_transport::ws_transport_select, ws_transport::ws_transport_delete, ws_transport::ws_transport_test, p2p::p2p_status, p2p::p2p_set_enabled, p2p::p2p_set_name, p2p::p2p_create_invite, p2p::p2p_accept_invite, p2p::p2p_send, p2p::p2p_send_file, p2p::p2p_remove_peer, p2p::p2p_messages, p2p::p2p_pair_nearby, p2p::p2p_approve_pair, p2p::p2p_group_create, p2p::p2p_group_add, p2p::p2p_group_remove, p2p::p2p_group_rename, p2p::p2p_group_disband, p2p::p2p_group_leave, p2p::p2p_group_delete, p2p::p2p_peer_groups, p2p::p2p_typing, p2p::p2p_group_send, p2p::p2p_group_send_file, p2p::p2p_group_file_retry, p2p::p2p_group_messages, scheduled::scheduled_op, scheduled::scheduled_run_due, scheduled::scheduled_exact_status, scheduled::scheduled_exact_request]);

    builder = builder.plugin(tauri_plugin_notification::init());

    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        builder = builder
            .plugin(tauri_plugin_single_instance::init(|app, argv, cwd| {
                let redacted: Vec<String> = argv.iter().map(|a| redact_chat_link(a)).collect();
                log(&format!("single-instance args: {redacted:?} cwd={cwd}"));
                // The deep-link plugin forwards velta:// to the running instance
                // as deep-link://new-url. File paths (Send to) are not that scheme.
                let files: Vec<String> = collect_startup_args(argv.iter().skip(1), |a| Path::new(a).is_file())
                    .into_iter()
                    .filter(|a| maybe_extract_deeplink(a).is_none())
                    .collect();
                if files.is_empty() {
                    return;
                }
                focus_main_window(app);
                for f in files {
                    queue_opened(f.clone());
                    app.emit("deeplink", f).ok();
                }
            }))
            .plugin(tauri_plugin_deep_link::init())
            // Windows self-update: the renderer drives check/download/install
            // through the plugin's JS API; all traffic stays shell-side.
            .plugin(tauri_plugin_updater::Builder::new().build())
            .plugin(tauri_plugin_process::init());
    }

    builder
        .build(tauri::generate_context!())
        .expect("error while building tauri application")
        .run(|_app, _event| {
            #[cfg(any(target_os = "macos", target_os = "ios", target_os = "android"))]
            if let tauri::RunEvent::Opened { urls } = _event {
                for url in &urls {
                    let s = url.to_string();
                    log_opened(&s);
                    queue_opened(s.clone());
                    _app.emit("deeplink", s).ok();
                }
            }
        });
}

// ---------------------------------------------------------------------------
// Tests: media range serving + IPC size guard
// ---------------------------------------------------------------------------

#[cfg(test)]
mod media_tests {
    use super::*;
    use std::io::{Read as _, Write as _};

    #[test]
    fn media_token_compare_is_exact() {
        assert!(constant_time_eq(b"abc123", b"abc123"));
        assert!(!constant_time_eq(b"abc123", b"abc124"));
        assert!(!constant_time_eq(b"abc123", b"abc12"));
        assert!(!constant_time_eq(b"", b"x"));
        assert!(constant_time_eq(b"", b""));
    }

    fn temp_media_dir(tag: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!("velta-media-test-{tag}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        dir
    }

    // Content: byte i = (i % 251) as u8, so any wrong offset or truncated
    // body produces a different payload.
    fn make_media_file(dir: &std::path::Path, name: &str, len: usize) -> PathBuf {
        let path = dir.join(name);
        let data: Vec<u8> = (0..len).map(|i| (i % 251) as u8).collect();
        std::fs::write(&path, &data).unwrap();
        path
    }

    fn start_test_server(accounts: PathBuf) -> u16 {
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        std::thread::spawn(move || {
            for stream in listener.incoming() {
                let Ok(mut server) = stream else { break };
                serve_media_connection(&mut server, &accounts);
            }
        });
        port
    }

    fn exchange(port: u16, request: String) -> Vec<u8> {
        let mut sock = std::net::TcpStream::connect(("127.0.0.1", port)).unwrap();
        sock.write_all(request.as_bytes()).unwrap();
        let mut response = Vec::new();
        let mut buf = [0u8; 8192];
        loop {
            match sock.read(&mut buf) {
                Ok(0) => break,
                Ok(n) => response.extend_from_slice(&buf[..n]),
                Err(_) => break,
            }
        }
        response
    }

    fn head(response: &[u8]) -> String {
        let end = response.windows(4).position(|w| w == b"\r\n\r\n").map(|i| i + 4).unwrap_or(response.len());
        String::from_utf8_lossy(&response[..end]).into_owned()
    }

    fn body(response: &[u8]) -> &[u8] {
        match response.windows(4).position(|w| w == b"\r\n\r\n") {
            Some(i) => &response[i + 4..],
            None => &[],
        }
    }

    fn get(port: u16, token: &str, path: &str, range: Option<&str>) -> Vec<u8> {
        get_with(port, token, path, range, None)
    }

    fn get_with(port: u16, token: &str, path: &str, range: Option<&str>, origin: Option<&str>) -> Vec<u8> {
        let range_line = range.map(|r| format!("Range: {r}\r\n")).unwrap_or_default();
        let origin_line = origin.map(|o| format!("Origin: {o}\r\n")).unwrap_or_default();
        exchange(
            port,
            format!("GET /{token}/{} HTTP/1.1\r\nHost: x\r\n{range_line}{origin_line}\r\n", path),
        )
    }

    // Regression: the head terminator literal was a raw newline pair, so the
    // server never saw the end of the request head and every request waited
    // for the 10 s read timeout before answering.
    #[test]
    fn request_head_is_parsed_without_waiting_for_the_read_timeout() {
        let dir = temp_media_dir("latency");
        *MEDIA_TOKEN.lock().unwrap() = "testtoken".into();
        let path = make_media_file(&dir, "clip.mp4", 100);
        let port = start_test_server(dir.clone());

        let started = std::time::Instant::now();
        let response = get(port, "testtoken", &path.to_string_lossy(), Some("bytes=0-9"));
        assert!(head(&response).starts_with("HTTP/1.1 206"), "{}", head(&response));
        assert!(started.elapsed() < std::time::Duration::from_secs(3), "took {:?}", started.elapsed());
    }

    #[test]
    fn sandboxed_frames_cannot_read_media_and_the_app_origin_can() {
        let dir = temp_media_dir("origin");
        *MEDIA_TOKEN.lock().unwrap() = "testtoken".into();
        let path = make_media_file(&dir, "clip.mp4", 100);
        let port = start_test_server(dir.clone());
        let p = path.to_string_lossy();

        // Opaque-origin frames (webxdc apps, the HTML viewer) send Origin: null.
        let denied = get_with(port, "testtoken", &p, None, Some("null"));
        assert!(head(&denied).starts_with("HTTP/1.1 404"), "{}", head(&denied));
        assert!(body(&denied).is_empty());

        let allowed = get_with(port, "testtoken", &p, None, Some("http://tauri.localhost"));
        assert!(head(&allowed).starts_with("HTTP/1.1 200"), "{}", head(&allowed));
        assert!(head(&allowed).contains("Access-Control-Allow-Origin: http://tauri.localhost"), "{}", head(&allowed));

        // Plain element loads carry no Origin and get no ACAO header.
        let plain = get(port, "testtoken", &p, None);
        assert!(head(&plain).starts_with("HTTP/1.1 200"), "{}", head(&plain));
        assert!(!head(&plain).contains("Access-Control-Allow-Origin"), "{}", head(&plain));
    }

    #[test]
    fn media_cors_accepts_only_app_origins() {
        assert_eq!(media_cors(None), Ok(None));
        assert_eq!(media_cors(Some("tauri://localhost")), Ok(Some("tauri://localhost".into())));
        assert_eq!(media_cors(Some("http://tauri.localhost")), Ok(Some("http://tauri.localhost".into())));
        assert_eq!(media_cors(Some("null")), Err(()));
        assert_eq!(media_cors(Some("http://webxdc.localhost")), Err(()));
        assert_eq!(media_cors(Some("https://example.com")), Err(()));
    }

    #[test]
    fn parse_range_cases() {
        assert_eq!(parse_range("bytes=0-99", 1000), Some((0, 99)));
        assert_eq!(parse_range("bytes=100-199", 1000), Some((100, 199)));
        assert_eq!(parse_range("bytes=100-", 1000), Some((100, 999)));
        assert_eq!(parse_range("bytes=-200", 1000), Some((800, 999)));
        assert_eq!(parse_range("bytes=999-", 1000), Some((999, 999)));
        // Unsatisfiable or malformed.
        assert_eq!(parse_range("bytes=1000-", 1000), None);
        assert_eq!(parse_range("bytes=-0", 1000), None);
        assert_eq!(parse_range("bytes=500-100", 1000), None);
        assert_eq!(parse_range("bytes=abc", 1000), None);
    }

    #[test]
    fn range_request_serves_the_requested_interval_from_the_right_offset() {
        let dir = temp_media_dir("range");
        *MEDIA_TOKEN.lock().unwrap() = "testtoken".into();
        let path = make_media_file(&dir, "clip.mp4", 1000);
        let port = start_test_server(dir.clone());

        let response = get(port, "testtoken", &path.to_string_lossy(), Some("bytes=100-199"));

        assert!(head(&response).starts_with("HTTP/1.1 206 Partial Content"), "{}", head(&response));
        assert!(head(&response).contains("Content-Range: bytes 100-199/1000"), "{}", head(&response));
        let expected: Vec<u8> = (100..200).map(|i| (i % 251) as u8).collect();
        assert_eq!(body(&response), expected.as_slice());
    }

    #[test]
    fn open_ended_and_suffix_ranges_stay_correct() {
        let dir = temp_media_dir("openrange");
        *MEDIA_TOKEN.lock().unwrap() = "testtoken".into();
        let path = make_media_file(&dir, "clip.mp4", 1000);
        let port = start_test_server(dir.clone());
        let tail: Vec<u8> = (900..1000).map(|i| (i % 251) as u8).collect();

        // bytes=900- → the tail, seeked to 900.
        let response = get(port, "testtoken", &path.to_string_lossy(), Some("bytes=900-"));
        assert!(head(&response).contains("Content-Range: bytes 900-999/1000"), "{}", head(&response));
        assert_eq!(body(&response), tail.as_slice());

        // bytes=-100 → also the last 100 bytes.
        let response = get(port, "testtoken", &path.to_string_lossy(), Some("bytes=-100"));
        assert!(head(&response).contains("Content-Range: bytes 900-999/1000"), "{}", head(&response));
        assert_eq!(body(&response), tail.as_slice());
    }

    #[test]
    fn unsatisfiable_range_gets_416_not_the_whole_file() {
        let dir = temp_media_dir("unsat");
        *MEDIA_TOKEN.lock().unwrap() = "testtoken".into();
        let path = make_media_file(&dir, "clip.mp4", 1000);
        let port = start_test_server(dir.clone());

        let response = get(port, "testtoken", &path.to_string_lossy(), Some("bytes=2000-3000"));
        assert!(head(&response).starts_with("HTTP/1.1 416"), "{}", head(&response));
        assert!(head(&response).contains("Content-Range: bytes */1000"), "{}", head(&response));
        assert!(body(&response).is_empty(), "{:?}", body(&response));
    }

    #[test]
    fn full_get_streams_the_whole_file() {
        let dir = temp_media_dir("full");
        *MEDIA_TOKEN.lock().unwrap() = "testtoken".into();
        let path = make_media_file(&dir, "clip.mp4", 5000);
        let port = start_test_server(dir.clone());

        let response = get(port, "testtoken", &path.to_string_lossy(), None);
        assert!(head(&response).starts_with("HTTP/1.1 200 OK"), "{}", head(&response));
        assert!(head(&response).contains("Content-Length: 5000"), "{}", head(&response));
        assert_eq!(body(&response).len(), 5000);
        let expected: Vec<u8> = (0..5000).map(|i| (i % 251) as u8).collect();
        assert_eq!(body(&response), expected.as_slice());
    }

    #[test]
    fn oversized_media_read_is_refused_before_allocation() {
        let dir = temp_media_dir("big");
        let path = dir.join("big.mp4");
        // Sparse file: size without content, so the test stays fast.
        let f = std::fs::File::create(&path).unwrap();
        f.set_len(MAX_MEDIA_IPC_BYTES + 1).unwrap();
        drop(f);

        let err = checked_media_read(&path).unwrap_err();
        assert!(err.contains("too large"), "{err}");
    }
}

#[cfg(test)]
mod chat_link_token_tests {
    use super::*;

    fn token_dir(tag: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!("velta-chat-token-{tag}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[test]
    fn token_file_is_created_once_and_reused() {
        let dir = token_dir("once");
        let path = dir.join("chat-link-token");
        let first = load_or_create_chat_link_token(&path).unwrap();
        let second = load_or_create_chat_link_token(&path).unwrap();
        assert_eq!(first, second);
        assert!(valid_chat_link_token(&first));
        assert_eq!(std::fs::read_to_string(&path).unwrap(), first);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn corrupt_token_file_is_replaced() {
        let dir = token_dir("corrupt");
        let path = dir.join("chat-link-token");
        std::fs::write(&path, "not-a-token\n").unwrap();
        let token = load_or_create_chat_link_token(&path).unwrap();
        assert!(valid_chat_link_token(&token));
        assert_eq!(std::fs::read_to_string(&path).unwrap(), token);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn trimmed_token_file_is_kept() {
        let dir = token_dir("trim");
        let path = dir.join("chat-link-token");
        std::fs::write(&path, "0123456789abcdef0123456789abcdef\n").unwrap();
        assert_eq!(
            load_or_create_chat_link_token(&path).unwrap(),
            "0123456789abcdef0123456789abcdef"
        );
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn unreadable_token_path_is_not_replaced() {
        let dir = token_dir("dir");
        // A directory is not a token file and is not NotFound, so a failed
        // read must not mint a new token over it.
        let err = load_or_create_chat_link_token(&dir).unwrap_err();
        assert!(!err.is_empty());
        assert!(dir.is_dir());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn redact_chat_link_hides_only_the_query_token() {
        assert_eq!(
            redact_chat_link("velta://chat?account=1&chat=2&t=abcd"),
            "velta://chat?account=1&chat=2&t=…"
        );
        assert_eq!(redact_chat_link("velta://chat?t=abcd&chat=2"), "velta://chat?t=…&chat=2");
        assert_eq!(redact_chat_link("https://x?t=secret#frag"), "https://x?t=…#frag");
        assert_eq!(redact_chat_link("no token"), "no token");
        assert_eq!(redact_chat_link(r"C:\Users\t=foo"), r"C:\Users\t=foo");
    }
}

#[cfg(test)]
mod opened_args_tests {
    use super::*;

    #[test]
    fn startup_args_keep_deeplinks_and_existing_files_only() {
        let file = std::env::temp_dir().join(format!("velta-share-arg-{}", std::process::id()));
        std::fs::write(&file, b"x").unwrap();
        let path = file.to_string_lossy().to_string();
        let got = collect_startup_args(
            ["--flag", "velta://chat?chat=1", "https://example.com", path.as_str(), "not-a-file"],
            |a| Path::new(a).is_file(),
        );
        assert_eq!(
            got,
            vec!["velta://chat?chat=1".to_string(), "https://example.com".to_string(), path]
        );
        let _ = std::fs::remove_file(&file);
    }

    #[test]
    fn sendto_shortcut_matches_only_its_target() {
        let dir = std::env::temp_dir().join(format!("velta-lnk-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let exe = dir.join("velta-app.exe");
        let link = dir.join("Velta.lnk");
        let needle: Vec<u8> = exe.to_string_lossy().encode_utf16().flat_map(|c| c.to_le_bytes()).collect();
        std::fs::write(&link, &needle).unwrap();
        assert!(lnk_points_at(&link, &exe));
        assert!(!lnk_points_at(&link, &dir.join("other.exe")));
        assert!(!lnk_points_at(&dir.join("missing.lnk"), &exe));
        let _ = std::fs::remove_dir_all(&dir);
    }
}

#[cfg(test)]
mod link_preview_proxy_tests {
    use super::*;

    #[test]
    fn no_proxy_is_a_direct_fetch() {
        assert_eq!(link_preview_proxy(None), Ok(None));
        assert_eq!(link_preview_proxy(Some("")), Ok(None));
        assert_eq!(link_preview_proxy(Some(" \n \n")), Ok(None));
        assert!(link_preview_agent(None).is_ok());
    }

    #[test]
    fn socks5_and_http_proxies_are_used() {
        // Authenticated SOCKS5 proxy URL.
        let proxy = "socks5://user:secret@127.0.0.1:41234";
        assert_eq!(link_preview_proxy(Some(proxy)), Ok(Some(proxy.to_string())));
        assert_eq!(
            link_preview_proxy(Some("socks5h://u:p@proxy.example:1080")),
            Ok(Some("socks5://u:p@proxy.example:1080".to_string()))
        );
        assert_eq!(
            link_preview_proxy(Some("HTTP://proxy.example:3128")),
            Ok(Some("http://proxy.example:3128".to_string()))
        );
        assert!(link_preview_agent(Some(proxy)).is_ok());
        assert!(link_preview_agent(Some("http://proxy.example:3128")).is_ok());
    }

    #[test]
    fn first_line_of_a_proxy_list_wins() {
        assert_eq!(
            link_preview_proxy(Some("\nsocks5://a:1080\nhttp://b:3128")),
            Ok(Some("socks5://a:1080".to_string()))
        );
        // an unusable first entry fails closed instead of falling to the next
        assert!(link_preview_proxy(Some("ss://abc@h:1\nsocks5://a:1080")).is_err());
    }

    #[test]
    fn unusable_proxies_fail_closed() {
        for p in ["ss://YWVzOnB3@h:8388", "https://proxy.example:443", "socks4://h:1", "tg://socks?server=h", "garbage", "socks5://"] {
            assert!(link_preview_proxy(Some(p)).is_err(), "{p}");
            assert!(link_preview_agent(Some(p)).is_err(), "{p}");
        }
    }

    #[test]
    fn a_dead_proxy_never_falls_back_to_direct() {
        // Nothing listens on the port: the fetch errors instead of going direct.
        let port = std::net::TcpListener::bind("127.0.0.1:0").unwrap().local_addr().unwrap().port();
        let agent = link_preview_agent(Some(&format!("socks5://127.0.0.1:{port}"))).unwrap();
        assert!(agent.get("https://example.com/").call().is_err());
    }

    #[test]
    fn the_fetch_connects_to_the_proxy() {
        // A listener that reads the SOCKS5 greeting and hangs up: the agent
        // must dial it (not example.com) and then fail.
        let l = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = l.local_addr().unwrap().port();
        let seen = std::thread::spawn(move || {
            use std::io::Read as _;
            let (mut c, _) = l.accept().unwrap();
            let mut b = [0u8; 1];
            c.read_exact(&mut b).unwrap();
            b[0]
        });
        let agent = link_preview_agent(Some(&format!("socks5://127.0.0.1:{port}"))).unwrap();
        assert!(agent.get("https://example.com/").call().is_err());
        assert_eq!(seen.join().unwrap(), 5, "SOCKS version byte");
    }
}

#[cfg(test)]
mod relay_claim_tests {
    use super::relay_claim_url;

    #[test]
    fn accepts_plain_invites() {
        assert_eq!(relay_claim_url("Relay.Example.", "AbCdEf12_-xy").unwrap(), "https://relay.example/i/claim?t=AbCdEf12_-xy");
    }

    #[test]
    fn rejects_malformed() {
        for (h, t) in [
            ("relay.example:8443", "AbCdEf12"), ("user@relay.example", "AbCdEf12"), ("10.0.0.1", "AbCdEf12"),
            ("localhost", "AbCdEf12"), ("relay.example/x", "AbCdEf12"), ("-a.example", "AbCdEf12"),
            ("relay.example", "short"), ("relay.example", "claim"), ("relay.example", "AbCd&x=1234"),
            ("relay.example", "AbCdEf12%2F"), ("relay.example", &"a".repeat(129)),
        ] {
            assert!(relay_claim_url(h, t).is_err(), "{h} {t}");
        }
    }
}

#[cfg(test)]
mod core_rpc_watchdog_tests {
    use super::*;
    use std::time::{Duration, Instant};

    #[test]
    fn method_of_request_line() {
        assert_eq!(rpc_method_of(r#"{"jsonrpc":"2.0","id":3,"method":"get_chat","params":[1]}"#), "get_chat");
        assert_eq!(rpc_method_of("garbage"), "?");
    }

    #[test]
    fn inflight_summary_names_oldest_and_skips_long_polls() {
        let now = Instant::now() + Duration::from_secs(60);
        let mut m = std::collections::HashMap::new();
        m.insert(1, ("get_next_event_batch".to_string(), now - Duration::from_secs(50)));
        m.insert(2, ("get_chatlist_items_by_entries".to_string(), now - Duration::from_secs(12)));
        m.insert(3, ("get_chat".to_string(), now - Duration::from_secs(1)));
        let s = summarize_inflight(&m, now, Duration::from_secs(8)).unwrap();
        assert_eq!(s, "core rpc in flight (2): get_chatlist_items_by_entries 12.0s, get_chat 1.0s");
        m.remove(&2);
        assert!(summarize_inflight(&m, now, Duration::from_secs(8)).is_none());
    }
}
